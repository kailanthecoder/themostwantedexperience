# Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload every file and folder from this package to the repository root. Keep `index.html` and the `deck` folder together.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your default branch, choose **/(root)**, and save.

GitHub will display the public URL after the first deployment finishes.
