const APP_VERSION = "2.10.147";
const DEFAULT_LOGO_SRC = "app/regen-logo.png?v=dark-logo-20260821";
const PROPOSAL_LOGO_SRC = "app/regen-logo-proposal.png?v=proposal-black-logo-20260821";
const REGEN_CONTACT_EMAIL = "";
const REGEN_CONTACT_PHONE = "";
const MOST_WANTED_LEGAL_IDENTITY = "Most Wanted, DBA of Kailan Industries FZCO out of the UAE, all sales are contractually underwritten by Regen Digital, based in Delaware";
const REGEN_PROPOSAL_TITLE = "Your Digital Infrastructure Plan";
const REGEN_PROPOSAL_SUMMARY = "Thank you for meeting with us. This proposal explains what we will build, what it costs and what happens next. Before this meeting, Most Wanted invested approximately six focused hours designing and engineering the prepared website for your business. The prepared work and offer remain reserved for 72 hours while the Most Wanted Room is available for questions, another decision-maker or a final private consultation.";
const REGEN_PROPOSAL_CUSTOMER_NEEDS = "Signing the agreement, receiving payment, confirming your domain details";
const REGEN_PROPOSAL_SERVICE_COPY = {
  seo: "We’ll deliver monthly SEO, something 99% of agencies do not include. In fact, we have not found another agency that offers it included. We will also optimize your website for AI Optimization to bring you more clients and continual growth as the months go on.",
  website: "We’ll launch the demo site we discussed, ensuring that you can begin receiving leads and inbound traffic, converting it correctly from day 1, and launch your online presence with precision.",
  reviews: "We’ll provide you with a state-of-the-art Google Review and reputation management system, ensuring you can automate the review process in a number of key ways to build your reputation online."
};
const STORAGE_PREFIX = "most-wanted:v2:";
const ACTIVE_KEY = `${STORAGE_PREFIX}active`;
const INDEX_KEY = `${STORAGE_PREFIX}prospects`;
const ANALYTICS_KEY = `${STORAGE_PREFIX}analytics`;
const API_ENABLED = false;
const CLIENT_SESSION_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const INVALID_SESSION_STATUSES = new Set([400, 401, 403, 404, 410, 422]);
const API_RETRY_DELAY_MS = 60_000;

const SERVICES = {
  seo: {
    id: "seo", name: "Regular SEO + AI Optimization", icon: "🔎", pillar: "found",
    problem: "Not enough local people find the business", deliverable: "Improve Google visibility for the searches that matter",
    window: "7–14 business days", customer: "Business details, service area and account access",
    setup: 0, monthly: 0, demo: "visibility"
  },
  ads: {
    id: "ads", name: "Paid Ads", icon: "📣", pillar: "found",
    problem: "Not enough good local leads", deliverable: "Set up, track and launch your ad campaigns",
    window: "5–10 business days", customer: "Services to advertise, service area, budget and ad-account access",
    setup: 0, monthly: 0, demo: "ads"
  },
  receptionist: {
    id: "receptionist", name: "AI Receptionist", icon: "📞", pillar: "answered",
    problem: "Calls are missed or answered too slowly", deliverable: "Answer calls, collect details and book work",
    window: "3–7 business days", customer: "How calls should be handled, common questions and calendar access",
    setup: 0, monthly: 0, demo: "receptionist"
  },
  chatbot: {
    id: "chatbot", name: "AI Chatbot", icon: "💬", pillar: "answered",
    problem: "Website and social messages are answered too slowly", deliverable: "Answer messages, collect details and book work",
    window: "3–7 business days", customer: "Common questions, booking rules and the places messages come from",
    setup: 0, monthly: 0, demo: "chatbot"
  },
  website: {
    id: "website", name: "Website", icon: "🖥️", pillar: "chosen",
    problem: "The current website is not earning enough trust", deliverable: "Custom website built to turn visits into calls",
    window: "1–3 business days", customer: "Business information, approvals and domain access",
    setup: 0, monthly: 0, demo: "website"
  },
  reviews: {
    id: "reviews", name: "Google Review System", icon: "⭐", pillar: "chosen",
    problem: "The business needs more recent Google reviews", deliverable: "Simple system for asking customers for reviews",
    window: "2–5 business days", customer: "Logo, customer list and Google profile access",
    setup: 0, monthly: 0, demo: "reviews"
  },
  crm: {
    id: "crm", name: "CRM + Follow-Up", icon: "🗂️", pillar: "chosen",
    problem: "Enquiries are not tracked or followed up every time", deliverable: "Keep every enquiry together and follow up automatically",
    window: "3–7 business days", customer: "The steps from new enquiry to booked job, team users and approval for messages",
    setup: 0, monthly: 0, demo: "crm"
  }
};

const DEFAULT_PACKAGE_TEMPLATES = [
  {
    id: "complete-digital-infrastructure",
    name: "Complete Digital Infrastructure",
    setup: 0,
    monthly: 0,
    allServices: true
  },
  {
    id: "digital-market-mastery",
    name: "Digital Market Mastery",
    setup: 0,
    monthly: 0,
    allServices: false
  }
];

const SERVICE_COMPARISONS = {
  website: {
    title: "Website",
    lead: "Compare a do-it-yourself website, a conventional agency handover and a Most Wanted site built as a connected growth system.",
    levels: [
      { className: "basic", number: "01", icon: "🧱", label: "DIY", provider: "Wix, Squarespace, Or $20 AI Subscription", factor: "DIY", factorLabel: "Usually glitchy, with little or no discovery", headline: "A website can go live, but practically nobody ever sees it.", bullets: ["Template-led design that often barely works", "Visitors can get lost in the design", "No system for consistently bringing traffic", "Often slow or poorly optimized for mobile"], outcome: "A site exists. A growth system does not." },
      { className: "typical", number: "02", icon: "📦", label: "LEFT", provider: "Any Other Web Agency In 2026", factor: "LEFT", factorLabel: "Once handed over, there is no growth system", headline: "A website built like almost every other agency project in 2026.", bullets: ["Launched with initial SEO, but no consistent engine", "Changes are usually slow, costly or frustrating", "No complete, connected system for market dominance"], outcome: "A completed project, then you are left to drive growth." },
      { className: "regen", number: "03", icon: "⚡", label: "GROWTH", provider: "Your Most Wanted Conversion & Growth Site", factor: "GROWTH", factorLabel: "Unbeatable support, connected systems and improvement over time", headline: "Built to bring revenue and jobs by connecting conversion, discovery and follow-up.", bullets: ["Conversion, speed and discovery science at their peak", "Connected to calls, enquiries, reviews and follow-up", "Clear ready times with continued human support", "Regular SEO helps more people find you over time"], outcome: "A revenue system designed to keep getting stronger." }
    ]
  },
  seo: {
    title: "Regular SEO",
    lead: "Compare no SEO, a single launch-time setup and regular strategic tightening throughout the year.",
    levels: [
      { className: "basic", number: "01", icon: "🧱", label: "0 SEO", provider: "0 SEO Whatsoever", factor: "0×", factorLabel: "Ongoing SEO. Near-zero visibility.", headline: "They might add a favicon and a description, but it creates no meaningful impact.", bullets: ["Virtually no real impact on the site's visibility", "No specialist regularly improving visibility", "The site is unlikely to be discovered organically"], outcome: "A site online, with no visibility engine." },
      { className: "typical", number: "02", icon: "📦", label: "ONE TIME", provider: "SEO One Time If That", factor: "1×", factorLabel: "SEO done once, at launch", headline: "The website is optimized for one moment in time.", bullets: ["Initial audit and launch setup, usually", "Work commonly slows after launch instead of growing", "Ongoing SEO often comes with a significant price tag"], outcome: "A launch task, not a continuing process." },
      { className: "regen", number: "03", icon: "📈", label: "REGULAR", provider: "Regular SEO Tightening", factor: "12×", factorLabel: "Strategic reviews every year", headline: "Search is treated as repeated work, not a launch checkbox.", bullets: ["Monthly keyword tightening that fortifies growth", "Technical, page, local and AI-search work completed", "Every system works together as one complete system"], outcome: "Continuous improvement with one accountable partner." }
    ]
  },
  reviews: {
    title: "Google Review System",
    lead: "Compare remembering to ask manually, buying stand-alone review software and running a connected review workflow.",
    levels: [
      { className: "basic", number: "01", icon: "🗣️", label: "MANUAL", provider: "Ask when you remember", factor: "AD HOC", factorLabel: "Inconsistent review requests", headline: "Good customers may be happy, but many are never asked at the right time.", bullets: ["Owner or staff remember to ask", "No consistent request timing", "Results depend on individual habits"], outcome: "Reputation growth is left to memory" },
      { className: "typical", number: "02", icon: "⭐", label: "STAND-ALONE TOOL", provider: "Review software subscription", factor: "TOOL", factorLabel: "Software the team operates", headline: "The requests can be automated, but the tool may sit apart from daily operations.", bullets: ["Templates and review links", "Team configures contacts and triggers", "Another dashboard and process to manage"], outcome: "Useful software that still needs ownership" },
      { className: "regen", number: "03", icon: "🔗", label: "MOST WANTED", provider: "Connected review workflow", factor: "FLOW", factorLabel: "Built into the customer journey", headline: "Review requests become a defined step after completed work.", bullets: ["Configured request timing and messaging", "Connected with customer records and follow-up", "One team owns setup and support"], outcome: "A repeatable reputation-building system" }
    ]
  },
  crm: {
    title: "CRM + Follow-Up",
    lead: "Compare scattered notes, an empty CRM subscription and a workflow configured around the way the business actually sells.",
    levels: [
      { className: "basic", number: "01", icon: "📥", label: "MANUAL", provider: "Inbox, phone and spreadsheets", factor: "SCATTERED", factorLabel: "Several places to check", headline: "Customer information exists, but it is split across people and tools.", bullets: ["Notes live in inboxes, phones or sheets", "Follow-up depends on memory", "Limited visibility over every enquiry"], outcome: "The process works until something is missed" },
      { className: "typical", number: "02", icon: "🗂️", label: "SOFTWARE ONLY", provider: "Stand-alone CRM", factor: "LOGIN", factorLabel: "A platform the team must configure", headline: "The software is capable, but value depends on setup and consistent team use.", bullets: ["Central customer database", "Workflows available if configured", "Training and administration stay with the business"], outcome: "Powerful software that can become shelfware" },
      { className: "regen", number: "03", icon: "⚙️", label: "MOST WANTED", provider: "Configured customer workflow", factor: "DONE", factorLabel: "Built around the real sales process", headline: "The CRM is configured as the operating path from enquiry to booked work.", bullets: ["Stages shaped around the business", "Follow-up and ownership rules connected", "Setup and human support included"], outcome: "A working process, not another empty dashboard" }
    ]
  },
  chatbot: {
    title: "AI Chatbot",
    lead: "Compare a contact form, a generic chat widget and a connected assistant designed around the business's real enquiries.",
    levels: [
      { className: "basic", number: "01", icon: "✉️", label: "BASIC", provider: "Contact form", factor: "WAIT", factorLabel: "Customer submits and waits", headline: "The enquiry is captured, but the conversation stops until a person replies.", bullets: ["Collects basic contact details", "No immediate question handling", "Speed depends on staff availability"], outcome: "A message box, not an active response system" },
      { className: "typical", number: "02", icon: "💬", label: "STAND-ALONE BOT", provider: "Generic chat widget", factor: "CHAT", factorLabel: "Answers a prepared set of questions", headline: "Visitors receive faster answers, but the bot may remain disconnected from the sales process.", bullets: ["Common questions and simple flows", "Separate dashboard and setup", "Handover and booking vary by provider"], outcome: "Faster answers with another tool to manage" },
      { className: "regen", number: "03", icon: "🤖", label: "MOST WANTED", provider: "Connected enquiry assistant", factor: "24/7", factorLabel: "Capture, qualify and route", headline: "The assistant is configured to move a real enquiry toward the next useful step.", bullets: ["Business-specific answers and qualification", "Connected with booking or follow-up", "One team manages setup and support"], outcome: "A response system connected to the customer journey" }
    ]
  },
  receptionist: {
    title: "AI Receptionist",
    lead: "Compare voicemail, a stand-alone answering service and a connected receptionist configured around the calls the business receives.",
    levels: [
      { className: "basic", number: "01", icon: "📵", label: "BASIC", provider: "Voicemail and callbacks", factor: "LATER", factorLabel: "The customer waits for a return call", headline: "Missed callers leave a message or move on to another business.", bullets: ["Low setup and familiar process", "Staff return calls when available", "No immediate qualification or booking"], outcome: "Every missed call becomes a manual recovery task" },
      { className: "typical", number: "02", icon: "🎧", label: "ANSWERING SERVICE", provider: "Stand-alone call handling", factor: "ANSWER", factorLabel: "A separate team takes the message", headline: "More calls are answered, but information and handover can remain separate.", bullets: ["Human or scripted call answering", "Messages passed to the business", "Booking and CRM connection vary"], outcome: "Better coverage with a separate provider" },
      { className: "regen", number: "03", icon: "📞", label: "MOST WANTED", provider: "Connected AI receptionist", factor: "ROUTE", factorLabel: "Answer, qualify and move forward", headline: "Calls are handled around the rules, services and next steps of the business.", bullets: ["Business-specific call handling", "Qualification, message capture and booking", "Connected with records and follow-up"], outcome: "Call coverage built into one customer system" }
    ]
  },
  ads: {
    title: "Paid Ads",
    lead: "Compare self-serve promotion, stand-alone campaign management and advertising connected to the full enquiry and follow-up path.",
    levels: [
      { className: "basic", number: "01", icon: "📣", label: "SELF-SERVE", provider: "Boosts and DIY campaigns", factor: "CLICKS", factorLabel: "You manage targeting and follow-up", headline: "The platforms can generate attention, but the business owns the whole process.", bullets: ["Direct access to Google and Meta tools", "You manage creative, targeting and budget", "Lead handling remains separate"], outcome: "Media access without an accountable acquisition system" },
      { className: "typical", number: "02", icon: "📊", label: "AD MANAGER", provider: "Stand-alone campaign service", factor: "LEADS", factorLabel: "Campaign performance is the main scope", headline: "A specialist manages campaigns, usually up to the point a lead is delivered.", bullets: ["Campaign setup and optimization", "Reporting on media and lead activity", "Website, calls and follow-up may sit elsewhere"], outcome: "Managed advertising with hand-offs after the lead" },
      { className: "regen", number: "03", icon: "🎯", label: "MOST WANTED", provider: "Connected acquisition system", factor: "JOBS", factorLabel: "Ads connected to the response path", headline: "Advertising is planned around what happens before and after the click.", bullets: ["Campaign, landing experience and tracking aligned", "Calls, forms and follow-up connected", "One accountable partner across the system"], outcome: "Advertising connected to the route from click to customer" }
    ]
  }
};

const PILLARS = {
  found: { name: "Get Found", icon: "🔎", description: "SEO, AI search, Google Maps and paid ads." },
  answered: { name: "Answer Calls", icon: "📞", description: "Answer calls and messages before customers move on." },
  chosen: { name: "Get Chosen", icon: "✅", description: "Use your website, reviews and follow-up to win more work." }
};

const DEMOS = {
  website: { id: "website", name: "View Your Custom Website", icon: "🖥️", service: "website", url: "" },
  receptionist: { id: "receptionist", name: "Call the AI Receptionist", icon: "📞", service: "receptionist", url: "" },
  chatbot: { id: "chatbot", name: "Test the AI Chatbot", icon: "💬", service: "chatbot", url: "" },
  enquiry: { id: "enquiry", name: "Submit a Test Enquiry", icon: "✉️", service: "website", url: "" },
  crm: { id: "crm", name: "See a New Enquiry Get Saved", icon: "🗂️", service: "crm", url: "" },
  followup: { id: "followup", name: "Send a Test Follow-Up", icon: "🔁", service: "crm", url: "" },
  reviews: { id: "reviews", name: "View the Review Request Flow", icon: "⭐", service: "reviews", url: "" },
  ownership: { id: "ownership", name: "See What You Own", icon: "🔐", service: null, url: "" },
  support: { id: "support", name: "See How Support Works", icon: "🛟", service: null, url: "" }
};

const DISCOVERY_GROUPS = [
  { id: "business", name: "Your Business", icon: "🏪" },
  { id: "problems", name: "What Is Not Working", icon: "⚠️" },
  { id: "outcome", name: "What Must Change", icon: "🎯" }
];

const LAUNCH_TIMING_OPTIONS = [
  "Launch immediately",
  "Wait for domain",
  "Wait for requested changes",
  "Launch now, complete changes after"
];

const MAIN_SCENES = [
  "intro", "discovery", "cost", "agency", "testimonials", "regen", "system",
  "seoCompare", "proof", "guarantee", "economics", "regenRoom", "closerChecklist"
];

const FAST_SCENES = MAIN_SCENES;

const SCENE_LABELS = {
  intro: "What Most Wanted Does", discovery: "Your Business", cost: "The Cost", agency: "Why Agencies Fail",
  testimonials: "Client Stories", regen: "Why Most Wanted", system: "Your System", guarantee: "Delivery Guarantee", proof: "See It",
  seoCompare: "SEO Comparison", economics: "Economics", regenRoom: "Most Wanted Room",
  closerChecklist: "Closer Checklist",
  checkout: "Launch"
};

const SCENE_ALIASES = {
  company: "intro", "outcome-frame": "proof", discovery: "discovery", "what-i-heard": "heard",
  "revenue-leak": "leaks", ecosystem: "recommendation", recommendation: "recommendation", "proof-centre": "proof",
  "infrastructure-map": "infrastructure", infrastructure: "infrastructure", "connected-growth-system": "infrastructure",
  website: "website", "launch-version": "website", "decision-summary": "decision", support: "support", pledge: "pledge", "launch-plan": "launch",
  "break-even": "calculator", certainty: "certainty", "low-urgency": "lowUrgency", "price-decision": "price", close: "close", checkout: "checkout"
};

const OPPORTUNITY_LOSSES = {
  visibility: {
    icon: "🔎", name: "Not being found",
    description: "Potential customers may not see the business when they search.",
    systems: ["Regular SEO + AI Optimization", "Paid Ads", "Local visibility"]
  },
  response: {
    icon: "📞", name: "Not getting answered",
    description: "Calls, messages or forms may go unanswered, or get a reply after the customer has moved on.",
    systems: ["AI Receptionist", "AI Chatbot", "CRM lead capture"]
  },
  trust: {
    icon: "⭐", name: "Not enough trust",
    description: "People may find the business but still choose someone else.",
    systems: ["Website", "Reviews", "Positioning"]
  },
  followup: {
    icon: "🔁", name: "No consistent follow-up",
    description: "Interested people may not get the reminders or follow-up needed to book.",
    systems: ["CRM", "Email / SMS", "Reactivation"]
  }
};

const OPPORTUNITY_STATE_ALIASES = {
  yes: "yes", known: "yes", confirmed: "yes",
  maybe: "maybe", possible: "maybe", estimated: "maybe", observed: "maybe", likely: "maybe",
  no: "no",
  unknown: "unknown", "not currently measured": "unknown", "not measured": "unknown", "": "unknown"
};

const CHECKPOINT_OPTIONS = {
  understanding: ["Yes", "Needs an edit", "Add detail"],
  problem: ["Yes", "Needs an edit", "Add detail"],
  recommendation: ["Yes", "Needs an edit", "Add detail"],
  product: ["Yes", "Needs an edit", "Add detail"],
  decision: ["Yes", "Needs an edit", "Add detail"],
  certainty: ["Nothing", "Results", "Trust", "Timing", "Cash Flow", "Another Person"]
};

const DEFAULT_QUESTION_CATEGORIES = [
  {
    id: "services", name: "Services", emoji: "🧩", description: "What Most Wanted builds, how the systems connect and what you own.",
    items: [
      { id: "services-what", emoji: "⚙️", question: "What does Most Wanted actually build?", answer: "We design, build and connect the digital systems that help your business get found, answer enquiries, build trust and follow up consistently." },
      { id: "services-own", emoji: "🔑", question: "Do I own what Most Wanted builds?", answer: "Yes. Your agreed plan clearly states what you own, what Most Wanted manages and what can be transferred." },
      { id: "services-template", emoji: "✨", question: "Is this a template or a generic software package?", answer: "No. Your plan is configured around your business, priorities and existing infrastructure. You only launch the systems that make sense for you." }
    ]
  },
  {
    id: "support", name: "Support", emoji: "🤝", description: "How Most Wanted supports, manages and improves the system after launch.",
    items: [
      { id: "support-after", emoji: "🛟", question: "What happens after launch?", answer: "Your onboarding portal keeps the launch organised, and your dedicated support team helps manage the agreed build, access, changes and ongoing work." },
      { id: "support-human", emoji: "💬", question: "Can I speak to a real person?", answer: "Yes. Most Wanted is designed as a boutique, human partnership with dedicated support rather than a self-service software subscription." },
      { id: "support-manage", emoji: "🧰", question: "Do I have to figure the systems out myself?", answer: "No. Most Wanted handles the agreed implementation and connection work, while clearly showing anything we need from you." }
    ]
  },
  {
    id: "launch", name: "Launch", emoji: "🚀", description: "Ready times, responsibilities and what happens when you decide to begin.",
    items: [
      { id: "launch-speed", emoji: "⏱️", question: "How quickly can the plan launch?", answer: "Each selected service has a clear ready time. Your final Launch Plan shows those timeframes and separates what Most Wanted handles from what we need from you." },
      { id: "launch-needs", emoji: "📋", question: "What does Most Wanted need from me?", answer: "Usually the approved plan, payment, business details, access and timely feedback. Your Launch Plan lists the exact requirements for every selected service." },
      { id: "launch-pledge", emoji: "🛡️", question: "What protects the launch timeline?", answer: "When the On-Time Launch Pledge applies, a qualifying missed Most Wanted deadline triggers the remedies shown in your plan." }
    ]
  },
  {
    id: "investment", name: "Investment", emoji: "💳", description: "Pricing, payment choices and how the selected plan can be adjusted.",
    items: [
      { id: "investment-included", emoji: "🧾", question: "What is included in the price?", answer: "The Investment screen and formal proposal show the selected services, quantities, setup investment, monthly support and ready times in one place." },
      { id: "investment-saving", emoji: "💎", question: "How does the start-today saving work?", answer: "When enabled for the opportunity, the Investment screen shows the standard setup price, the exact saving and the amount due today before you choose." },
      { id: "investment-change", emoji: "🎛️", question: "Can the plan be changed?", answer: "Yes. Services, quantities and item-by-item pricing can be adjusted before the final agreement and payment." }
    ]
  }
];

const deepClone = value => JSON.parse(JSON.stringify(value));
const money = value => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(Number(value) || 0);
const number = value => new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 }).format(Number(value) || 0);
const currencyNumber = value => {
  const normalized = String(value ?? "").replace(/[^0-9.-]/g, "");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
};
const esc = value => String(value ?? "").replace(/\s*\u2014\s*/g, " - ").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]);
const accentLastTitleWord = value => {
  const words = String(value || "").trim().split(/\s+/).filter(Boolean);
  const keyWord = words.pop() || "Business";
  return `${words.length ? `${esc(words.join(" "))} ` : ""}<span class="accent">${esc(keyWord)}</span>`;
};
const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
const now = () => new Date().toISOString();
const slug = value => String(value ?? "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const normalizeOpportunityState = value => OPPORTUNITY_STATE_ALIASES[String(value ?? "").trim().toLowerCase()] || "unknown";
const opportunityLossLabel = id => OPPORTUNITY_LOSSES[id]?.name || "Not chosen yet";
const normalizePersistedPunctuation = value => {
  if (typeof value === "string") return value.replace(/\s*\u2014\s*/g, " - ");
  if (Array.isArray(value)) return value.map(normalizePersistedPunctuation);
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, normalizePersistedPunctuation(item)]));
  return value;
};
const coerce = value => {
  if (value === "true") return true;
  if (value === "false") return false;
  if (value === "null") return null;
  return value;
};
const get = (object, path, fallback = "") => path.split(".").reduce((acc, key) => acc?.[key], object) ?? fallback;
const set = (object, path, value) => {
  const keys = path.split(".");
  let cursor = object;
  keys.slice(0, -1).forEach(key => { if (!cursor[key] || typeof cursor[key] !== "object") cursor[key] = {}; cursor = cursor[key]; });
  cursor[keys.at(-1)] = value;
};

function defaultState() {
  const id = uid();
  return {
    schema: 25,
    id,
    variant: "v2",
    mode: new URLSearchParams(location.search).get("mode") === "prospect" ? "prospect" : "presenter",
    createdAt: now(), updatedAt: now(), startedAt: now(),
    currentScene: "intro", discoveryStep: 0, setupTab: "prospect", adminTab: "services",
    path: "standard", lowUrgencyEnabled: false, showAllDemos: false,
    activeTabs: { discovery: "business", cost: "impact", agency: "vendors", regen: "payments" },
    prospect: {
      name: "", business: "", industry: "", location: "", websiteUrl: "", googleBusinessUrl: "", demoUrl: "", previewImageUrl: "",
      averageJobRevenue: "", grossProfitPerJob: "", monthlyRevenue: "", monthlyOpportunities: "", missedPercent: "",
      averageResponseTime: "", monthlyEstimates: "", closeRate: "", reviewCount: "", reviewRating: "",
      currentChannels: [], currentSystems: [], provider: "", growthGoal: "", capacityJobs: "",
      primaryProblem: "", whyGoalMatters: "", whyNow: "", decisionMaker: "", approvers: "",
      budgetTiming: "", urgency: "", desiredJobs: "", desiredJobsMonthly: "", targetPeriod: "90 days", followupProcess: "",
      missedHandling: "", webEnquiryHandling: "", webTraffic: "", websitePerformance: "", localVisibility: "", acquisitionWorking: "",
      targetSearches: ["", "", ""], targetSearchAreas: ["", "", ""], serviceRadiusMiles: "", hasWebsite: "", competitiveEdge: "", reviewsProcess: "",
      commercialSources: { monthlyOpportunities: "", averageJobRevenue: "" },
      successSelections: [], blockerSelections: [], blockerDetail: "", wishSelections: []
    },
    heard: {
      situation: "", objective: "", constraint: "", opportunityVolume: "", capacity: "", decision: "", motive: "", searches: ["", "", ""], confirmed: false
    },
    leaks: {
      visibility: { state: "unknown", note: "" },
      response: { state: "unknown", note: "" },
      trust: { state: "unknown", note: "" },
      followup: { state: "unknown", note: "" },
      primary: ""
    },
    services: Object.fromEntries(Object.keys(SERVICES).map(id => [id, {
      status: "later", selected: false, quantity: 0, manual: false, reason: "Not needed based on what you told us."
    }])),
    demos: Object.fromEntries(Object.keys(DEMOS).map(id => [id, { viewed: false, url: "" }])),
    checkpoints: { understanding: "", problem: "", recommendation: "", product: "", decision: "", certainty: "" },
    websiteLaunch: { draftChange: "", requestedChanges: [] },
    notes: "", internalNotes: "", takeoutNotes: { prospect: "", offer: "", outcome: "" }, selectedDemo: "", calculatorScenario: "monthly1", customScenarioJobs: 1,
    followUpTemplates: { emailSubject: "", emailBody: "", textBody: "" },
    closerChecklist: {
      meetingCompleted: false,
      callNotesAdded: false,
      reminderSent: false,
      finalReminderScheduled: false,
      feedbackScheduled: false,
      waterCompleted: false,
      pushUpsCompleted: false
    },
    questions: { activeCategory: "services", categories: deepClone(DEFAULT_QUESTION_CATEGORIES) },
    guarantee: {
      enabled: true, title: "The Most Wanted On-Time Launch Pledge",
      coreDefinition: "the work listed in your signed Launch Plan",
      deadlineRule: "the ready times shown in your signed Launch Plan",
      trigger: "Most Wanted misses a deadline for a launch lead time.",
      clockStarts: "", clockPauses: "",
      buyerCredit: 1000, buyerCreditLabel: "Most Wanted store credit", freeSupportMonths: 0,
      charityEnabled: true, mealQuantity: 1000, charityName: "Feeding America",
      donationValue: "1,000 meals", proofUrl: "", termsUrl: "",
      exclusions: "",
      versionDate: "2026-08-21", customerRemedyCap: "$1,000 Most Wanted store credit"
    },
    support: {
      onboarding: "Use your secure onboarding portal to send business details and account access, check progress and contact your dedicated support team.", channels: "", hours: "", responseTarget: "", changePolicy: "", urgentProcess: "",
      monitoring: "", updates: "", approval: "", included: "", ownership: "", transfer: ""
    },
    rules: {
      missedCallPercent: 15, responseMinutes: 10, minimumReviewCount: 30, minimumReviewRating: 4.5,
      websiteFromPoorPerformance: true, chatbotFromUnansweredWeb: true,
      crmFromMissingFollowup: true, adsAfterFoundation: true
    },
    discoveryCopy: {
      business: { name: "Your Business", title: "How does the business win work today?", description: "Give us the context we need to understand the commercial picture." },
      problems: { name: "What Is Not Working", title: "Where is the current setup letting you down?", description: "Choose every issue that is costing time, trust or opportunities." },
      outcome: { name: "What Must Change", title: "What must the new system achieve?", description: "Define the result that would make acting today worthwhile." }
    },
    language: { locale: "en", opportunityTerm: "Automatic", checkpointUnderstanding: "Have I understood the business correctly?", checkpointProblem: "Is this the main place opportunities are being lost?", checkpointRecommendation: "Does this plan address the problems you described?", checkpointProduct: "Would this be a meaningful improvement over what you have now?", checkpointDecision: "Does this solve what you wanted us to solve?", checkpointCertainty: "Before we discuss the investment, what still feels unclear or uncertain?" },
    paymentOptions: ["Pay in full", "Deposit + balance", "Configured installments"],
    checkoutLinks: { agreement: "", payment: "", onboarding: "" },
    opening: {
      step: 0, logo: "", buildAccessStartedAt: "", buildAccessExpiresAt: "", buildDeletedAt: "",
      contactEmail: REGEN_CONTACT_EMAIL, contactPhone: REGEN_CONTACT_PHONE
    },
    regenRoom: {
      url: "", qrImage: "", windowHours: 72, startedAt: "", expiresAt: "",
      attendanceConfirmed: false, linkReceived: false, giftCardChoice: "Amazon"
    },
    proposal: {
      title: REGEN_PROPOSAL_TITLE,
      reference: "",
      validDays: 14,
      preparedBy: "Kailan",
      preparedByTitle: "Owner",
      preparedByEmail: REGEN_CONTACT_EMAIL,
      preparedByPhone: REGEN_CONTACT_PHONE,
      introduction: REGEN_PROPOSAL_SUMMARY,
      scopeNote: "The work included in your plan is listed below.",
      outline: "This section explains what is included, how the parts work together and how we will get everything ready.",
      outlineHeading: "What we will do",
      timelineHeading: "Ready times and support",
      commercialHeading: "Price and payment",
      termsHeading: "Important details",
      responsibilitiesHeading: "What we need from you",
      exclusions: "We will discuss and approve any extra work before starting it. Delays caused by outside platforms, account checks or late replies are outside Most Wanted's control.",
      supportNote: "Your secure onboarding portal keeps everything organised while your dedicated support team builds, connects and supports the services in your plan.",
      paymentNote: "Your price and payment details are shown below. Work begins after the agreement is signed and the agreed payment is confirmed.",
      terms: "This plan is for the business named in this proposal. We will agree any extra work before starting it. Ready times begin after we receive the details and access listed below.",
      customerNeeds: REGEN_PROPOSAL_CUSTOMER_NEEDS,
      nextSteps: "Review the plan, confirm any changes, sign the agreement and make the agreed payment. Your secure onboarding portal will guide you from there.",
      nextStepsHeading: "Next steps",
      itemNotes: deepClone(REGEN_PROPOSAL_SERVICE_COPY),
      manualItems: []
    },
    packageConfig: deepClone(DEFAULT_PACKAGE_TEMPLATES),
    activePackage: { id: "digital-market-mastery", name: "Digital Market Mastery", quantity: 1, setup: 3495, monthly: 199, applied: true },
    combinedOffer: { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false },
    testimonialsConfig: [],
    serviceConfig: deepClone(SERVICES),
    demosConfig: deepClone(DEMOS),
    claims: [], caseStudies: [],
    launchStart: { timing: "Launch immediately", domain: "", contactPhone: "", contactEmails: "" },
    launchPlan: { tasks: [], serviceTimings: [], overallWindow: "", status: "draft", guaranteeVersion: "", launchStart: {} },
    pricing: {
      setup: 3495, monthly: 199, discount: 20, timing: "today", paymentOption: "$1 eligible launch commitment", deposit: 1, shownAt: "",
      catalogSetup: 0, catalogMonthly: 0, manualSetup: true, manualMonthly: true,
      serviceOverrides: {},
      dollarCommitmentEligible: true, dollarCommitmentSelected: true, academyRevealed: false
    },
    outcome: { type: "", cashCollected: 0, contractValue: 0, lossReason: "", followupDate: "", servicesSold: [], serviceQuantities: {}, serviceTimings: [], launchWindow: "", guaranteeVersion: "" },
    analytics: { events: [], priceFirstShownAt: "", discoveryCompletedAt: "" },
    serverSession: { id: "", revision: 0 }
  };
}

let state = defaultState();
let modal = null;
let drawer = null;
let saveTimer = null;
let apiTimer = null;
let syncPromise = null;
let apiRetryAfter = 0;
let activeShareToken = "";
let renderedScene = "";
let openingToShell = false;
let buildExpiryTimer = null;
let discoveryDetailsGroup = "";
let launchTasksGroup = "today";
let packageDraft = null;
let combinedOfferDraft = null;
let activeDemoOverlay = null;
let systemSelectionBeforeComplete = null;
let followUpTemplateEditing = "";

function scenes() {
  const sequence = (state.path === "ready" ? FAST_SCENES : MAIN_SCENES).slice();
  return state.mode === "prospect" ? sequence.filter(scene => scene !== "closerChecklist") : sequence;
}

function hasSupportCommitments() {
  return Object.values(state.support || {}).some(value => String(value || "").trim());
}

function guaranteeFullyConfigured() {
  const g = state.guarantee || {};
  const base = g.enabled && g.coreDefinition && g.deadlineRule && g.trigger &&
    Number(g.buyerCredit) > 0 && g.buyerCreditLabel && g.versionDate;
  const charity = g.charityEnabled && Number(g.mealQuantity) > 0 && g.charityName;
  return Boolean(base && charity);
}

function track(type, details = {}) {
  const event = { id: uid(), at: now(), type, scene: state.currentScene, path: state.path, details };
  state.analytics.events.push(event);
  if (state.analytics.events.length > 500) state.analytics.events.splice(0, state.analytics.events.length - 500);
  const global = JSON.parse(localStorage.getItem(ANALYTICS_KEY) || "[]");
  global.push({ prospectId: state.id, variant: state.variant, ...event });
  localStorage.setItem(ANALYTICS_KEY, JSON.stringify(global.slice(-3000)));
  sendServerEvent(event);
}

async function sendServerEvent(event) {
  if (!API_ENABLED) return;
  try {
    if (state.mode === "prospect" && activeShareToken) {
      const response = await fetch(`/api/shares/${encodeURIComponent(activeShareToken)}/events`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: event.type, scene: event.scene, payload: event.details, occurredAt: event.at })
      });
      if (!response.ok) pauseApiRequests();
      return;
    }
    const sessionId = state.serverSession?.id;
    const editToken = sessionId ? localStorage.getItem(`${STORAGE_PREFIX}edit:${sessionId}`) : "";
    if (!sessionId || !editToken || state.mode !== "presenter") return;
    const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/events`, {
      method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${editToken}` },
      body: JSON.stringify({ name: event.type, scene: event.scene, payload: event.details, occurredAt: event.at })
    });
    if (INVALID_SESSION_STATUSES.has(response.status)) clearInvalidServerSession(sessionId);
    else if (!response.ok) pauseApiRequests();
  } catch { /* Browser analytics remain available when the API is unavailable. */ }
}

function pauseApiRequests(delay = API_RETRY_DELAY_MS) {
  apiRetryAfter = Math.max(apiRetryAfter, Date.now() + delay);
}

function clearInvalidServerSession(sessionId = state.serverSession?.id) {
  try {
    if (sessionId) localStorage.removeItem(`${STORAGE_PREFIX}edit:${sessionId}`);
    if (!sessionId || state.serverSession?.id === sessionId) state.serverSession = { id: "", revision: 0 };
    flushPersistence();
  } catch { /* A clean in-memory session is still enough to stop the retry loop. */ }
}

function sanitizeStoredServerSession() {
  if (state.mode !== "presenter") return;
  const sessionId = String(state.serverSession?.id || "");
  if (!sessionId) return;
  const editToken = localStorage.getItem(`${STORAGE_PREFIX}edit:${sessionId}`);
  if (!CLIENT_SESSION_ID_PATTERN.test(sessionId) || !editToken) clearInvalidServerSession(sessionId);
}

function save({ sync = true } = {}) {
  state.updatedAt = now();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      localStorage.setItem(`${STORAGE_PREFIX}prospect:${state.id}`, JSON.stringify(state));
      localStorage.setItem(ACTIVE_KEY, state.id);
      const list = JSON.parse(localStorage.getItem(INDEX_KEY) || "[]");
      const next = [{ id: state.id, name: state.prospect.name, business: state.prospect.business, updatedAt: state.updatedAt }, ...list.filter(item => item.id !== state.id)].slice(0, 100);
      localStorage.setItem(INDEX_KEY, JSON.stringify(next));
    } catch (error) { console.warn("Local save unavailable", error); }
  }, 80);
  if (sync && state.mode === "presenter") scheduleApiSync();
}

function scheduleApiSync() {
  if (!API_ENABLED || Date.now() < apiRetryAfter) return;
  clearTimeout(apiTimer);
  apiTimer = setTimeout(() => syncServerSession(), 900);
}

function stateForServerSync() {
  const snapshot = deepClone(state);
  if (snapshot.analytics) snapshot.analytics.events = [];

  // Uploaded logos and QR codes remain available locally, but large data URLs
  // must never make the session API exceed the Worker's JSON body limit.
  const serializedSize = () => JSON.stringify(snapshot).length;
  if (serializedSize() > 700000 && String(snapshot.regenRoom?.qrImage || "").startsWith("data:")) {
    snapshot.regenRoom.qrImage = "";
  }
  if (serializedSize() > 700000 && String(snapshot.opening?.logo || "").startsWith("data:")) {
    snapshot.opening.logo = "";
  }
  return snapshot;
}

async function syncServerSession() {
  if (!API_ENABLED) return null;
  if (state.mode !== "presenter") return null;
  if (Date.now() < apiRetryAfter) return null;
  if (syncPromise) return syncPromise;
  syncPromise = (async () => {
    try {
      let sessionId = state.serverSession?.id;
      let editToken = sessionId ? localStorage.getItem(`${STORAGE_PREFIX}edit:${sessionId}`) : "";
      if (sessionId && (!CLIENT_SESSION_ID_PATTERN.test(sessionId) || !editToken)) {
        clearInvalidServerSession(sessionId);
        sessionId = "";
        editToken = "";
      }
      if (!sessionId || !editToken) {
        const syncState = stateForServerSync();
        const response = await fetch("/api/sessions", {
          method: "POST", headers: { "content-type": "application/json" },
          body: JSON.stringify({ state: syncState, prospectName: state.prospect.name, businessName: state.prospect.business, presenterPath: state.path, deckVersion: state.variant })
        });
        if (!response.ok) {
          pauseApiRequests();
          return null;
        }
        const payload = await response.json();
        if (!CLIENT_SESSION_ID_PATTERN.test(String(payload.session?.id || "")) || !payload.editToken) {
          pauseApiRequests();
          return null;
        }
        sessionId = payload.session.id;
        editToken = payload.editToken;
        state.serverSession = { id: sessionId, revision: payload.session.revision };
        localStorage.setItem(`${STORAGE_PREFIX}edit:${sessionId}`, editToken);
        flushPersistence();
        return payload.session;
      }
      const update = async () => {
        const syncState = stateForServerSync();
        return fetch(`/api/sessions/${encodeURIComponent(sessionId)}`, {
          method: "PATCH", keepalive: true,
          headers: { "content-type": "application/json", authorization: `Bearer ${editToken}` },
          body: JSON.stringify({ expectedRevision: state.serverSession.revision || 1, state: syncState, prospectName: state.prospect.name, businessName: state.prospect.business, presenterPath: state.path, status: serverOutcomeStatus() })
        });
      };
      let response = await update();
      if (response.status === 409) {
        const latest = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}`, { headers: { authorization: `Bearer ${editToken}` } });
        if (latest.ok) state.serverSession.revision = (await latest.json()).session.revision;
        response = await update();
      }
      if (INVALID_SESSION_STATUSES.has(response.status)) {
        clearInvalidServerSession(sessionId);
        return null;
      }
      if (!response.ok) {
        pauseApiRequests();
        return null;
      }
      const payload = await response.json();
      state.serverSession.revision = payload.session.revision;
      flushPersistence();
      return payload.session;
    } catch { return null; }
    finally { syncPromise = null; }
  })();
  return syncPromise;
}

function serverOutcomeStatus() {
  if (/payment|deposit|closed/i.test(state.outcome.type)) return "won";
  if (/lost/i.test(state.outcome.type)) return "lost";
  if (/follow/i.test(state.outcome.type)) return "follow_up";
  return "active";
}

async function loadInitialState() {
  const params = new URLSearchParams(location.search);
  const shareToken = params.get("share");
  if (shareToken && API_ENABLED) {
    try {
      const response = await fetch(`/api/shares/${encodeURIComponent(shareToken)}`);
      if (response.ok) {
        const payload = await response.json();
        state = mergeState(defaultState(), migrateLegacySnapshot(payload.share.snapshot));
        state.mode = "prospect";
        activeShareToken = shareToken;
        track("prospect_link_opened", { source: "server_share" });
        return;
      }
    } catch { /* A static copy can still use the encoded fallback below. */ }
  }
  const sessionParam = params.get("session");
  if (sessionParam && API_ENABLED) {
    const token = localStorage.getItem(`${STORAGE_PREFIX}edit:${sessionParam}`);
    if (token) {
      try {
        const response = await fetch(`/api/sessions/${encodeURIComponent(sessionParam)}`, { headers: { authorization: `Bearer ${token}` } });
        if (response.ok) {
          const payload = await response.json();
          const serverSnapshot = migrateLegacySnapshot(payload.session.state);
          let preferredSnapshot = serverSnapshot;
          try {
            const localSnapshot = migrateLegacySnapshot(JSON.parse(localStorage.getItem(`${STORAGE_PREFIX}prospect:${serverSnapshot.id}`) || "null"));
            const sameSession = localSnapshot?.serverSession?.id === payload.session.id;
            const localIsNewer = Date.parse(localSnapshot?.updatedAt || "") > Date.parse(serverSnapshot.updatedAt || "");
            if (sameSession && localIsNewer) preferredSnapshot = localSnapshot;
          } catch { /* The verified server snapshot remains authoritative when local recovery is unavailable. */ }
          state = mergeState(defaultState(), preferredSnapshot);
          state.serverSession = { id: payload.session.id, revision: payload.session.revision };
          state.mode = "presenter";
          return;
        }
      } catch { /* Fall through to browser persistence. */ }
    }
  }
  const hash = new URLSearchParams(location.hash.replace(/^#/, ""));
  if (hash.has("s")) {
    try {
      const decoded = decodeURIComponent(escape(atob(hash.get("s").replace(/-/g, "+").replace(/_/g, "/"))));
      state = mergeState(defaultState(), migrateLegacySnapshot(JSON.parse(decoded)));
      state.mode = "prospect";
      track("prospect_link_opened");
      return;
    } catch (error) { console.warn("Invalid shared state", error); }
  }
  const requested = params.get("prospect") || localStorage.getItem(ACTIVE_KEY);
  if (requested) {
    try {
      const local = JSON.parse(localStorage.getItem(`${STORAGE_PREFIX}prospect:${requested}`) || "null");
      if (local) state = mergeState(defaultState(), migrateLegacySnapshot(local));
    } catch { /* use a clean state */ }
    if (!localStorage.getItem(`${STORAGE_PREFIX}prospect:${requested}`)) {
      /* A browser without the edit token cannot open an editable server session. */
    }
  }
  if (params.get("mode") === "prospect") state.mode = "prospect";
}

function mergeState(base, incoming) {
  if (!incoming || typeof incoming !== "object") return base;
  const merged = { ...base, ...incoming };
  ["prospect", "heard", "leaks", "services", "demos", "checkpoints", "websiteLaunch", "guarantee", "support", "rules", "language", "discoveryCopy", "pricing", "outcome", "analytics", "launchStart", "launchPlan", "serviceConfig", "demosConfig", "serverSession", "checkoutLinks", "proposal", "opening", "regenRoom", "takeoutNotes", "questions", "activeTabs", "activePackage", "combinedOffer", "closerChecklist", "followUpTemplates"].forEach(key => {
    merged[key] = { ...base[key], ...(incoming[key] || {}) };
  });
  merged.packageConfig = (Array.isArray(incoming.packageConfig) ? incoming.packageConfig : base.packageConfig).map((item, index) => ({
    id: String(item?.id || `package-${index + 1}`),
    name: String(item?.name || `Package ${index + 1}`),
    setup: Math.max(0, Number(item?.setup) || 0),
    monthly: Math.max(0, Number(item?.monthly) || 0),
    allServices: Boolean(item?.allServices)
  }));
  merged.testimonialsConfig = (Array.isArray(incoming.testimonialsConfig) ? incoming.testimonialsConfig : base.testimonialsConfig).map((item, index) => ({
    id: String(item?.id || `testimonial-${index + 1}`),
    clientName: String(item?.clientName || ""),
    businessName: String(item?.businessName || ""),
    role: String(item?.role || ""),
    quote: String(item?.quote || ""),
    resultLabel: String(item?.resultLabel || ""),
    rating: Math.min(5, Math.max(1, Number(item?.rating) || 5)),
    videoUrl: String(item?.videoUrl || ""),
    enabled: Boolean(item?.enabled)
  }));
  Object.keys(base.services).forEach(id => { merged.services[id] = { ...base.services[id], ...(incoming.services?.[id] || {}) }; });
  Object.keys(base.demos).forEach(id => { merged.demos[id] = { ...base.demos[id], ...(incoming.demos?.[id] || {}) }; });
  Object.keys(base.serviceConfig).forEach(id => {
    merged.serviceConfig[id] = { ...base.serviceConfig[id], ...(incoming.serviceConfig?.[id] || {}) };
    delete merged.serviceConfig[id].timeline;
  });
  Object.keys(base.demosConfig).forEach(id => { merged.demosConfig[id] = { ...base.demosConfig[id], ...(incoming.demosConfig?.[id] || {}) }; });
  return merged;
}

function migrateLegacySnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== "object") return snapshot;
  const migrated = normalizePersistedPunctuation(deepClone(snapshot));
  const defaults = defaultState();
  const sourceSchema = Number(migrated.schema || 0);
  const legacyGuarantee = migrated.guarantee || {};
  if (!Object.prototype.hasOwnProperty.call(legacyGuarantee, "buyerCredit")) {
    migrated.guarantee = {
      ...defaults.guarantee,
      termsUrl: legacyGuarantee.termsUrl || "",
      proofUrl: legacyGuarantee.proofUrl || "",
      exclusions: legacyGuarantee.exclusions || defaults.guarantee.exclusions,
      versionDate: defaults.guarantee.versionDate,
      enabled: true
    };
  }
  if (Number(migrated.schema || 0) < 5) {
    migrated.guarantee = {
      ...defaults.guarantee,
      ...(migrated.guarantee || {}),
      deadlineRule: defaults.guarantee.deadlineRule,
      trigger: defaults.guarantee.trigger,
      clockStarts: "",
      clockPauses: "",
      exclusions: "",
      enabled: true
    };
    migrated.launchStart = { ...defaults.launchStart, ...(migrated.launchStart || {}) };
    migrated.launchPlan = { ...defaults.launchPlan, ...(migrated.launchPlan || {}), launchStart: { ...defaults.launchStart, ...(migrated.launchStart || {}) } };
  }
  migrated.launchStart = { ...defaults.launchStart, ...(migrated.launchStart || {}) };
  migrated.launchPlan = { ...defaults.launchPlan, ...(migrated.launchPlan || {}), launchStart: { ...defaults.launchStart, ...(migrated.launchStart || migrated.launchPlan?.launchStart || {}) } };
  if (migrated.guarantee?.coreDefinition === "the selected systems and Core Launch scope listed in the signed Launch Plan") migrated.guarantee.coreDefinition = defaults.guarantee.coreDefinition;
  if (migrated.guarantee?.deadlineRule === "the stated lead times shown in the signed Launch Plan") migrated.guarantee.deadlineRule = defaults.guarantee.deadlineRule;
  if (["Most Wanted exceeds a stated lead time for work within Most Wanted’s control.", "Most Wanted misses a ready time for work within Most Wanted’s control."].includes(migrated.guarantee?.trigger)) migrated.guarantee.trigger = defaults.guarantee.trigger;
  migrated.support = { ...defaults.support, ...(migrated.support || {}) };
  migrated.websiteLaunch = { ...defaults.websiteLaunch, ...(migrated.websiteLaunch || {}) };
  migrated.websiteLaunch.requestedChanges = Array.isArray(migrated.websiteLaunch.requestedChanges)
    ? migrated.websiteLaunch.requestedChanges.map(item => String(item || "").trim()).filter(Boolean)
    : [];
  if (["company", "outcome"].includes(migrated.currentScene)) migrated.currentScene = "intro";
  if (migrated.currentScene === "infrastructure") migrated.currentScene = "ecosystem";
  migrated.opening = { ...defaults.opening, ...(migrated.opening || {}) };
  migrated.opening.step = Math.max(0, Math.min(10, Number(migrated.opening.step) || 0));
  migrated.regenRoom = { ...defaults.regenRoom, ...(migrated.regenRoom || {}) };
  migrated.regenRoom.windowHours = normalizeRegenRoomWindowHours(migrated.regenRoom.windowHours);
  if (sourceSchema < 25) {
    migrated.regenRoom.startedAt = "";
    migrated.regenRoom.expiresAt = "";
    migrated.regenRoom.attendanceConfirmed = false;
    migrated.regenRoom.linkReceived = false;
  }
  if (["decision", "offer", "buildExpiry"].includes(migrated.currentScene)) migrated.currentScene = "regenRoom";
  migrated.proposal = { ...defaults.proposal, ...(migrated.proposal || {}) };
  if (/^(?:senior\s+)?growth specialist$/i.test(String(migrated.proposal.preparedByTitle || "").trim())) migrated.proposal.preparedByTitle = "Owner";
  migrated.followUpTemplates = { ...defaults.followUpTemplates, ...(migrated.followUpTemplates || {}) };
  ["emailBody", "textBody"].forEach(key => {
    migrated.followUpTemplates[key] = String(migrated.followUpTemplates[key] || "")
      .replace(/Kailan\s*[·-]\s*(?:Senior\s+)?Growth Specialist/gi, "Kailan - Owner")
      .replace(/Kailan\r?\n(?:Senior\s+)?Growth Specialist/gi, "Kailan - Owner");
  });
  if (migrated.proposal.introduction === REGEN_PROPOSAL_SUMMARY && migrated.regenRoom.windowHours !== 72) {
    migrated.proposal.introduction = REGEN_PROPOSAL_SUMMARY.replace("reserved for 72 hours", `reserved for ${migrated.regenRoom.windowHours} hours`);
  }
  migrated.proposal.itemNotes = migrated.proposal.itemNotes && typeof migrated.proposal.itemNotes === "object" ? migrated.proposal.itemNotes : {};
  migrated.proposal.manualItems = Array.isArray(migrated.proposal.manualItems)
    ? migrated.proposal.manualItems.map((item, index) => ({
      id: String(item?.id || `manual-${index}-${uid()}`), icon: String(item?.icon || "🧩"),
      name: String(item?.name || "Custom scope item"), description: String(item?.description || ""),
      deliverable: String(item?.deliverable || ""), window: String(item?.window || "To be agreed"),
      quantity: Math.max(1, Math.floor(Number(item?.quantity) || 1)),
      setup: Math.max(0, Number(item?.setup) || 0), monthly: Math.max(0, Number(item?.monthly) || 0)
    }))
    : [];
  if (!String(migrated.support.onboarding || "").trim()) migrated.support.onboarding = defaults.support.onboarding;
  migrated.checkpoints = { ...defaults.checkpoints, ...(migrated.checkpoints || {}) };
  Object.entries(CHECKPOINT_OPTIONS).forEach(([key, values]) => {
    if (!values.includes(migrated.checkpoints[key])) migrated.checkpoints[key] = "";
  });
  const incomingQuestions = migrated.questions && typeof migrated.questions === "object" ? migrated.questions : {};
  const incomingCategories = Array.isArray(incomingQuestions.categories) ? incomingQuestions.categories : defaults.questions.categories;
  migrated.questions = {
    activeCategory: String(incomingQuestions.activeCategory || defaults.questions.activeCategory),
    categories: incomingCategories.map((category, categoryIndex) => ({
      id: String(category?.id || `faq-${categoryIndex}-${uid()}`),
      name: String(category?.name || `Section ${categoryIndex + 1}`),
      emoji: String(category?.emoji || "💬"),
      description: String(category?.description || ""),
      items: (Array.isArray(category?.items) ? category.items : []).map((item, itemIndex) => ({
        id: String(item?.id || `question-${categoryIndex}-${itemIndex}-${uid()}`),
        emoji: String(item?.emoji || "💬"),
        question: String(item?.question || "New question"),
        answer: String(item?.answer || "Add the answer in Settings.")
      }))
    }))
  };
  if (!migrated.questions.categories.length) migrated.questions.categories = deepClone(defaults.questions.categories);
  if (!migrated.questions.categories.some(category => category.id === migrated.questions.activeCategory)) migrated.questions.activeCategory = migrated.questions.categories[0].id;
  migrated.leaks = { ...defaults.leaks, ...(migrated.leaks || {}) };
  Object.keys(OPPORTUNITY_LOSSES).forEach(id => {
    const legacyLoss = migrated.leaks[id] || {};
    migrated.leaks[id] = {
      ...defaults.leaks[id],
      ...legacyLoss,
      state: normalizeOpportunityState(legacyLoss.state)
    };
  });
  migrated.schema = defaults.schema;
  if (migrated.language?.checkpointProblem === "Does this look like where the most expensive leak is happening?") {
    migrated.language.checkpointProblem = defaults.language.checkpointProblem;
  }
  migrated.serviceConfig = { ...defaults.serviceConfig, ...(migrated.serviceConfig || {}) };
  Object.keys(SERVICES).forEach(id => {
    migrated.serviceConfig[id] = { ...defaults.serviceConfig[id], ...(migrated.serviceConfig[id] || {}), icon: SERVICES[id].icon };
    if (id === "seo") migrated.serviceConfig[id].name = SERVICES.seo.name;
    delete migrated.serviceConfig[id].timeline;
  });
  if (Array.isArray(migrated.prospect?.currentSystems)) {
    migrated.prospect.currentSystems = migrated.prospect.currentSystems.map(name => /^(SEO \+ AI SEO|Regular SEO \+ AI optim(?:isation|ization))$/i.test(String(name || "").trim()) ? SERVICES.seo.name : name);
  }
  migrated.services = { ...defaults.services, ...(migrated.services || {}) };
  Object.keys(SERVICES).forEach(id => {
    const item = { ...defaults.services[id], ...(migrated.services[id] || {}) };
    const requestedQuantity = Math.floor(Number(item.quantity));
    item.quantity = item.selected ? Math.max(1, Math.min(99, Number.isFinite(requestedQuantity) ? requestedQuantity : 1)) : 0;
    migrated.services[id] = item;
  });
  migrated.demosConfig = { ...defaults.demosConfig, ...(migrated.demosConfig || {}) };
  Object.keys(DEMOS).forEach(id => {
    migrated.demosConfig[id] = { ...defaults.demosConfig[id], ...(migrated.demosConfig[id] || {}), icon: DEMOS[id].icon };
  });
  const legacyPricing = migrated.pricing || {};
  const hasCurrentPricing = Object.prototype.hasOwnProperty.call(legacyPricing, "timing") &&
    Object.prototype.hasOwnProperty.call(legacyPricing, "catalogSetup") &&
    Object.prototype.hasOwnProperty.call(legacyPricing, "manualSetup");
  if (!hasCurrentPricing || Number(migrated.schema || 0) < 3) {
    migrated.pricing = {
      ...defaults.pricing,
      ...legacyPricing,
      discount: 20,
      timing: "today",
      catalogSetup: Number(legacyPricing.setup) || 0,
      catalogMonthly: Number(legacyPricing.monthly) || 0,
      manualSetup: Number(legacyPricing.setup) > 0,
      manualMonthly: Number(legacyPricing.monthly) > 0
    };
  }
  if (sourceSchema < 15) {
    migrated.pricing.dollarCommitmentEligible = true;
    migrated.pricing.dollarCommitmentSelected = true;
    migrated.pricing.deposit = 1;
    migrated.pricing.paymentOption = "$1 eligible launch commitment";
  }
  if (sourceSchema < 17) {
    const sceneMap = {
      opening: "intro", company: "intro", outcome: "intro", heard: "discovery",
      leaks: "cost", lowUrgency: "cost", ecosystem: "system", recommendation: "system", infrastructure: "system",
      website: "proof", support: "regen", launch: "regen", certainty: "decision", price: "economics",
      calculator: "economics", pledge: "guarantee", close: "decision", buildExpiry: "offer"
    };
    migrated.currentScene = sceneMap[migrated.currentScene] || migrated.currentScene;
    migrated.discoveryStep = Math.max(0, Math.min(2, Number(migrated.discoveryStep) || 0));
    migrated.activeTabs = { ...defaults.activeTabs, ...(migrated.activeTabs || {}) };
    migrated.guarantee = { ...defaults.guarantee, ...(migrated.guarantee || {}), charityName: "Feeding America" };
  }
  if (sourceSchema < 18) {
    migrated.prospect = { ...defaults.prospect, ...(migrated.prospect || {}) };
    migrated.prospect.targetSearchAreas = Array.isArray(migrated.prospect.targetSearchAreas)
      ? [...migrated.prospect.targetSearchAreas, "", ""].slice(0, 3)
      : ["", "", ""];
    migrated.prospect.commercialSources = {
      monthlyOpportunities: migrated.prospect.monthlyOpportunities !== "" ? "discovery" : "",
      averageJobRevenue: migrated.prospect.averageJobRevenue !== "" ? "discovery" : "",
      ...(migrated.prospect.commercialSources || {})
    };
  }
  if (sourceSchema < 19 && Number(migrated.pricing?.discount) === 30) migrated.pricing.discount = 20;
  if (sourceSchema < 20) {
    migrated.packageConfig = deepClone(defaults.packageConfig);
    migrated.activePackage = deepClone(defaults.activePackage);
  }
  if (sourceSchema < 21) migrated.testimonialsConfig = [];
  if (sourceSchema < 22 && Number(migrated.pricing?.discount) === 25) migrated.pricing.discount = 20;
  migrated.pricing.serviceOverrides = migrated.pricing?.serviceOverrides && typeof migrated.pricing.serviceOverrides === "object"
    ? migrated.pricing.serviceOverrides
    : {};
  migrated.outcome = { ...defaults.outcome, ...(migrated.outcome || {}), serviceQuantities: { ...(migrated.outcome?.serviceQuantities || {}) } };
  migrated.schema = defaults.schema;
  return migrated;
}

function inferHeard({ force = false } = {}) {
  const p = state.prospect;
  const assign = (key, value) => { if (force || !state.heard[key]) state.heard[key] = value; };
  assign("situation", [p.currentChannels.length ? `Jobs currently come through ${p.currentChannels.join(", ")}` : "We have not listed where jobs come from yet", p.currentSystems.length ? `Tools in use: ${p.currentSystems.join(", ")}` : "We have not listed the current website and tools yet"].join(". "));
  assign("objective", p.desiredJobsMonthly ? `Add ${p.desiredJobsMonthly} completed jobs each month` : p.growthGoal || p.successSelections.join(", ") || p.wishSelections.join(", ") || (p.desiredJobs ? `Add about ${p.desiredJobs} completed jobs within ${p.targetPeriod || "the target period"}` : "Agree on a clear growth goal"));
  assign("constraint", p.primaryProblem || p.blockerDetail || p.blockerSelections.join(", ") || "We still need to agree on the main problem");
  assign("opportunityVolume", p.monthlyOpportunities ? `About ${p.monthlyOpportunities} calls, forms or enquiries per month` : "Monthly calls and enquiries are not known yet");
  assign("capacity", p.capacityJobs ? `Room for about ${p.capacityJobs} more completed jobs per month` : "We have not said how many extra jobs the team can handle");
  assign("decision", p.decisionMaker ? `${p.decisionMaker}${p.approvers ? `; other people who must agree: ${p.approvers}` : ""}` : "We still need to confirm who makes the decision");
  assign("motive", [p.whyGoalMatters, p.whyNow].filter(Boolean).join(" ") || "We still need to confirm why this matters now");
  if (force || !Array.isArray(state.heard.searches) || !state.heard.searches.some(Boolean)) {
    state.heard.searches = [0, 1, 2].map(index => [p.targetSearches?.[index], p.targetSearchAreas?.[index]].map(value => String(value || "").trim()).filter(Boolean).join(" · "));
  }
}

function evaluateRecommendations({ preserveManual = true } = {}) {
  const p = state.prospect;
  const next = Object.fromEntries(Object.keys(SERVICES).map(id => [id, { status: "later", selected: false, quantity: 0, manual: false, reason: "Not needed based on what you told us." }]));
  const recommend = (id, reason) => Object.assign(next[id], { status: "recommended", selected: true, quantity: 1, reason });
  const optional = (id, reason) => Object.assign(next[id], { status: "optional", selected: false, quantity: 0, reason });

  const channels = p.currentChannels.join(" ").toLowerCase();
  const systems = p.currentSystems.join(" ").toLowerCase();
  const missed = Number(p.missedPercent);
  const rating = Number(p.reviewRating);
  const reviews = Number(p.reviewCount);
  const responseMinutes = parseFloat(p.averageResponseTime);

  if (["poor", "invisible"].includes(String(p.localVisibility).toLowerCase()) || (p.currentChannels.length > 0 && !channels.match(/google|search|maps/))) {
    recommend("seo", "Recommended because Google is not bringing in enough good local leads yet.");
  } else if (p.localVisibility === "strong" || channels.match(/google|search|maps/)) optional("seo", "Could help you keep and improve the Google visibility you already have.");

  if (state.rules.websiteFromPoorPerformance && (p.websitePerformance === "Poor" || p.websitePerformance === "No website" || (p.currentSystems.length > 0 && !systems.includes("website")))) {
    recommend("website", "Recommended because the current website is missing or is not turning enough visitors into callers.");
  } else if (p.websiteUrl || systems.includes("website")) optional("website", "Your current website may only need a few changes after we review it.");

  if (missed >= Number(state.rules.missedCallPercent) || String(p.missedHandling).toLowerCase() === "none" || (Number.isFinite(responseMinutes) && responseMinutes > Number(state.rules.responseMinutes))) {
    recommend("receptionist", `Recommended because ${missed ? `about ${missed}% of calls or enquiries may go unanswered` : "calls may not be answered while the team is working"}.`);
  } else optional("receptionist", "Could help if missed calls become a regular problem.");

  if (state.rules.chatbotFromUnansweredWeb && ["none", "slow", "unanswered"].includes(String(p.webEnquiryHandling).toLowerCase())) {
    recommend("chatbot", "Recommended because website or social messages may not be answered before customers move on.");
  } else if (!systems.match(/chat|web enquiry/) && (p.websiteUrl || state.services.website.selected)) {
    optional("chatbot", "Could answer website and social messages outside working hours.");
  }

  if ((reviews && reviews < Number(state.rules.minimumReviewCount)) || (rating && rating < Number(state.rules.minimumReviewRating)) || (p.currentSystems.length > 0 && !systems.match(/review/))) {
    recommend("reviews", `Recommended because ${reviews ? `the business has ${reviews} reviews` : "customers are not being asked for reviews consistently"}${rating ? ` with a ${rating} rating` : ""}.`);
  } else if (reviews || rating || systems.match(/review/)) optional("reviews", "Could help you keep the strong reputation you already have.");

  if (state.rules.crmFromMissingFollowup && (/none|manual|inconsistent/i.test(p.followupProcess) || (p.currentSystems.length > 0 && !systems.match(/crm/)))) {
    recommend("crm", "Recommended because there is no clear way to track and follow up every enquiry.");
  } else if (systems.match(/crm/) || p.followupProcess) optional("crm", "We should review the follow-up you already use before replacing it.");

  if (!state.rules.adsAfterFoundation || (Number(p.capacityJobs) > 0 && p.acquisitionWorking === "yes")) {
    optional("ads", "Could be added once the website, call handling and follow-up can handle more leads.");
  } else {
    Object.assign(next.ads, { status: "later", selected: false, reason: "Not recommended yet. First make sure the website, call handling and follow-up can handle the enquiries you already get." });
  }

  const automaticPriority = {
    website: p.websitePerformance === "No website" ? 100 : p.websitePerformance === "Poor" ? 88 : 60,
    receptionist: Math.min(99, 65 + Math.round(missed || 0)) + (String(p.missedHandling).toLowerCase() === "none" ? 20 : 0),
    seo: String(p.localVisibility).toLowerCase() === "invisible" ? 96 : String(p.localVisibility).toLowerCase() === "poor" ? 84 : 58,
    crm: String(p.followupProcess).toLowerCase() === "none" ? 90 : /inconsistent/i.test(p.followupProcess) ? 78 : 55,
    reviews: rating && rating < Number(state.rules.minimumReviewRating) ? 82 : reviews && reviews < Number(state.rules.minimumReviewCount) ? 72 : 52,
    chatbot: String(p.webEnquiryHandling).toLowerCase() === "none" || String(p.webEnquiryHandling).toLowerCase() === "unanswered" ? 76 : 54,
    ads: 40
  };
  Object.entries(next)
    .filter(([, item]) => item.status === "recommended")
    .sort(([leftId], [rightId]) => (automaticPriority[rightId] || 0) - (automaticPriority[leftId] || 0) || leftId.localeCompare(rightId))
    .slice(3)
    .forEach(([, item]) => Object.assign(item, {
      status: "optional", selected: false, quantity: 0,
      reason: `Could be added later. ${item.reason}`
    }));

  if (preserveManual) Object.entries(state.services).forEach(([id, current]) => {
    if (current.manual) next[id] = { ...next[id], status: current.status, selected: current.selected, quantity: current.selected ? normalizedServiceQuantity(current) : 0, manual: true, reason: current.reason || next[id].reason };
  });
  state.services = next;
  buildLaunchPlan();
  recalculatePrice();
  track("recommendations_evaluated", { recommended: selectedServices().map(service => service.id) });
  save();
  return deepClone(next);
}

function normalizedServiceQuantity(item) {
  if (!item?.selected) return 0;
  const quantity = Math.floor(Number(item.quantity));
  return Math.max(1, Math.min(99, Number.isFinite(quantity) ? quantity : 1));
}

function serviceQuantity(id) {
  return normalizedServiceQuantity(state.services[id]);
}

function selectedServices() {
  return Object.values(state.serviceConfig)
    .filter(service => state.services[service.id]?.selected)
    .map(service => ({
      ...service,
      setup: effectiveServicePrice(service, "setup"),
      monthly: effectiveServicePrice(service, "monthly"),
      quantity: serviceQuantity(service.id),
      timeToLive: serviceTimeToLive(service),
      launchGroup: serviceLaunchGroup(service)
    }));
}

function effectiveServicePrice(service, key) {
  const overrides = state.pricing?.serviceOverrides?.[service.id];
  if (overrides && Object.prototype.hasOwnProperty.call(overrides, key)) {
    return Math.max(0, Number(overrides[key]) || 0);
  }
  return Math.max(0, Number(service?.[key]) || 0);
}

const LAUNCH_PHASES = {
  today: { label: "Today", order: 0 },
  72: { label: "Next 3 Days", order: 1 },
  week: { label: "First Week", order: 2 },
  ongoing: { label: "Ongoing", order: 3 }
};

function serviceConfigEntry(serviceOrId) {
  if (typeof serviceOrId === "string") return state.serviceConfig[serviceOrId] || SERVICES[serviceOrId] || null;
  if (serviceOrId?.id) return state.serviceConfig[serviceOrId.id] || serviceOrId;
  return serviceOrId || null;
}

function serviceTimeToLive(serviceOrId) {
  const service = serviceConfigEntry(serviceOrId);
  return String(service?.window || "").trim() || "Ready time to be confirmed";
}

function parseServiceTimeToLive(serviceOrValue) {
  const value = typeof serviceOrValue === "string" && !state.serviceConfig[serviceOrValue]
    ? serviceOrValue
    : serviceTimeToLive(serviceOrValue);
  const lower = String(value).toLowerCase();
  if (/\b(same(?: business)? day|today|immediate(?:ly)?)\b/.test(lower)) {
    return { minDays: 0, maxDays: 1, businessDays: /business day/.test(lower) };
  }
  const numbers = [...String(value).matchAll(/\d+(?:\.\d+)?/g)].map(match => Number(match[0])).filter(Number.isFinite);
  if (!numbers.length) return null;
  const multiplier = /month/.test(lower) ? 22 : /week/.test(lower) ? 5 : /hour/.test(lower) ? 1 / 24 : 1;
  return {
    minDays: Math.max(0, numbers[0] * multiplier),
    maxDays: Math.max(0, numbers.at(-1) * multiplier),
    businessDays: /business day/.test(lower)
  };
}

function serviceLaunchGroup(serviceOrId) {
  const service = serviceConfigEntry(serviceOrId);
  const label = serviceTimeToLive(service).toLowerCase();
  const parsed = parseServiceTimeToLive(service);
  if (!parsed) return "ongoing";
  if (/\b(same(?: business)? day|today|immediate(?:ly)?)\b/.test(label)) return "today";
  if (service.id === "reviews") return "today";
  if (parsed.maxDays <= 3) return "72";
  if (parsed.maxDays <= 7) return "week";
  return "ongoing";
}

function selectedServiceTimings() {
  return selectedServices().map(service => ({
    id: service.id,
    name: service.name,
    icon: service.icon,
    quantity: service.quantity,
    timeToLive: serviceTimeToLive(service),
    launchGroup: serviceLaunchGroup(service),
    launchPhase: LAUNCH_PHASES[serviceLaunchGroup(service)]?.label || LAUNCH_PHASES.ongoing.label,
    customerRequirement: service.customer
  }));
}

function overallLaunchTiming() {
  const timings = selectedServiceTimings();
  if (!timings.length) return "Choose a service to see its ready time";
  const parsed = timings.map(item => ({ ...item, parsed: parseServiceTimeToLive(item.timeToLive) })).filter(item => item.parsed);
  if (parsed.length !== timings.length) return timings.map(item => `${item.name}: ${item.timeToLive}`).join(" · ");
  const firstDays = Math.min(...parsed.map(item => item.parsed.minDays));
  const dayLabel = parsed.every(item => item.parsed.businessDays) ? "business day" : "day";
  const formatDays = value => value <= 0 ? `the same ${dayLabel}` : `${number(value)} ${dayLabel}${value === 1 ? "" : "s"}`;
  const firstValue = firstDays <= 0 ? `the same ${dayLabel}` : `in as little as ${formatDays(firstDays)}`;
  return `First service can be ready ${firstValue}. All selected services can be ready within the timeframes given once we receive what we need.`;
}

function serviceTimingRows(services, context) {
  if (!services.length) return `<span class="fieldHelp">Choose a service to see its ready time.</span>`;
  return `<div class="serviceTimingList" data-testid="${esc(context)}-service-timings">${services.map(service => `<div class="serviceTimingRow" data-service-id="${service.id}" data-testid="${esc(context)}-service-ttl-${service.id}"><span><i>${service.icon}</i><b>${esc(service.name)}</b>${service.quantity > 1 ? `<small>Qty ${service.quantity}</small>` : ""}</span><strong>⏱️ Ready in ${esc(serviceTimeToLive(service))}</strong></div>`).join("")}</div>`;
}

function setServiceQuantity(id, rawQuantity, source = "launch-cart") {
  const item = state.services[id];
  if (!item) return false;
  const parsed = Math.floor(Number(rawQuantity));
  const quantity = Math.max(0, Math.min(99, Number.isFinite(parsed) ? parsed : 0));
  item.quantity = quantity;
  item.selected = quantity > 0;
  item.status = item.selected ? "recommended" : "optional";
  item.manual = true;
  item.reason ||= item.selected ? "Included in the plan." : "Available later if it becomes useful.";
  buildLaunchPlan();
  recalculatePrice();
  track("service_quantity_changed", { id, quantity, source });
  save();
  return true;
}

function calculateLeaks() {
  const p = state.prospect;
  const missed = Number(p.missedPercent);
  const revenueEstimate = calculateRevenueLossEstimate();
  const knownResponseValue = revenueEstimate.monthlyValue;
  const visibility = String(p.localVisibility || "").toLowerCase();
  const missedHandling = String(p.missedHandling || "").toLowerCase();
  const webHandling = String(p.webEnquiryHandling || "").toLowerCase();
  const websitePerformance = String(p.websitePerformance || "").toLowerCase();
  const followup = String(p.followupProcess || "").toLowerCase();
  const responseMinutes = Number(p.averageResponseTime);
  const rating = Number(p.reviewRating);
  const reviewCount = Number(p.reviewCount);
  const blockers = (p.blockerSelections || []).join(" ").toLowerCase();
  const channels = (p.currentChannels || []).join(" ").toLowerCase();
  const visibilityProblem = /inquir|maps|search|paid ads|lead service/.test(blockers) || (channels && !/google maps|google search|paid ads|website/.test(channels));
  const responseProblem = /miss calls|following up|workflow/.test(blockers) || missed > 0;
  const trustProblem = /website|review|reputation/.test(blockers) || /poor|no website|not making/.test(websitePerformance);
  const defaults = {
    visibility: visibilityProblem || ["poor", "invisible"].includes(visibility) ? "yes" : (["adequate", "strong"].includes(visibility) ? "no" : "unknown"),
    response: responseProblem || missedHandling === "none" || webHandling === "none" || webHandling === "unanswered" ? "yes" : ((responseMinutes > Number(state.rules.responseMinutes)) || /voicemail|call back|manual|sometimes/.test(missedHandling) || webHandling === "slow" ? "maybe" : ((missedHandling === "automated" || webHandling === "fast") ? "no" : "unknown")),
    trust: trustProblem ? "yes" : ((rating > 0 && rating < Number(state.rules.minimumReviewRating)) || (reviewCount > 0 && reviewCount < Number(state.rules.minimumReviewCount)) ? "maybe" : (websitePerformance === "strong" && rating >= Number(state.rules.minimumReviewRating) ? "no" : "unknown")),
    followup: followup === "none" ? "yes" : (/manual|inconsistent/.test(followup) ? "maybe" : (/automated|manual and consistent/.test(followup) ? "no" : "unknown"))
  };
  Object.entries(defaults).forEach(([id, status]) => {
    state.leaks[id] ||= { state: "unknown", note: "" };
    if (!state.leaks[id].manual) state.leaks[id].state = status;
    else state.leaks[id].state = normalizeOpportunityState(state.leaks[id].state);
  });
  return {
    knownResponseValue,
    monthly: knownResponseValue,
    annual: knownResponseValue !== null ? knownResponseValue * 12 : null,
    goalValue: revenueEstimate.goalValue,
    missedCallValue: revenueEstimate.missedCallValue,
    estimateMethod: revenueEstimate.method,
    estimateMethodLabel: revenueEstimate.methodLabel,
    estimateFormula: revenueEstimate.formula,
    states: defaults
  };
}

function calculateMonthlyGrowthTarget() {
  const jobs = Math.max(0, Number(state.prospect.desiredJobsMonthly) || 0);
  const averageJobValue = Math.max(0, Number(state.prospect.averageJobRevenue) || 0);
  return {
    jobs,
    averageJobValue,
    monthlyValue: jobs > 0 && averageJobValue > 0 ? jobs * averageJobValue : null
  };
}

function calculateRevenueLossEstimate() {
  const target = calculateMonthlyGrowthTarget();
  const opportunities = Math.max(0, Number(state.prospect.monthlyOpportunities) || 0);
  const missedPercent = Math.max(0, Math.min(100, Number(state.prospect.missedPercent) || 0));
  const closeRate = Math.max(0, Math.min(100, Number(state.prospect.closeRate) || 0));
  const averageJobValue = target.averageJobValue;
  const goalValue = target.monthlyValue;
  const missedCallValue = opportunities > 0 && missedPercent > 0 && closeRate > 0 && averageJobValue > 0
    ? opportunities * (missedPercent / 100) * (closeRate / 100) * averageJobValue
    : null;
  let monthlyValue = goalValue;
  let method = goalValue !== null ? "quick" : "none";
  if (missedCallValue !== null && goalValue === null) {
    monthlyValue = missedCallValue;
    method = "missed-calls";
  } else if (missedCallValue !== null && goalValue !== null) {
    monthlyValue = Math.max(goalValue, missedCallValue);
    method = "refined";
  }
  const methodLabel = method === "refined"
    ? "REFINED ESTIMATE"
    : method === "missed-calls"
      ? "MISSED-CALL ESTIMATE"
      : method === "quick"
        ? "QUICK TWO-NUMBER ESTIMATE"
        : "ADD TWO NUMBERS TO CALCULATE";
  const formula = method === "refined"
    ? `Uses the stronger supported monthly gap: ${money(goalValue)} growth target or ${money(missedCallValue)} missed-call leakage.`
    : method === "missed-calls"
      ? `${number(opportunities)} enquiries × ${number(missedPercent)}% missed × ${number(closeRate)}% close rate × ${money(averageJobValue)}.`
      : method === "quick"
        ? `${number(target.jobs)} additional job${target.jobs === 1 ? "" : "s"} × ${money(averageJobValue)} average job value.`
        : "Enter the average job value and additional jobs wanted each month.";
  return {
    ...target,
    goalValue,
    missedCallValue,
    monthlyValue,
    annualValue: monthlyValue !== null ? monthlyValue * 12 : null,
    method,
    methodLabel,
    formula
  };
}

function priceSummary() {
  const standardSetup = Math.max(0, Number(state.pricing.setup) || 0);
  const monthly = Math.max(0, Number(state.pricing.monthly) || 0);
  const configuredDiscount = Number(state.pricing.discount);
  const discount = state.pricing.timing === "after" || configuredDiscount <= 0 ? 0 : Math.min(20, Math.max(1, configuredDiscount));
  const saving = standardSetup * (discount / 100);
  const effectiveSetup = standardSetup - saving;
  const standardFirstYear = standardSetup + (monthly * 12);
  const effectiveFirstYear = effectiveSetup + (monthly * 12);
  const dollarCommitment = state.pricing.timing !== "after" && state.pricing.dollarCommitmentEligible && state.pricing.dollarCommitmentSelected;
  const configuredDeposit = Math.max(0, Number(state.pricing.deposit) || 0);
  const downPayment = dollarCommitment ? Math.min(1, effectiveSetup || 1) : Math.min(effectiveSetup, configuredDeposit || effectiveSetup);
  return { standardSetup, monthly, discount, saving, effectiveSetup, standardFirstYear, effectiveFirstYear, downPayment, remainingSetup: Math.max(0, effectiveSetup - downPayment), timing: state.pricing.timing || "today" };
}

function priceLineItems() {
  return selectedServices().map(service => {
    const unitSetup = Math.max(0, Number(service.setup) || 0);
    const unitMonthly = Math.max(0, Number(service.monthly) || 0);
    return {
      ...service,
      unitSetup,
      unitMonthly,
      setup: unitSetup * service.quantity,
      monthly: unitMonthly * service.quantity
    };
  });
}

function calculateBreakEven() {
  const p = state.prospect;
  const firstYear = priceSummary().effectiveFirstYear;
  const gross = Number(p.grossProfitPerJob);
  const revenue = Number(p.averageJobRevenue);
  const basis = gross > 0 ? "gross profit" : revenue > 0 ? "revenue equivalent" : "unknown";
  const perJob = gross || revenue || 0;
  const jobs = perJob ? firstYear / perJob : 0;
  const scenario = state.calculatorScenario;
  const yearlyJobs = scenario === "quarterly1" ? 4 : scenario === "monthly1" ? 12 : scenario === "monthly2" ? 24 : Number(state.customScenarioJobs) * 12;
  const yearlyValue = yearlyJobs * perJob;
  const months = yearlyJobs && jobs ? (jobs / yearlyJobs) * 12 : 0;
  return { firstYear, basis, perJob, jobs, yearlyJobs, yearlyValue, months };
}

function recalculatePrice() {
  const selected = selectedServices();
  const setup = selected.reduce((sum, service) => sum + Number(service.setup || 0) * service.quantity, 0);
  const monthly = selected.reduce((sum, service) => sum + Number(service.monthly || 0) * service.quantity, 0);
  state.pricing.catalogSetup = setup;
  state.pricing.catalogMonthly = monthly;
  if (state.combinedOffer?.applied) {
    const selectedIds = new Set(selected.map(service => service.id));
    const combinedIds = (state.combinedOffer.serviceIds || []).filter(id => selectedIds.has(id));
    if (combinedIds.length < 2) {
      state.combinedOffer = { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false };
      state.pricing.manualSetup = false;
      state.pricing.manualMonthly = false;
    } else {
      state.combinedOffer.serviceIds = combinedIds;
      const included = new Set(combinedIds);
      const outside = selected.filter(service => !included.has(service.id));
      state.pricing.setup = Math.max(0, Number(state.combinedOffer.setup) || 0) + outside.reduce((sum, service) => sum + Number(service.setup || 0) * service.quantity, 0);
      state.pricing.monthly = Math.max(0, Number(state.combinedOffer.monthly) || 0) + outside.reduce((sum, service) => sum + Number(service.monthly || 0) * service.quantity, 0);
      state.pricing.manualSetup = true;
      state.pricing.manualMonthly = true;
      return;
    }
  }
  if (!state.pricing.manualSetup) state.pricing.setup = setup;
  if (!state.pricing.manualMonthly) state.pricing.monthly = monthly;
}

function buildLaunchPlan() {
  const selected = selectedServices();
  const scope = id => {
    const quantity = selected.find(item => item.id === id)?.quantity || 0;
    return quantity > 1 ? ` (${quantity} setups)` : "";
  };
  const task = (group, name, owner, duration, dependency, guaranteed = false, metadata = {}) => ({ id: metadata.id || uid(), group, name, owner, duration, dependency, guaranteed, status: "not started", ...metadata });
  const tasks = [
    task("today", "Agreement and payment", "Customer", "10 minutes", "Final plan approved"),
    task("today", "Send your details through the secure onboarding portal", "Customer", "10–15 minutes", "Agreement signed"),
    task("72", "Your support team reviews the setup details", "Most Wanted", "Within 3 days", "Setup details submitted"),
    task("72", `Confirm when work should start: ${state.launchStart.timing || "Launch immediately"}`, "Most Wanted + Customer", "5 minutes", "Setup details received")
  ];
  if (state.launchStart.domain) tasks.push(task("72", `Connect the confirmed domain: ${state.launchStart.domain}`, "Most Wanted", "Within 3 days", "Domain access received"));
  if (state.launchStart.contactPhone || state.launchStart.contactEmails) tasks.push(task("today", "Confirm who should receive launch updates", "Most Wanted", "Same business day", "Setup details submitted"));
  selected.forEach(service => {
    const timeToLive = serviceTimeToLive(service);
    const launchGroup = serviceLaunchGroup(service);
    tasks.push(task(
      launchGroup,
      `${service.deliverable || `${service.name} setup`}${scope(service.id)}`,
      "Most Wanted",
      timeToLive,
      service.customer || "We have the details we need",
      guaranteeFullyConfigured(),
      { id: `service-${service.id}`, serviceId: service.id, timeToLive, timingSource: `serviceConfig.${service.id}.window` }
    ));
  });
  tasks.push(task("ongoing", "Support, agreed changes and ongoing improvements", "Most Wanted", "Ongoing", "Support plan has started", false));
  state.launchPlan.tasks = tasks;
  state.launchPlan.status = "draft";
  state.launchPlan.generatedAt = now();
  state.launchPlan.serviceTimings = selectedServiceTimings();
  state.launchPlan.overallWindow = overallLaunchTiming();
  state.launchPlan.guaranteeVersion = guaranteeFullyConfigured() ? state.guarantee.versionDate : "";
  state.launchPlan.launchStart = deepClone(state.launchStart);
}

function qualifiedClaim(claim) {
  return Boolean(claim.displayEnabled && claim.verified && claim.text && claim.source && claim.metricDefinition && claim.lastVerified && (claim.publicLink || claim.privateLink));
}

function qualifiedCaseStudy(study) {
  return Boolean(study.displayEnabled && study.permissionStatus === "approved" && study.customerName && study.industry && study.startingSituation && study.systemsInstalled && study.baselineEvidence && study.resultEvidence && study.metricDefinition && study.dateRange && study.sourceLinks && study.verifiedBy);
}

async function loadPublicClaims() {
  if (!API_ENABLED) return;
  try {
    const response = await fetch("/api/claims");
    if (!response.ok) return;
    const raw = await response.text();
    if (!raw.trim()) return;
    const payload = JSON.parse(raw);
    const claims = Array.isArray(payload?.claims) ? payload.claims : [];
    const remote = claims.map(claim => ({
      id: claim.id, text: claim.claimText, verified: true, displayEnabled: true,
      source: claim.sourceEvidence || "Verified private evidence", metricDefinition: claim.metricDefinition,
      lastVerified: claim.lastVerifiedDate, sourceVisibility: claim.sourceVisibility,
      publicLink: claim.sourceUrl || "", privateLink: claim.sourceVisibility === "private" ? "verified-private-source" : ""
    }));
    if (remote.length) state.claims = remote;
  } catch { /* Claims remain hidden when the verified-claims API is unavailable. */ }
}

function sharePayload() {
  buildLaunchPlan();
  const copy = deepClone(state);
  copy.mode = "prospect";
  copy.launchTiming = {
    overallWindow: overallLaunchTiming(),
    services: deepClone(selectedServiceTimings())
  };
  delete copy.notes;
  delete copy.internalNotes;
  delete copy.takeoutNotes;
  delete copy.analytics;
  delete copy.outcome;
  delete copy.serverSession;
  delete copy.packageConfig;
  copy.activePackage = copy.activePackage?.applied ? {
    name: String(copy.activePackage.name || ""),
    quantity: Math.max(1, Number(copy.activePackage.quantity) || 1),
    applied: true
  } : { name: "", quantity: 1, applied: false };
  copy.combinedOffer = copy.combinedOffer?.applied ? {
    name: String(copy.combinedOffer.name || ""),
    serviceIds: Array.isArray(copy.combinedOffer.serviceIds) ? copy.combinedOffer.serviceIds.map(String) : [],
    applied: true
  } : { name: "", serviceIds: [], applied: false };
  copy.pricing = {
    setup: Number(copy.pricing.setup) || 0,
    monthly: Number(copy.pricing.monthly) || 0,
    discount: Number(copy.pricing.discount) || 0,
    timing: copy.pricing.timing === "after" ? "after" : "today",
    paymentOption: copy.pricing.paymentOption || "pay in full",
    deposit: Number(copy.pricing.deposit) || 0
  };
  copy.guarantee = {
    enabled: guaranteeFullyConfigured(),
    title: copy.guarantee.title,
    coreDefinition: copy.guarantee.coreDefinition,
    deadlineRule: copy.guarantee.deadlineRule,
    trigger: copy.guarantee.trigger,
    buyerCredit: Number(copy.guarantee.buyerCredit) || 0,
    buyerCreditLabel: copy.guarantee.buyerCreditLabel,
    charityEnabled: Boolean(copy.guarantee.charityEnabled),
    mealQuantity: Number(copy.guarantee.mealQuantity) || 0,
    charityName: copy.guarantee.charityName,
    versionDate: copy.guarantee.versionDate,
    termsUrl: copy.guarantee.termsUrl || "",
    proofUrl: copy.guarantee.proofUrl || ""
  };
  copy.claims = copy.claims.filter(qualifiedClaim).map(claim => claim.sourceVisibility === "private" ? { ...claim, source: "Evidence verified privately", privateLink: "", publicLink: "" } : claim);
  copy.caseStudies = copy.caseStudies.filter(qualifiedCaseStudy);
  return copy;
}

function takeoutLine(lines, label, value) {
  const values = Array.isArray(value) ? value.filter(item => String(item ?? "").trim()) : [value];
  const text = values.map(item => String(item ?? "").trim()).filter(Boolean).join(", ");
  if (text) lines.push(`${label}: ${text}`);
}

function takeoutSection(lines, title) {
  if (lines.length && lines.at(-1) !== "") lines.push("");
  lines.push(title.toUpperCase());
}

function takeoutAddSection(lines, title, writeSection) {
  const section = [];
  writeSection(section);
  if (!section.length) return;
  takeoutSection(lines, title);
  lines.push(...section);
}

function callNotesSummary() {
  const p = state.prospect || {};
  const price = priceSummary();
  const selected = selectedServices();
  const hasLeakInputs = Boolean(
    (p.blockerSelections || []).length || p.websitePerformance || p.missedHandling || p.reviewsProcess ||
    p.missedPercent !== "" || p.closeRate !== "" || p.monthlyOpportunities !== "" || p.averageJobRevenue !== "" || p.desiredJobsMonthly !== ""
  );
  const leakResult = hasLeakInputs ? calculateLeaks() : null;
  const urgency = hasLeakInputs ? opportunityUrgencyScores(leakResult) : [];
  const overallUrgency = urgency.length ? Math.round(urgency.reduce((sum, item) => sum + item.score, 0) / urgency.length) : null;
  const lines = ["MOST WANTED CALL NOTES", `Prepared: ${proposalDate()}`];

  takeoutAddSection(lines, "Prospect", section => {
    takeoutLine(section, "Prospect name", p.name);
    takeoutLine(section, "Business", p.business);
    takeoutLine(section, "Custom website / demo", p.demoUrl || p.websiteUrl);
  });

  takeoutAddSection(lines, "Discovery - Where revenue comes from", section => {
    takeoutLine(section, "Current revenue sources", p.currentChannels);
    takeoutLine(section, "What the business sells", p.industry);
    takeoutLine(section, "Why customers choose them", p.competitiveEdge);
    takeoutLine(section, "Has a current website", p.hasWebsite);
    takeoutLine(section, "Calls and enquiries per month", p.monthlyOpportunities);
    takeoutLine(section, "Average pre-cost job value", p.averageJobRevenue !== "" ? money(p.averageJobRevenue) : "");
  });

  takeoutAddSection(lines, "Discovery - Where revenue is leaking", section => {
    takeoutLine(section, "Problems selected", p.blockerSelections);
    takeoutLine(section, "Current website performance", p.websitePerformance);
    takeoutLine(section, "Missed-call handling", p.missedHandling);
    takeoutLine(section, "Google review process", p.reviewsProcess);
    takeoutLine(section, "Calls missed or unanswered", p.missedPercent !== "" ? `${number(p.missedPercent)}%` : "");
  });

  takeoutAddSection(lines, "Discovery - What they want to solve", section => {
    takeoutLine(section, "Desired outcomes", p.wishSelections);
    takeoutLine(section, "Additional jobs wanted each month", p.desiredJobsMonthly);
    takeoutLine(section, "Why the goal matters", p.whyGoalMatters);
    takeoutLine(section, "Why now", p.whyNow);
  });

  takeoutAddSection(lines, "Commercial summary", section => {
    if (overallUrgency !== null) takeoutLine(section, "Overall revenue leakage score", `${overallUrgency}/100`);
    takeoutLine(section, "Biggest gap", state.leaks?.primary ? opportunityLossLabel(state.leaks.primary) : "");
    takeoutLine(section, "Possible revenue leaking per month", leakResult?.knownResponseValue !== null && leakResult?.knownResponseValue !== undefined ? money(leakResult.knownResponseValue) : "");
    const growthTarget = calculateMonthlyGrowthTarget();
    takeoutLine(section, "Monthly revenue target from additional jobs", growthTarget.monthlyValue !== null ? money(growthTarget.monthlyValue) : "");
  });

  takeoutAddSection(lines, "Final solution", section => {
    if (state.activePackage?.applied) takeoutLine(section, "Package", `${state.activePackage.name || "Configured package"} · Qty ${Math.max(1, Number(state.activePackage.quantity) || 1)}`);
    if (state.combinedOffer?.applied) {
      const combinedNames = (state.combinedOffer.serviceIds || []).map(id => state.serviceConfig[id]?.name).filter(Boolean);
      takeoutLine(section, "Combined offer", `${state.combinedOffer.name || "Combined offer"}${combinedNames.length ? ` · ${combinedNames.join(" + ")}` : ""} · One agreed price`);
    }
    selected.forEach(service => {
      takeoutLine(section, service.name, service.quantity > 1 ? `Qty ${service.quantity}` : "Selected");
    });
  });

  takeoutAddSection(lines, "Offer and pricing", section => {
    if (price.standardSetup > 0) takeoutLine(section, "Setup price", money(price.standardSetup));
    if (price.monthly > 0) takeoutLine(section, "Monthly", money(price.monthly));
    takeoutLine(section, "Payment option", state.pricing?.paymentOption);
  });

  takeoutAddSection(lines, "Prepared work", section => {
    takeoutLine(section, "Custom website / concept", p.demoUrl || p.websiteUrl);
    takeoutLine(section, "Website changes requested", state.websiteLaunch?.requestedChanges);
  });

  takeoutAddSection(lines, "Decision and outcome", section => {
    takeoutLine(section, "Recorded outcome", state.outcome?.type);
    takeoutLine(section, "Amount paid today", Number(state.outcome?.cashCollected) ? money(state.outcome.cashCollected) : "");
    takeoutLine(section, "Contract value", Number(state.outcome?.contractValue) ? money(state.outcome.contractValue) : "");
    takeoutLine(section, "Outcome detail", state.outcome?.lossReason);
    takeoutLine(section, "Follow-up date", state.outcome?.followupDate);
    takeoutLine(section, `${regenRoomWindowLabel()} Most Wanted Room closes`, state.regenRoom?.expiresAt ? new Date(state.regenRoom.expiresAt).toLocaleString() : "");
    takeoutLine(section, "Most Wanted Room attendance confirmed", state.regenRoom?.attendanceConfirmed ? "Yes" : "");
    takeoutLine(section, "Gift card choice", state.regenRoom?.attendanceConfirmed ? state.regenRoom?.giftCardChoice : "");
  });

  takeoutAddSection(lines, "Private notes", section => {
    takeoutLine(section, "Prospect notes", state.takeoutNotes?.prospect);
    takeoutLine(section, "Offer notes", state.takeoutNotes?.offer);
    takeoutLine(section, "Outcome notes", state.takeoutNotes?.outcome);
    takeoutLine(section, "Session notes", state.notes);
    takeoutLine(section, "Internal notes", state.internalNotes);
  });

  return lines.join("\n");
}

function followUpCommercialValues() {
  const price = priceSummary();
  const monthlyLeak = calculateRevenueLossEstimate().monthlyValue;
  const hasMonthlyProblem = monthlyLeak !== null && Number(monthlyLeak) > 0;
  const emails = String(state.launchStart?.contactEmails || "").split(/[\s,;]+/).map(value => value.trim()).filter(value => value.includes("@"));
  return {
    prospectName: String(state.prospect?.name || "").trim() || "Prospect",
    monthlyProblem: hasMonthlyProblem ? money(monthlyLeak) : "",
    monthlyProblemDisplay: hasMonthlyProblem ? money(monthlyLeak) : "Leaving money on the table",
    // Follow-up happens after the live call. The 20% saving is deliberately
    // call-only, so every post-call message must use the standard setup price.
    offerCost: money(price.standardSetup),
    email: emails[0] || "",
    phone: String(state.launchStart?.contactPhone || "").replace(/[^0-9+]/g, ""),
    roomUrl: String(state.regenRoom?.url || "").trim(),
    roomExpiry: state.regenRoom?.expiresAt ? new Date(state.regenRoom.expiresAt).toLocaleString() : `${regenRoomDurationLabel()} from the meeting`
  };
}

function followUpEmailSubject() {
  return String(state.followUpTemplates?.emailSubject || "").trim() || `Your site, ${regenRoomWindowLabel()} decision window and Most Wanted Room access`;
}

function regenRoomZoneLabel(timeZone, daylightLabel, standardLabel, at = new Date()) {
  try {
    const label = new Intl.DateTimeFormat("en-US", {
      timeZone,
      timeZoneName: "short"
    }).formatToParts(at).find(part => part.type === "timeZoneName")?.value;
    if (label === daylightLabel || label === standardLabel) return label;
  } catch {}
  return standardLabel;
}

function regenRoomTimeZones(at = new Date()) {
  return [
    { id: "pacific", label: regenRoomZoneLabel("America/Los_Angeles", "PDT", "PST", at), time: "11:00 AM–12:00 PM" },
    { id: "mountain", label: regenRoomZoneLabel("America/Denver", "MDT", "MST", at), time: "12:00–1:00 PM" },
    { id: "central", label: regenRoomZoneLabel("America/Chicago", "CDT", "CST", at), time: "1:00–2:00 PM", primary: true },
    { id: "eastern", label: regenRoomZoneLabel("America/New_York", "EDT", "EST", at), time: "2:00–3:00 PM" }
  ];
}

function followUpEmailText() {
  const custom = String(state.followUpTemplates?.emailBody || "").trim();
  if (custom) return custom;
  const { prospectName, monthlyProblem, roomUrl, roomExpiry } = followUpCommercialValues();
  const duration = regenRoomDurationLabel();
  const roomTimes = regenRoomTimeZones().map(zone => `- ${zone.time} ${zone.label}`).join("\n");
  const problemSentence = monthlyProblem
    ? `We identified a ${monthlyProblem} per month problem in your business’s performance that we would solve for you, starting with the launch within 3 working days.`
    : "We identified that your business is leaving money on the table, and we would start solving that problem with the launch within 3 working days.";
  return `Dear ${prospectName},

Your prepared website and production slot are reserved for ${duration}. At the end of that window, the completed site is permanently deleted if we have not received a commitment to move forward.

Approximately six focused hours of human design and engineering have already been invested specifically into your business. We would genuinely rather see that work launched than deleted.

YOUR PRIVATE MOST WANTED ROOM

If you need time, have a final question or want another decision-maker involved, join our Most Wanted Room during the next ${duration}:

${roomTimes}

There is no fixed appointment inside that hour. We set it aside to speak privately, show the site again, discuss doubts, modify the offer or launch together. It is not a pressure room.

Bring your spouse, partner or another decision-maker, even if they currently think the answer is no. We will answer them directly and respect whichever decision you make.

Attend for ten minutes and we will email you a $10 gift card of your choice, immediately usable, even if you decide not to launch. There are no conditions. Choose from Amazon, Walmart, Target, Apple, The Home Depot, Starbucks, Dunkin’ or Subway.

${roomUrl ? `Most Wanted Room: ${roomUrl}` : "Your Most Wanted Room link has been sent separately."}

Outside the dedicated hour, you may join the same room and wait 5–10 minutes. There is roughly a 50/50 chance we can step in; availability is guaranteed only during the hour above.

SITE-DELETION DEADLINE

${roomExpiry}

${problemSentence}

Your contract and secure payment link have been sent separately. If you decide to move forward, complete both and reply to this email. If you need us, contact Kailan - Owner.

Kailan - Owner
Most Wanted Digital

10529765 (Delaware)
1111B S Governors Ave, Suite 87498
Dover, DE 19904, US
Most Wanted`;
}

function followUpTextMessage() {
  const custom = String(state.followUpTemplates?.textBody || "").trim();
  if (custom) return custom;
  const { prospectName, monthlyProblem, offerCost, roomUrl } = followUpCommercialValues();
  const duration = regenRoomDurationLabel();
  const problemPhrase = monthlyProblem
    ? `leaving approximately ${monthlyProblem}/month on the table`
    : "leaving money on the table";
  return `Hey ${prospectName}, Kailan - Owner from Most Wanted here.

Your prepared site is reserved for ${duration}, then permanently deleted.

The site is already prepared, with approximately six focused hours of human design and engineering invested specifically into ${prospectName}.

Based on what we went through, you’re currently ${problemPhrase}, versus ${offerCost} to get everything launched.

If you need more clarity or another decision-maker involved, join the Most Wanted Room during the next ${duration}: 2–3 PM EDT / 1–2 PM CDT / 12–1 PM MDT / 11 AM–12 PM PDT.${roomUrl ? ` ${roomUrl}` : ""}

Ten minutes earns an unconditional $10 gift card, even if you say no. Bring anyone involved in the decision. We can answer questions, show the site again, modify the offer or launch without pressure.

Kailan - Owner`;
}

function followUpMessageModal(type) {
  const emailMode = type === "email";
  const editing = followUpTemplateEditing === type;
  const values = followUpCommercialValues();
  const title = emailMode ? "Email Follow-Up" : "Text Follow-Up";
  const text = emailMode ? followUpEmailText() : followUpTextMessage();
  const destination = emailMode ? (values.email || "Add an email in Launch Start") : (values.phone || "Add a phone number in Launch Start");
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal followUpMessageModal" data-testid="follow-up-${emailMode ? "email" : "text"}">
    <header class="modalHead"><div><small>${esc(regenRoomWindowLabel().toUpperCase())} MOST WANTED ROOM COMMUNICATION</small><h2>${title}</h2><p>Prepared from the client details, Lost Revenue calculation and current Investment.</p></div><button class="iconBtn" data-action="close-overlay" aria-label="Close ${title}">×</button></header>
    <div class="modalBody followUpMessageBody">
      <aside class="followUpMessageFacts"><article><span>PROSPECT</span><b>${esc(values.prospectName)}</b></article><article><span>MONTHLY PROBLEM</span><b>${esc(values.monthlyProblemDisplay)}</b></article><article><span>POST-CALL PRICE</span><b>${esc(values.offerCost)}</b></article><article><span>${emailMode ? "EMAIL TO" : "TEXT TO"}</span><b>${esc(destination)}</b></article></aside>
      <section class="followUpMessageEditor ${emailMode ? "email" : "text"} ${editing ? "isEditing" : ""}">${emailMode ? `<label>Subject<input ${editing ? 'data-bind="followUpTemplates.emailSubject"' : "readonly"} value="${esc(followUpEmailSubject())}" data-testid="follow-up-email-subject"></label>` : ""}<label>${emailMode ? "Email body" : "Text message"}<textarea ${editing ? `data-bind="followUpTemplates.${emailMode ? "emailBody" : "textBody"}"` : "readonly"} data-testid="follow-up-${emailMode ? "email" : "text"}-body">${esc(text)}</textarea></label>${editing ? `<p class="fieldHelp">Edit this prospect’s saved template. It stays attached to this client record.</p>` : ""}</section>
    </div>
    <footer class="modalFoot"><button class="ghostBtn" data-action="close-overlay">Close</button>${editing ? `<button class="primaryBtn" data-action="save-follow-up-template" data-type="${type}">Save Template</button>` : `<button class="ghostBtn" data-action="edit-follow-up-template" data-type="${type}">Edit Template</button><button class="primaryBtn" data-action="copy-follow-up-${emailMode ? "email" : "text"}">Copy ${emailMode ? "Email" : "Text"}</button>`}</footer>
  </section></div>`;
}

function clearEditableProspectAddress() {
  const url = new URL(location.href);
  ["session", "prospect", "share", "mode"].forEach(key => url.searchParams.delete(key));
  url.hash = "";
  history.replaceState({}, "", `${url.pathname}${url.search}`);
}

function startNewProspect() {
  // Stop a pending save/sync from the previous call and detach the new record
  // from any editable session URL before creating its fresh state.
  const retainedServicePrices = Object.fromEntries(Object.entries(state.serviceConfig || {}).map(([id, service]) => [id, {
    setup: Math.max(0, Number(service?.setup) || 0),
    monthly: Math.max(0, Number(service?.monthly) || 0)
  }]));
  const retainedPackages = deepClone(state.packageConfig || DEFAULT_PACKAGE_TEMPLATES);
  const retainedRegenRoom = {
    url: String(state.regenRoom?.url || ""),
    qrImage: String(state.regenRoom?.qrImage || ""),
    windowHours: normalizeRegenRoomWindowHours(state.regenRoom?.windowHours)
  };
  clearTimeout(saveTimer);
  clearTimeout(apiTimer);
  clearEditableProspectAddress();
  modal = "setup";
  drawer = null;
  activeShareToken = "";
  state = defaultState();
  Object.entries(retainedServicePrices).forEach(([id, prices]) => {
    if (state.serviceConfig[id]) Object.assign(state.serviceConfig[id], prices);
  });
  state.packageConfig = retainedPackages;
  Object.assign(state.regenRoom, retainedRegenRoom);
  state.proposal.introduction = REGEN_PROPOSAL_SUMMARY.replace("reserved for 72 hours", `reserved for ${regenRoomDurationLabel()}`);
  state.mode = "presenter";
  flushPersistence();
  track("new_prospect");
  render({ shell: true });
  toast("New prospect ready. Service prices kept.");
}

function field(path, label, type = "text", options = {}) {
  const value = get(state, path, "");
  const className = `${options.full ? "field full" : "field"}${options.currency ? " currencyField" : ""}`;
  const attrs = `data-bind="${esc(path)}" ${options.min != null ? `min="${options.min}"` : ""} ${options.max != null ? `max="${options.max}"` : ""} ${options.step != null ? `step="${options.step}"` : ""} ${options.testid ? `data-testid="${esc(options.testid)}"` : ""} ${options.rows != null ? `rows="${Math.max(1, Math.floor(Number(options.rows) || 1))}"` : ""} ${options.controlStyle ? `style="${esc(options.controlStyle)}"` : ""} ${options.readonly ? "readonly" : ""} ${options.disabled ? "disabled" : ""}`;
  let control = `<input ${attrs} type="${type}" value="${esc(value)}" placeholder="${esc(options.placeholder || "")}">`;
  if (type === "textarea") control = `<textarea ${attrs} placeholder="${esc(options.placeholder || "")}">${esc(value)}</textarea>`;
  if (type === "select") control = `<select ${attrs}>${(options.items || []).map(item => `<option value="${esc(item.value ?? item)}" ${String(value) === String(item.value ?? item) ? "selected" : ""}>${esc(item.label ?? item)}</option>`).join("")}</select>`;
  if (options.currency && type === "number") control = `<div class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span>${control}</div>`;
  if (options.suffix && type === "number") control = `<div class="suffixControl">${control}<span class="controlSuffix" aria-hidden="true">${esc(options.suffix)}</span></div>`;
  return `<div class="${className}"><label>${esc(label)}</label>${control}${options.help ? `<div class="fieldHelp">${esc(options.help)}</div>` : ""}</div>`;
}

function choice(path, value, label, icon = "✓", multi = true) {
  const current = get(state, path, multi ? [] : "");
  const on = multi ? current.includes(value) : current === value;
  return `<button class="choice ${on ? "on" : ""}" data-action="choice" data-path="${esc(path)}" data-value="${esc(value)}" data-multi="${multi}" aria-pressed="${on}"><i>${icon}</i><span>${esc(label)}</span></button>`;
}

function stageShell() {
  if (state.currentScene === "opening") {
    const openingStep = Math.max(0, Math.min(10, Number(state.opening?.step) || 0));
    return `<div class="stage stage--opening openingStage ${state.mode === "prospect" ? "prospectMode" : ""}" id="regenStage" data-scene="opening" data-opening-state="${openingStep}" data-testid="opening-stage"><section class="openingViewport" id="sceneViewport"></section></div>`;
  }
  const sequence = scenes();
  const sceneIndex = sequence.indexOf(state.currentScene);
  const index = sceneIndex < 0 ? sequence.length : sceneIndex;
  return `<div class="stage stage--shell stage--${slug(state.currentScene)} ${state.mode === "prospect" ? "prospectMode" : ""} ${openingToShell ? "shellReveal" : ""}" id="regenStage" data-scene="${esc(state.currentScene)}" ${state.mode === "prospect" ? 'data-testid="prospect-mode"' : ""}>
    <div class="shell">
      <header class="topRail">
        <div class="brand"><img class="brandLogo" src="${DEFAULT_LOGO_SRC}" alt="Most Wanted Digital"></div>
        <nav class="sceneTrail" aria-label="Presentation progress">${sequence.map((scene, i) => `<span class="trailStep ${i < index ? "done" : i === index ? "active" : ""}" ${i === index ? 'aria-current="step"' : ""} title="${esc(SCENE_LABELS[scene] || scene)}"></span>`).join("")}</nav>
        <div class="railActions presenterOnly" data-testid="presenter-controls">
          <button class="railBtn presenterOnly" data-action="client-details" data-testid="client-details">Client details</button>
          <button class="railBtn presenterOnly" data-action="takeaway-menu" data-testid="takeaway-open">Offer Tools</button>
          <button class="railBtn presenterOnly" data-action="takeout">Call Notes</button>
          <button class="iconBtn clearPricingButton presenterOnly" data-action="clear-current-pricing" data-testid="clear-current-pricing" aria-label="Clear current pricing" title="Clear current pricing">✓</button>
          <button class="iconBtn" data-action="fullscreen" aria-label="Full screen">⛶</button>
          <button class="iconBtn presenterOnly" data-action="admin" aria-label="Settings">☷</button>
        </div>
      </header>
      <section class="sceneViewport" id="sceneViewport"></section>
      <footer class="bottomRail">
        <div class="origin"><span>Based in United States <b class="flag">🇺🇸</b></span></div>
        <div class="sessionStatus legalStatus" aria-label="${esc(MOST_WANTED_LEGAL_IDENTITY)}">
          <span class="legalStatusLead">${esc(MOST_WANTED_LEGAL_IDENTITY)}</span>
        </div>
        <nav class="railNav"><button class="iconBtn" data-action="prev" aria-label="Previous">←</button><button class="iconBtn" data-action="next" aria-label="Next">→</button></nav>
      </footer>
    </div>
  </div>`;
}

function scenePresentationMetrics(scene = state.currentScene) {
  const counts = {
    discovery: DISCOVERY_GROUPS.length,
    recommendation: Object.keys(state.serviceConfig || {}).length,
    ecosystem: Object.keys(state.serviceConfig || {}).length,
    infrastructure: Object.keys(state.serviceConfig || {}).length,
    proof: Object.keys(state.demosConfig || {}).length,
    website: (state.websiteLaunch?.requestedChanges || []).length,
    launch: (state.launchPlan?.tasks || []).length,
    price: selectedServices().length,
    checkout: selectedServices().length + (state.websiteLaunch?.requestedChanges || []).length
  };
  const itemCount = Number(counts[scene] || 0);
  const immersive = new Set(["proof", "website", "infrastructure"]);
  const compact = new Set(["discovery", "recommendation", "ecosystem", "launch", "price", "checkout"]);
  const density = immersive.has(scene) ? "immersive" : compact.has(scene) || itemCount > 6 ? "compact" : "relaxed";
  return { itemCount, density };
}

function sceneFrame(title, lead, body, options = {}) {
  const { itemCount, density } = scenePresentationMetrics();
  const entering = renderedScene !== state.currentScene;
  const titleId = `scene-title-${slug(state.currentScene)}`;
  return `<article class="scene scene--${slug(state.currentScene)} density--${density} ${entering ? "is-entering" : "is-updating"}" data-scene="${esc(state.currentScene)}" data-density="${density}" data-item-count="${itemCount}" data-testid="scene" aria-labelledby="${titleId}">
    <header class="sceneHead"><div><h1 class="sceneTitle" id="${titleId}">${title}</h1>${lead ? `<p class="sceneLead">${lead}</p>` : ""}</div>${options.headAction ? `<div class="sceneHeadActions">${options.badge ? `<span class="sceneBadge">${esc(options.badge)}</span>` : ""}${options.headAction}</div>` : (options.badge ? `<span class="sceneBadge">${esc(options.badge)}</span>` : "")}</header>
    <div class="sceneBody" data-testid="scene-body">${body}</div>
    ${sceneFooter(options)}
  </article>`;
}

function openingLogoSrc() {
  const configured = String(state.opening?.logo || "").trim();
  if (!configured || /^app\/regen-logo\.png(?:\?.*)?$/.test(configured)) return DEFAULT_LOGO_SRC;
  return configured;
}

function openingBusiness() {
  return state.prospect.business || "Your Business";
}

function openingBuildAccessLabel() {
  return `For ${regenRoomDurationLabel()}`;
}

function openingPreviewMarkup() {
  if (state.prospect.previewImageUrl) {
    return `<div class="openingPreviewImage"><img src="${esc(state.prospect.previewImageUrl)}" alt="Custom website prepared for ${esc(openingBusiness())}"></div>`;
  }
  return `<div class="openingBrowserPreview" aria-label="Custom website build in progress"><div class="openingBrowserDots"><i></i><i></i><i></i></div><div class="openingBrowserBar"></div><div class="openingBrowserCanvas"><span>${esc(openingBusiness())}</span><b>Custom digital presence</b><em>Built specifically for this session</em></div></div>`;
}

function openingStateMarkup(step) {
  const business = esc(openingBusiness());
  const logo = esc(openingLogoSrc());
  const roomDuration = regenRoomDurationLabel();
  const capability = ["AMERICAN WEBSITES PIONEER", "UNBEATEN REGULAR SEO", "RELIABLE AI INFRASTRUCTURE", "GOOGLE MAPS MASTERY", "PAID ADS DOMINATION"];
  const journey = ["UNDERSTAND", "DIAGNOSE", "CONFIGURE", "EXPERIENCE", "DECIDE"];
  const states = {
    0: "",
    1: `<img class="openingLogo" src="${logo}" alt="Most Wanted Digital">`,
    2: `<div class="openingLockup"><img class="openingLogo openingLogoSecondary" src="${logo}" alt="Most Wanted Digital"><h1>Built Around Your <span class="accent">Business</span></h1><p>Your business isn’t a template. Neither is what we build around it.</p></div>`,
    3: `<div class="openingLockup"><img class="openingLogo openingLogoSecondary" src="${logo}" alt="Most Wanted Digital"><h1><span class="accent">Unstoppable</span> Digital Infrastructure</h1><p>Website, search, AI, Google Maps and paid growth, built to work as one.</p></div>`,
    4: `<div class="openingLockup"><img class="openingLogo openingLogoSecondary" src="${logo}" alt="Most Wanted Digital"><h1><span class="accent">Curing</span> The Agency Industry</h1><p>We built Most Wanted around fixing the problems businesses have learned to expect from digital agencies.</p><button class="openingPainPointsBtn" data-action="opening-pain-points">See Pain Points</button></div>`,
    5: `<div class="openingWho"><div class="openingWhoCopy"><small>WELCOME TO MOST WANTED</small><h1>Digital <span class="accent">growth</span> infrastructure<br>for American businesses.</h1><p>We build and connect the systems that help local businesses get discovered, win customers and grow.</p><div class="openingContrast"><span>AI SLOP SITES</span><i>→</i><b>RELIABLE REVENUE SYSTEMS</b></div></div><div class="openingCapabilities">${capability.map((label, index) => `<span style="--cap:${index}">${label}</span>`).join("")}</div></div>`,
    6: `<div class="openingPrepared"><div class="openingPreparedCopy"><small>TODAY IS A DECISION SESSION</small><h1>Your site is already<br><span class="accent">prepared.</span></h1><p>Before this meeting, our designers and engineers invested approximately six focused hours creating it specifically for your business. Today you can review the completed work, choose the right plan and decide whether it launches.</p><div class="openingPreparedFor"><span>PREPARED FOR</span><b>${business}</b><em>≈6 FOCUSED HOURS · HUMAN DESIGN + ENGINEERING · READY TO REVIEW TODAY</em></div></div>${openingPreviewMarkup()}</div>`,
    7: `<div class="openingJourney"><small>YOUR PRIVATE DECISION SESSION</small><h1>Built to reach one clear decision <span class="accent">today.</span></h1><div class="openingJourneyRail">${journey.map((label, index) => `<div><b>${label}</b><span>${["Your business.", "Where opportunities are being lost.", "The right launch plan.", "What we’ve built.", "Whether we launch today."][index]}</span></div>`).join("<i>→</i>")}</div><p>We’ll understand the business, diagnose the biggest gaps, configure the right launch plan and let you experience what we prepared. Then we make one clear decision today. There is no scheduled follow-up sales call or chase sequence after this meeting.</p></div>`,
    8: `<div class="openingPrinciples"><h1>Built like specialists.<br><span class="accent">Supported</span> like family.</h1><div class="openingPrincipleGrid"><article><b>CUSTOM CRAFTED</b><p>No cookie-cutter package. Your infrastructure is shaped around your business, market, goals and exact needs.</p></article><article><b>CONCIERGE FOR LIFE</b><p>A boutique, human relationship designed to continue long after launch.</p></article><article><b>ONE-AND-DONE SIMPLICITY</b><p>We build and manage the infrastructure so you don’t have to.</p></article></div><p class="openingClosing">Our goal is not to sell you another piece of software or become another agency you replace. It’s to become the digital growth partner behind your business for the long term.</p></div>`,
    9: `<div class="openingOperate"><header class="openingOperateHead"><small>HOW WE OPERATE</small><h1>We <span class="accent">build.</span> We don’t chase.</h1><p class="openingOperateLead">We reserve production capacity for active client builds, not prolonged sales follow-up.</p><p class="openingOperateDecision">Approximately six focused hours of design and engineering are already complete. This meeting is the decision point. If more clarity is genuinely needed, the Most Wanted Room remains available during the ${roomDuration} before deletion.</p></header><div class="openingPaths" role="group" aria-label="Your two clear options"><article class="openingPath launch" data-opening-path="launch"><span class="openingPathNumber">01</span><small>IF WE’RE A FIT</small><h2>Secure the prepared site today.</h2><p>Your commitment is applied toward the agreed price. The completed work is protected, your production slot is secured and launch work continues immediately.</p><b class="openingDollarCommitment"><strong>≈6H</strong><span>ALREADY INVESTED</span><em>DESIGN + ENGINEERING COMPLETE</em></b></article><article class="openingPath noLaunch" data-opening-path="no-launch"><span class="openingPathNumber">02</span><small>IF YOU NEED CLARITY</small><h2>${roomDuration} of Most Wanted Room access.</h2><p>Bring another decision-maker, ask questions, review the site again or discuss a different offer privately. The site is permanently deleted when the ${roomDuration} window closes.</p><b>MOST WANTED ROOM · ${openingBuildAccessLabel().toUpperCase()}</b></article></div></div>`,
    10: `<div class="openingFinal"><small>THE MOST WANTED EXPERIENCE</small><h1>Your business.<br>Your <span class="accent">infrastructure.</span><br>Your decision today.</h1><div class="openingFinalJourney">${journey.join("  →  ")}</div><p>Your site is ready to launch and approximately six focused hours of human design and engineering are already complete. If we’re the right fit, protect that work and launch today. If we’re not, there is no follow-up sales call and no chase.</p><div class="openingFinalPrepared"><b>CUSTOM BUILD PREPARED FOR ${business}</b><span><strong>≈6 FOCUSED HOURS</strong> ALREADY INVESTED</span><em>Prepared work and pricing remain available ${openingBuildAccessLabel().toUpperCase()} if unlaunched.</em></div></div>`
  };
  return states[step] || "";
}

function renderOpening() {
  const step = Math.max(0, Math.min(10, Number(state.opening?.step) || 0));
  const instruction = step < 10 ? `Opening state ${step + 1} of 11. Activate to continue.` : "Final opening state. Activate to enter the presentation.";
  return `<article class="openingCanvas openingStep${step}" data-testid="opening-canvas" data-opening-step="${step}" data-action="opening-next" role="button" tabindex="0" aria-label="${instruction}"><div class="openingOpticalGlass" aria-hidden="true"><i></i><b></b></div><div class="openingContent" aria-live="polite">${openingStateMarkup(step)}</div></article>`;
}

function buildExpiryDate() {
  const value = state.regenRoom?.expiresAt;
  const date = value ? new Date(value) : null;
  return date && !Number.isNaN(date.getTime()) ? date : null;
}

function buildAccessExpired() {
  const expiry = buildExpiryDate();
  return Boolean(expiry && expiry.getTime() <= Date.now());
}

function normalizeRegenRoomWindowHours(value) {
  const hours = Math.round(Number(value));
  return Number.isFinite(hours) && hours >= 1 ? Math.min(hours, 720) : 72;
}

function regenRoomWindowHours() {
  return normalizeRegenRoomWindowHours(state.regenRoom?.windowHours);
}

function regenRoomDurationLabel(hours = regenRoomWindowHours()) {
  return `${hours} ${hours === 1 ? "hour" : "hours"}`;
}

function regenRoomWindowLabel(hours = regenRoomWindowHours()) {
  return `${hours}-hour`;
}

function syncRegenRoomExpiryToWindow() {
  const startedAt = state.regenRoom?.startedAt ? new Date(state.regenRoom.startedAt) : null;
  if (!startedAt || Number.isNaN(startedAt.getTime())) return;
  state.regenRoom.expiresAt = new Date(startedAt.getTime() + regenRoomWindowHours() * 60 * 60 * 1000).toISOString();
}

function ensureBuildAccessStarted(source = "regen-room-opened") {
  if (buildExpiryDate()) return false;
  const savedStart = state.regenRoom?.startedAt ? new Date(state.regenRoom.startedAt) : null;
  const startedAt = savedStart && !Number.isNaN(savedStart.getTime()) ? savedStart : new Date();
  state.regenRoom.startedAt = startedAt.toISOString();
  const windowHours = regenRoomWindowHours();
  state.regenRoom.expiresAt = new Date(startedAt.getTime() + windowHours * 60 * 60 * 1000).toISOString();
  state.outcome.type ||= `Most Wanted Room, ${regenRoomWindowLabel(windowHours)} decision window`;
  track("regen_room_started", { source, windowHours, expiresAt: state.regenRoom.expiresAt });
  return true;
}

function normalizedPortalList(...sources) {
  const values = sources.flatMap(source => {
    if (Array.isArray(source)) return source;
    if (source && typeof source === "object") return Object.values(source);
    if (typeof source === "string") return source.split(/\n|\s*;\s*/);
    return [];
  }).map(item => {
    if (item && typeof item === "object") return item.text || item.label || item.value || item.name || "";
    return item;
  }).map(item => String(item || "").trim()).filter(Boolean);
  return [...new Set(values)];
}

function portalRequestedChanges() {
  return normalizedPortalList(
    state.websiteLaunch?.requestedChanges,
    state.launchVersion?.requestedChanges,
    state.launchVersion?.changes,
    state.websiteChanges,
    state.prospect?.requestedChanges
  );
}

function portalTargetSearches() {
  const pairedTargets = (state.prospect?.targetSearches || []).map((query, index) => {
    const area = state.prospect?.targetSearchAreas?.[index];
    return [query, area].map(value => String(value || "").trim()).filter(Boolean).join(" · ");
  }).filter(Boolean);
  return normalizedPortalList(
    pairedTargets,
    state.prospect?.seoTargets,
    state.discovery?.targetSearches,
    state.seoTargets
  ).slice(0, 3);
}

function expiryCountdownMarkup({ offerOnly = false, label = "" } = {}) {
  const expiry = buildExpiryDate();
  if (!expiry || buildAccessExpired()) return `<div class="expiryTimer expired" data-testid="build-expired"><span>${offerOnly ? "MOST WANTED ROOM CLOSED" : "BUILD PERMANENTLY DELETED"}</span></div>`;
  const remaining = Math.max(0, expiry.getTime() - Date.now());
  const hours = String(Math.floor(remaining / 3600000)).padStart(2, "0");
  const minutes = String(Math.floor((remaining % 3600000) / 60000)).padStart(2, "0");
  const seconds = String(Math.floor((remaining % 60000) / 1000)).padStart(2, "0");
  const timerLabel = label || (offerOnly ? "SITE SCHEDULED FOR DELETION IN" : "PERMANENTLY DELETED IN");
  return `<div class="expiryTimer" data-testid="build-countdown" data-expiry="${expiry.toISOString()}"><small>${timerLabel}</small><b><span>${hours}</span><i>:</i><span>${minutes}</span><i>:</i><span>${seconds}</span></b></div>`;
}

function renderBuildExpiry() {
  const expired = buildAccessExpired();
  const business = esc(openingBusiness());
  const email = esc(REGEN_CONTACT_EMAIL);
  const phone = esc(REGEN_CONTACT_PHONE);
  const selected = selectedServices();
  const systems = selected.map(service => `<li>${service.icon} ${esc(service.name)}${service.quantity > 1 ? ` · Qty ${service.quantity}` : ""}</li>`).join("") || "<li>The services in your plan</li>";
  const changes = portalRequestedChanges();
  const searches = portalTargetSearches();
  const price = priceSummary();
  const websiteUrl = String(state.prospect?.demoUrl || state.prospect?.websiteUrl || "").trim();
  const changesMarkup = changes.length ? `<ul>${changes.map(change => `<li>${esc(change)}</li>`).join("")}</ul>` : `<span>No website changes were requested during the session.</span>`;
  const searchesMarkup = searches.length ? `<div class="recommendMeta">${searches.map(search => `<span>${esc(search)}</span>`).join("")}</div>` : `<span>No target searches were recorded.</span>`;
  const pricingMarkup = `<section class="buildExpiryPricing" data-testid="build-expiry-pricing"><small>YOUR SAVED PLAN</small><div class="priceTotals"><div class="priceTotal"><span>Standard setup</span><b>${money(price.standardSetup)}</b></div><div class="priceTotal saving"><span>Saving when you start now</span><b>${money(price.saving)}</b></div><div class="priceTotal"><span>Setup due</span><b>${money(price.effectiveSetup)}</b></div><div class="priceTotal"><span>Monthly support</span><b>${money(price.monthly)}</b></div></div><p>${esc(state.pricing.paymentOption || "Payment plan to be confirmed")}${state.pricing.dollarCommitmentSelected ? " · $1 eligible launch commitment selected" : ""}</p></section>`;
  if (expired) return `<article class="buildExpiryPage isExpired" data-testid="build-expiry-page"><div class="buildExpiryMark"><img src="${esc(openingLogoSrc())}" alt="Most Wanted Digital"></div><div class="buildExpiryCenter">${expiryCountdownMarkup()}<p>This Most Wanted Experience has ended.</p><div class="buildExpiryContact"><b>Want us to build another one?</b><span>New website requests enter our standard build queue and typically take around 2 weeks, compared with the 5–6 hours already invested in the deleted build.</span><a href="mailto:${email}">${email}</a><a href="tel:${phone.replace(/[^0-9+]/g, "")}">${phone}</a><a class="primaryBtn" href="mailto:${email}?subject=Request%20a%20new%20Most Wanted%20build">Request A New Build</a></div></div></article>`;
  return `<article class="buildExpiryPage" data-testid="build-expiry-page"><div class="buildExpiryMark"><img src="${esc(openingLogoSrc())}" alt="Most Wanted Digital"></div><div class="buildExpiryGrid"><section>${expiryCountdownMarkup()}<p>Everything we prepared for your business stays available until the timer reaches zero.</p><div class="buildAvailable"><b>Available now</b><ul><li>${websiteUrl ? `<a href="${esc(websiteUrl)}" target="_blank" rel="noopener">Open your custom website</a>` : "Your custom website"}</li><li>Your requested website changes</li><li>The services in your plan</li><li>Your three selected Google searches</li><li>Your saved price, start details and checkout</li></ul></div></section><aside class="buildExpiryActions"><button class="primaryBtn" data-action="expiry-launch">Start My Plan</button><a class="ghostBtn" href="mailto:${email}?subject=Question%20about%20my%20Most Wanted%20build">Ask Most Wanted a Question</a><div class="buildExpiryContact"><b>Kailan - Owner</b><a href="mailto:${email}">${email}</a><a href="tel:${phone.replace(/[^0-9+]/g, "")}">${phone}</a><span>Have a question before the timer reaches zero? Reach out directly.</span></div></aside></div>${pricingMarkup}<div class="buildExpiryScope"><b>Your plan for ${business}</b><ul>${systems}</ul><b>Requested website changes</b>${changesMarkup}<b>Three searches to win</b>${searchesMarkup}<b>Start details</b><span>${esc(state.launchStart?.timing || "Launch immediately")}${state.launchStart?.domain ? ` · ${esc(state.launchStart.domain)}` : ""}</span></div><div class="buildExpiryContrast"><section><small>RIGHT NOW</small><b>Your completed custom build</b><span>Available immediately until the timer expires.</span></section><i>VERSUS</i><section><small>AFTER DELETION</small><b>Start again</b><span>Typical turnaround: about 2 weeks.</span></section><p>Changed your mind later? You can request a new website at any time. A new design usually takes about 2 weeks, compared with the 5–6 hours already spent preparing this one.</p></div></article>`;
}

function sceneFooter(options = {}) {
  const checkpoint = options.checkpoint;
  const extra = options.extra || "";
  if (!checkpoint && !extra) return "";
  return `<footer class="sceneFooter">
    ${checkpoint ? `<div class="checkpoint"><b>${esc(checkpoint)}</b>${options.checkpointKey ? checkpointControls(options.checkpointKey) : ""}</div>` : ""}
    ${extra ? `<div class="footerActions">${extra}</div>` : ""}
  </footer>`;
}

function checkpointControls(key) {
  const values = CHECKPOINT_OPTIONS[key] || [];
  return `<span class="checkpointChoices" role="group" aria-label="${esc(checkpointPrompt(key))}">${values.map(value => checkpointChoiceButton(key, value)).join("")}</span>`;
}

function checkpointPrompt(key) {
  return ({
    understanding: state.language.checkpointUnderstanding,
    problem: state.language.checkpointProblem,
    recommendation: state.language.checkpointRecommendation,
    product: state.language.checkpointProduct,
    decision: state.language.checkpointDecision,
    certainty: state.language.checkpointCertainty
  })[key] || "Choose the closest response";
}

function checkpointChoiceButton(key, value, { className = "chip", icon = "" } = {}) {
  const selected = state.checkpoints[key] === value;
  return `<button type="button" class="${className} ${selected ? "on" : ""}" data-action="checkpoint" data-key="${esc(key)}" data-value="${esc(value)}" data-selected="${selected}" data-testid="checkpoint-${slug(key)}-${slug(value)}" aria-pressed="${selected}">${icon ? `<i aria-hidden="true">${icon}</i>` : ""}<span>${esc(value)}</span></button>`;
}

function renderIntro() {
  return sceneFrame("Digital Infrastructure. <span class=\"accent\">One Connected System.</span>", "One accountable team builds, connects and supports the systems that turn attention into paying work.", `<div class="briefIntro briefIntroV3" data-testid="brief-introduction"><section class="briefIntroStatement"><h2>One team. Clear stated objective. Only what gets your business to victory.</h2><p>Websites, search and AI optimization, Google Maps, customer response, workflow and advertising. Built to work together as one clear operating system.</p><div class="briefIntroPromise"><div class="briefIntroLaunchCue"><span aria-hidden="true">🚀</span><b>Secure Today’s Launch</b><em>From $1</em></div><div class="briefIntroSaving"><strong>20%</strong><span>Off when launching today</span></div></div></section><div class="briefIntroCapabilities">${[
    ["🖥️", "Website", "Turn visits into calls and enquiries."],
    ["🔎", "Search", "Get found on Google, Maps and AI search."],
    ["📞", "Response", "Answer calls and messages before customers move on."],
    ["⭐", "Trust", "Build reviews, follow-up and local credibility."]
  ].map(([icon, name, copy]) => `<article><i>${icon}</i><div><b>${name}</b><p>${copy}</p></div></article>`).join("")}</div></div>`, { badge: "What Most Wanted does", nextLabel: "Let’s Talk About Your Business" });
}

const introCard = (icon, title, copy) => `<article class="introCard"><i>${icon}</i><b>${title}</b><span>${copy}</span></article>`;

function renderCompany() {
  return renderIntro();
}

function renderOutcome() {
  return sceneFrame("Help more of the right people find you, reach you and <span class=\"accent\">choose</span> you.", "Our job is simple: help more people who need your service become booked jobs.", `<div style="height:100%;display:grid;grid-template-rows:minmax(0,1fr) auto;gap:12px"><div class="threeGrid">${[
    ["🔎", "GET FOUND", "Appear where potential customers are searching."],
    ["📞", "ANSWER CALLS", "Reply before the customer moves on."],
    ["✅", "GET CHOSEN", "Build enough trust and follow-up to win more of the available work."]
  ].map(([icon, name, copy], index) => `<article class="outcomeCard"><span class="arrow">${index < 2 ? "→" : ""}</span><span class="cardIcon">${icon}</span><b>${name}</b><p>${copy}</p></article>`).join("")}</div><div class="glass" style="border-radius:16px;padding:12px 18px;text-align:center;font-size:12px;font-weight:900">Before we suggest anything, let’s find where jobs may be slipping away.</div></div>`, { badge: "What this should do", nextLabel: "Tell Us About Your Business" });
}

function renderDiscovery() {
  const group = DISCOVERY_GROUPS[state.discoveryStep] || DISCOVERY_GROUPS[0];
  const body = `<div class="discoveryShell" data-discovery-group="${group.id}"><nav class="discoveryNav" aria-label="Discovery sections">${DISCOVERY_GROUPS.map((item, index) => `<button type="button" data-action="discovery-step" data-index="${index}" class="${index === state.discoveryStep ? "active" : ""} ${discoveryComplete(item.id) ? "complete" : ""}" ${index === state.discoveryStep ? 'aria-current="step"' : ""}><i>${item.icon}</i><span>${esc(state.discoveryCopy[item.id]?.name || item.name)}</span></button>`).join("")}</nav><section class="questionCard questionCard--${group.id}" data-discovery-group="${group.id}">${discoveryGroup(group.id)}<div class="questionProgress" aria-label="Question ${state.discoveryStep + 1} of ${DISCOVERY_GROUPS.length}">${DISCOVERY_GROUPS.map((_, index) => `<span class="${index <= state.discoveryStep ? "on" : ""}"></span>`).join("")}</div></section></div>`;
  const last = state.discoveryStep === DISCOVERY_GROUPS.length - 1;
  return sceneFrame(`Your business: ${accentLastTitleWord(state.discoveryCopy[group.id]?.name || group.name)}`, "We’ll take this one question at a time. If you do not know an answer, leave it blank.", body, {
    badge: `Question ${state.discoveryStep + 1} of ${DISCOVERY_GROUPS.length}`,
    backAction: state.discoveryStep > 0 ? "discovery-back" : "prev",
    nextAction: last ? "finish-discovery" : "discovery-next", nextLabel: last ? "Build My Summary" : "Next Question"
  });
}

function discoveryGroup(id) {
  const copy = state.discoveryCopy[id] || {};
  const intro = `<h2>${esc(copy.title || id)}</h2><p>${esc(copy.description || "")}</p>`;
  if (id === "presence") return `${intro}<div class="questionFields infrastructureQuestionFields"><div class="choiceGrid infrastructureChoices">${Object.values(SERVICES).map(service => choice("prospect.currentSystems", service.name, service.name, service.icon)).join("")}</div><div class="formGrid three infrastructureFields discoveryCoreFields" style="margin-top:12px">${field("prospect.websitePerformance", "Website performance", "select", { items: ["", "No website", "Poor", "Adequate", "Strong", "Unknown"] })}${field("prospect.localVisibility", "Local visibility", "select", { items: ["", "Invisible", "Poor", "Adequate", "Strong", "Unknown"] })}${field("prospect.missedHandling", "Missed-call handling", "select", { items: ["", "None", "Voicemail only", "Call back manually", "Answering service", "Automated", "Unknown"] })}${field("prospect.followupProcess", "Follow-up process", "select", { items: ["", "None", "Manual and inconsistent", "Manual and consistent", "Automated", "Unknown"] })}</div><button class="ghostBtn discoveryDetailsBtn" data-action="discovery-details" data-group="presence">${presenceDetailsComplete() ? "Review details ✓" : "Add reviews and provider details"}</button></div>`;
  if (id === "channels") return `${intro}<div class="questionFields"><div class="choiceGrid">${["Referrals", "Google Search / Maps", "Social media", "Paid ads", "Repeat customers", "Offline / community"].map((item, i) => choice("prospect.currentChannels", item, item, ["🤝", "🔎", "📱", "📣", "🔁", "🏘️"][i])).join("")}</div><div class="formGrid three discoveryCoreFields" style="margin-top:12px">${field("prospect.monthlyOpportunities", "Calls and enquiries each month", "number", { min: 0 })}${field("prospect.missedPercent", "Missed or unanswered %", "number", { min: 0, step: 1 })}${field("prospect.averageResponseTime", "Response time in minutes", "number", { min: 0 })}</div><button class="ghostBtn discoveryDetailsBtn" data-action="discovery-details" data-group="channels">${channelDetailsComplete() ? "Review details ✓" : "Add estimates and close rate"}</button></div>`;
  if (id === "success") return `${intro}<div class="questionFields"><div class="choiceGrid">${[["More completed jobs", "More completed jobs"], ["More qualified opportunities", "More good enquiries"], ["More consistent revenue", "More consistent revenue"], ["Less admin and stress", "Less paperwork and stress"], ["Become the clear local choice", "Become the clear local choice"], ["Grow without chasing", "Grow without chasing"]].map(([value, label], index) => choice("prospect.successSelections", value, label, ["💰", "🎯", "📈", "😌", "🏆", "🧲"][index])).join("")}</div><div class="formGrid discoveryNarrativeFields" style="margin-top:12px">${field("prospect.growthGoal", "Put success into your own words", "textarea", { placeholder: "What result would make this worthwhile?" })}${field("prospect.whyGoalMatters", "If that became consistent, what would it change for you or the business?", "textarea")}</div><button class="ghostBtn discoveryDetailsBtn" data-action="discovery-details" data-group="success">${successDetailsComplete() ? "Review job target ✓" : "Add job target and timing"}</button></div>`;
  if (id === "blockers") return `${intro}<div class="questionFields"><div class="choiceGrid">${["Not enough time", "Cash flow", "Hard to trust providers", "Burned by a previous agency", "Unsure of the value", "Technology feels complicated", "Another person needs to agree"].map((item, index) => choice("prospect.blockerSelections", item, item, ["⏳", "💵", "🛡️", "🔥", "❓", "⚙️", "🤝"][index])).join("")}</div><div class="formGrid" style="margin-top:12px">${field("prospect.blockerDetail", "What is the biggest blocker in your own words?", "textarea", { full: true })}${field("prospect.budgetTiming", "Anything important about cash flow or timing?", "textarea", { full: true })}</div></div>`;
  const wishesTextArea = { full: true, rows: 3, controlStyle: "height:88px!important;min-height:88px!important;overflow:hidden!important" };
  return `${intro}<div class="questionFields"><div class="choiceGrid">${[["Help more people find us", "Help more people find us"], ["Answer every opportunity", "Answer every call or message"], ["Build immediate trust", "Build trust quickly"], ["Follow up without chasing", "Follow up without chasing"], ["Book more completed jobs", "Book more completed jobs"], ["Connect everything in one place", "Keep everything in one place"]].map(([value, label], index) => choice("prospect.wishSelections", value, label, ["🔎", "📞", "⭐", "🔁", "📅", "🧩"][index])).join("")}</div><div class="formGrid" style="margin-top:12px">${field("prospect.whyNow", "Why does getting this moving now matter?", "textarea", wishesTextArea)}${field("prospect.primaryProblem", "Anything else you want these tools to solve?", "textarea", wishesTextArea)}</div></div>`;
}

function discoveryComplete(id) {
  const p = state.prospect;
  return ({
    presence: p.currentSystems.length || p.websitePerformance || p.localVisibility,
    channels: p.currentChannels.length || p.targetSearches.some(Boolean) || p.monthlyOpportunities,
    success: p.successSelections.length || p.growthGoal || p.whyGoalMatters,
    blockers: p.blockerSelections.length || p.blockerDetail || p.budgetTiming,
    wishes: p.wishSelections.length || p.whyNow || p.primaryProblem
  })[id];
}

function presenceDetailsComplete() {
  const p = state.prospect;
  return Boolean(p.webEnquiryHandling || p.reviewCount !== "" || p.reviewRating !== "" || p.provider);
}

function channelDetailsComplete() {
  const p = state.prospect;
  return Boolean(p.monthlyEstimates !== "" || p.closeRate !== "");
}

function successDetailsComplete() {
  const p = state.prospect;
  return Boolean(p.capacityJobs !== "" || p.desiredJobs !== "" || p.targetPeriod);
}

function discoveryDetailsModal() {
  const group = ["presence", "channels", "success"].includes(discoveryDetailsGroup) ? discoveryDetailsGroup : "presence";
  const config = {
    presence: {
      title: "Presence Details",
      lead: "Add the details that sharpen the recommendation without crowding the main question.",
      body: `<div class="formGrid">${field("prospect.webEnquiryHandling", "Web enquiry handling", "select", { items: [{ value: "", label: "Unknown" }, { value: "none", label: "No response capability" }, { value: "slow", label: "Slow or manual response" }, { value: "fast", label: "Fast structured response" }] })}${field("prospect.reviewCount", "Google review count", "number", { min: 0 })}${field("prospect.reviewRating", "Google rating", "number", { min: 0, step: .1 })}${field("prospect.provider", "Current provider or providers", "text", { full: true })}</div>`
    },
    channels: {
      title: "Channel Details",
      lead: "Add these numbers when they are known. Leave them blank rather than guessing.",
      body: `<div class="formGrid">${field("prospect.monthlyEstimates", "Estimates or appointments each month", "number", { min: 0 })}${field("prospect.closeRate", "Current close rate %", "number", { min: 0, step: 1 })}</div>`
    },
    success: {
      title: "Job Target and Timing",
      lead: "Use the numbers you know. This helps keep the plan realistic for your current capacity.",
      body: `<div class="formGrid">${field("prospect.capacityJobs", "Extra jobs you can handle each month", "number", { min: 0 })}${field("prospect.desiredJobs", "Extra jobs you want", "number", { min: 0 })}${field("prospect.targetPeriod", "By when?", "select", { items: ["30 days", "90 days", "6 months", "12 months"] })}</div>`
    }
  }[group];
  return simpleModal(config.title, `<div class="discoveryDetailsModal" data-testid="discovery-details-${group}"><p class="sceneLead">${config.lead}</p>${config.body}</div>`);
}

function renderHeard() {
  inferHeard();
  const fields = [["situation", "Current situation"], ["objective", "Goal"], ["constraint", "Biggest constraint"], ["motive", "Deeper motivation"]];
  const searchInputs = [0, 1, 2].map(index => `<label class="heardSearchTag"><span>${index + 1}</span><input data-bind="heard.searches.${index}" value="${esc(state.heard.searches?.[index] || "")}" placeholder="Target search ${index + 1}"></label>`).join("");
  return sceneFrame("Here’s what I <span class=\"accent\">heard</span>", "Your situation, goal, main problem and reason for doing this, all in one place.", `<div class="heardGrid"><section class="heardEditor"><div class="summaryRows">${fields.map(([id, label]) => `<div class="summaryRow"><label>${label}</label><textarea data-bind="heard.${id}">${esc(state.heard[id])}</textarea></div>`).join("")}<section class="heardSearches" data-testid="heard-target-searches"><header><label>Three searches to win</label><span>You can edit these</span></header><div>${searchInputs}</div></section></div></section><aside class="heardSide"><h3>Check this together</h3><p>This makes sure your plan is based on the right problems.</p><div class="confirmBlock"><b>${state.heard.confirmed ? "✅ Confirmed" : "Please confirm"}</b><p>${state.heard.confirmed ? "Great, we can build the right plan." : "Change or add anything missing, then confirm it together."}</p></div></aside></div>`, {
    badge: state.heard.confirmed ? "Ready to continue" : "Please confirm", nextDisabled: !state.heard.confirmed,
    checkpoint: "Have I understood that correctly?", checkpointKey: "understanding"
  });
}

function opportunityUrgencyScores(result = calculateLeaks()) {
  const p = state.prospect;
  const selectedProblems = (p.blockerSelections || []).map(value => String(value));
  const selectedText = selectedProblems.join(" ").toLowerCase();
  const hasCallEvidence = /miss(?:ed)? calls?|call handling|never miss a call/.test(selectedText)
    || p.missedPercent !== ""
    || Boolean(String(p.missedHandling || "").trim());
  const hasFollowupEvidence = /follow(?:ing)? up|workflow|multiple companies|providers/.test(selectedText);
  const hasVisibilityEvidence = /inquir|maps|search|paid ads|lead service|visible|online/.test(selectedText)
    || Boolean(String(p.localVisibility || "").trim());
  const hasTrustEvidence = /website|review|reputation/.test(selectedText)
    || Boolean(String(p.websitePerformance || "").trim())
    || Boolean(String(p.reviewsProcess || "").trim());
  const statusScore = { yes: 84, maybe: 57, no: 18, unknown: 24 };
  const scoreFor = (id, status) => {
    let score = statusScore[status] ?? statusScore.unknown;
    if (id === "response") score += Math.min(12, Number(p.missedPercent || 0) / 3) + (Number(p.averageResponseTime || 0) > Number(state.rules.responseMinutes) ? 7 : 0);
    if (id === "trust") score += Number(p.reviewCount || 0) > 0 && Number(p.reviewCount) < Number(state.rules.minimumReviewCount) ? 6 : 0;
    if (id === "visibility") score += String(p.localVisibility || "").toLowerCase() === "invisible" ? 8 : 0;
    return Math.round(Math.max(5, Math.min(95, score)));
  };
  const reasonFor = (id, status) => {
    if (id === "response") {
      if (hasCallEvidence && p.missedPercent !== "" && p.missedPercent != null) return `${number(p.missedPercent)}% of calls or enquiries may be lost.`;
      if (hasFollowupEvidence) return "Follow-up or operational friction is interrupting the path to paid work.";
      return status === "unknown" ? "Conversion and follow-up have not been measured yet." : "The path from enquiry to paid work needs attention.";
    }
    if (id === "visibility") return p.localVisibility ? `Local visibility is currently marked: ${p.localVisibility}.` : hasVisibilityEvidence ? "Discovery answers show inconsistent demand or visibility." : "Consistent visibility has not been measured yet.";
    if (id === "trust") return p.reviewCount !== "" && p.reviewCount != null ? `${number(p.reviewCount)} reviews${p.reviewRating ? ` with a ${number(p.reviewRating)} rating` : ""}.` : hasTrustEvidence ? "Discovery answers show gaps in website or reputation strength." : "Online trust and conversion strength have not been measured yet.";
    return p.followupProcess ? "No consistent follow-up system." : "The follow-up process has not been measured yet.";
  };
  const responseName = hasCallEvidence
    ? "Calls And Enquiries Are Slipping Through"
    : hasFollowupEvidence
      ? "Operational Friction Is Costing Opportunities"
      : "Interest Isn’t Turning Into Enough Paid Work";
  const visibilityName = hasVisibilityEvidence
    ? "Not Enough Right Customers Are Finding You"
    : "Demand Isn’t Consistent Enough Yet";
  const trustName = hasTrustEvidence
    ? "Your Online Presence Is Losing Trust"
    : "Your Current Setup Is Limiting Growth";
  const clientFacingCards = {
    response: { ...OPPORTUNITY_LOSSES.response, icons: { red: "🚨", yellow: "⚠️", green: "📈" }, name: responseName },
    visibility: { ...OPPORTUNITY_LOSSES.visibility, icons: { red: "🚫", yellow: "🚧", green: "🔎" }, name: visibilityName },
    trust: { ...OPPORTUNITY_LOSSES.trust, icons: { red: "💔", yellow: "😬", green: "⭐" }, name: trustName }
  };
  return Object.entries(clientFacingCards).map(([id, card]) => {
    const status = normalizeOpportunityState(state.leaks[id]?.state || result.states?.[id]);
    const score = scoreFor(id, status);
    const level = score >= 70 ? "red" : score >= 40 ? "yellow" : "green";
    const label = level === "red" ? "Red" : level === "yellow" ? "Yellow" : "Green";
    const meaning = level === "red" ? "Jobs may be slipping away now" : level === "yellow" ? "Warning signs need attention" : "Lower urgency, still worth improving";
    return { id, ...card, icon: card.icons[level], status, score, level, label, meaning, reason: reasonFor(id, status) };
  }).sort((a, b) => b.score - a.score);
}

function renderLeaks() {
  const result = calculateLeaks();
  const scores = opportunityUrgencyScores(result);
  const top = scores[0];
  if (!state.leaks.primary && top) state.leaks.primary = top.id;
  const average = Math.round(scores.reduce((sum, item) => sum + item.score, 0) / Math.max(1, scores.length));
  const overallLevel = average >= 70 ? "red" : average >= 40 ? "yellow" : "green";
  const overallLabel = overallLevel === "red" ? "Red" : overallLevel === "yellow" ? "Yellow" : "Green";
  const overallMeaning = overallLevel === "red" ? "Jobs are likely being lost now" : overallLevel === "yellow" ? "Some parts need work" : "The path looks healthy";
  const leakById = Object.fromEntries(scores.map(card => [card.id, card]));
  const journey = [
    ["FOUND", "Visibility", "visibility", "They discover the business."],
    ["ANSWERED", "Response", "response", "The opportunity gets an answer."],
    ["TRUSTED", "Trust", "trust", "They see enough proof to keep going."],
    ["FOLLOWED UP", "Follow-Up", "followup", "Interest receives consistent follow-up."],
    ["BOOKED", "Completed outcome", "", "The opportunity becomes booked work."]
  ].map(([stage, leakName, leakId, copy], index) => {
    if (!leakId) return `<article class="leakJourneyStage bookedStage" data-journey-stage="booked"><span class="leakStageNumber">${index + 1}</span><small>DESTINATION</small><h3>${stage}</h3><p>Ready to become booked work.</p><strong>Goal</strong></article>`;
    const card = leakById[leakId];
    const selected = state.leaks.primary === leakId;
    return `<button type="button" class="leakJourneyStage ${card.level} ${selected ? "primary" : ""}" data-action="primary-leak" data-id="${leakId}" data-leak-card="${leakId}" data-urgency-level="${card.level}" data-testid="urgency-card-${leakId}" aria-pressed="${selected}"><span class="leakStageNumber">${index + 1}</span><small>${esc(leakName)}${selected ? " · Biggest gap" : ""}</small><h3>${stage}</h3><p>${esc(card.meaning)}</p><strong>${card.score}/100 · ${card.label}</strong></button>`;
  }).join(`<i class="leakJourneyArrow" aria-hidden="true">→</i>`);
  const outputs = `<section class="leakSummaryBar ${overallLevel}" data-testid="opportunity-urgency-score" aria-label="Opportunity loss summary"><div><span>Overall urgency</span><b>${average}<small>/100</small></b><em>${overallLabel}</em></div><div><span>Biggest gap to fix</span><b>${esc(opportunityLossLabel(state.leaks.primary) || top?.name || "Finish the questions")}</b><em>Start here</em></div><div data-testid="leak-calculation"><span>Possible monthly value</span><b>${result.knownResponseValue !== null ? `${money(result.knownResponseValue)}` : "Add your numbers"}</b><em>${result.knownResponseValue !== null ? "per month" : "to calculate this"}</em></div></section>`;
  return sceneFrame(`Where you’re <span class="accent">losing</span> jobs`, "This shows the path from being found to winning a booked job. Red needs attention first.", `<section class="leakJourney leakJourneySimple" data-testid="revenue-leak-map" aria-label="Found, answered, trusted, followed up, booked">${journey}</section>${outputs}`, { badge: `${overallLabel}: ${overallMeaning}`, checkpoint: "Does this match what you see in the business?", checkpointKey: "problem" });
}

function leakDetailsModal() {
  const result = calculateLeaks();
  const scores = opportunityUrgencyScores(result);
  const formula = "Monthly calls and enquiries × unanswered % × current close rate × average completed-job revenue";
  const rows = scores.map(card => `<article class="recommendRow ${card.level}"><i>${card.icon}</i><div><h4>${esc(card.name)} · ${esc(card.label)}</h4><p>${esc(card.reason)}</p></div><button class="ghostBtn" data-action="primary-leak" data-id="${card.id}">${state.leaks.primary === card.id ? "Biggest gap ✓" : "Mark biggest"}</button></article>`).join("");
  const value = result.knownResponseValue !== null
    ? `${money(result.knownResponseValue)} per month. Based on: ${formula}. This is illustrative, not a promise of results.`
    : "Add monthly calls and enquiries, unanswered percentage, close rate and average job value. Until then, we will not guess a dollar amount.";
  return simpleModal("Diagnosis Details", `<div class="leakDetailsModal" data-testid="leak-details-modal"><div class="recommendedList">${rows}</div><section class="leakCalculation"><b>Possible monthly value</b><p>${esc(value)}</p></section></div>`);
}

function renderEcosystem() {
  const website = state.serviceConfig.website;
  const foundation = website ? `<section class="websiteFoundation" data-testid="website-shared-foundation"><header><span>THE STARTING POINT</span><h3>Website</h3><p>Your website supports all three outcomes.</p></header>${moduleCard(website, { compact: true })}</section>` : "";
  const pillars = Object.entries(PILLARS).map(([pillarId, pillar]) => `<section class="pillar"><header class="pillarHead"><i>${pillar.icon}</i><div><span>What it helps with</span><b>${pillar.name}</b><span>${pillar.description}</span></div></header><div class="moduleList">${Object.values(state.serviceConfig).filter(service => service.pillar === pillarId && service.id !== "website").map(service => moduleCard(service, { compact: true })).join("")}</div></section>`).join("");
  return sceneFrame("Choose what we <span class=\"accent\">launch today</span>", "Keep only the services that directly solve the biggest problems. This becomes the scope you can approve and launch today.", `<div class="ecosystemArchitecture" data-testid="ecosystem">${foundation}<div class="pillarGrid">${pillars}</div></div>`, { badge: "Built from your answers", extra: `<div class="ecosystemActions"><button class="ghostBtn" data-action="explore-all">See Every Service</button><button class="ghostBtn presenterOnly" data-action="line-item-pricing" data-testid="open-line-item-pricing">Set Service Prices</button><button class="ghostBtn presenterOnly" data-action="launch-cart" data-testid="adjust-launch-cart">Finalise Today’s Plan</button></div>` });
}

function moduleCard(service, { compact = false } = {}) {
  const selected = state.services[service.id];
  const quantity = serviceQuantity(service.id);
  const statusLabel = selected.status === "recommended" ? "Include today" : selected.status === "optional" ? "Consider today" : "Not for today";
  const setupPrice = effectiveServicePrice(service, "setup");
  const monthlyPrice = effectiveServicePrice(service, "monthly");
  const servicePrice = `${money(setupPrice)} setup${monthlyPrice ? ` + ${money(monthlyPrice)}/mo` : ""}`;
  return `<article class="moduleCard ${selected.status} ${compact ? "moduleCard--summary" : ""}" data-testid="service-card-${service.id}"><div class="moduleTop"><i>${service.icon}</i><b>${esc(service.name)}${quantity > 1 ? ` · Qty ${quantity}` : ""}</b><span class="moduleStatus" data-testid="service-status-${service.id}">${statusLabel}</span></div>${compact ? "" : `<p class="moduleReason" contenteditable="${state.mode === "presenter"}" data-reason="${service.id}">${esc(selected.reason)}</p>`}<div class="moduleCommercials"><span class="serviceTimeToLive" data-service-ttl="${service.id}" data-testid="service-ttl-${service.id}">⏱️ ${esc(serviceTimeToLive(service))}</span><span class="servicePrice">${servicePrice}</span></div>${compact ? "" : `<div class="moduleActions presenterOnly">${["recommended", "optional", "later"].map(status => `<button class="${selected.status === status ? "on" : ""}" data-action="service-status" data-id="${service.id}" data-status="${status}">${status === "recommended" ? "Include" : status === "optional" ? "Maybe later" : "Not now"}</button>`).join("")}</div>`}</article>`;
}

function launchCartModal() {
  recalculatePrice();
  const selected = selectedServices();
  const totalUnits = selected.reduce((sum, service) => sum + service.quantity, 0);
  const manualPricing = state.pricing.manualSetup || state.pricing.manualMonthly;
  const rows = Object.values(state.serviceConfig).map(service => {
    const item = state.services[service.id];
    const quantity = serviceQuantity(service.id);
    const setupPrice = effectiveServicePrice(service, "setup");
    const monthlyPrice = effectiveServicePrice(service, "monthly");
    const selectedClass = quantity > 0 ? "isSelected" : "isInactive";
    const status = quantity > 0 ? "In your plan" : item.status === "later" ? "Saved for later" : "Available";
    return `<article class="launchCartRow ${selectedClass}" data-service-id="${service.id}" data-cart-selected="${quantity > 0}" data-testid="launch-cart-row-${service.id}"><div class="launchCartIdentity"><i>${service.icon}</i><div><b>${esc(service.name)}</b><span data-cart-status="${service.id}">${esc(PILLARS[service.pillar]?.name || "Most Wanted service")} · ${status} <small class="serviceTimeToLive" data-service-ttl="${service.id}" data-testid="launch-cart-service-ttl-${service.id}">· ⏱️ Ready time: ${esc(serviceTimeToLive(service))}</small></span></div></div><div class="launchCartUnitPrice"><small>Price per setup</small><span>${money(setupPrice)} setup${monthlyPrice ? ` + ${money(monthlyPrice)}/mo` : ""}</span></div><div class="launchCartQuantity" data-testid="launch-cart-quantity-${service.id}"><button type="button" class="quantityBtn" data-action="cart-quantity-minus" data-id="${service.id}" aria-label="Remove one ${esc(service.name)}">−</button><input type="number" inputmode="numeric" min="0" max="99" step="1" value="${quantity}" data-cart-quantity="${service.id}" data-testid="launch-cart-input-${service.id}" aria-label="Quantity for ${esc(service.name)}"><button type="button" class="quantityBtn" data-action="cart-quantity-plus" data-id="${service.id}" aria-label="Add one ${esc(service.name)}">+</button></div></article>`;
  }).join("");
  const pricingNote = manualPricing
    ? "The agreed setup or monthly price stays unchanged. Quantities still update the plan, price, proposal and checkout."
    : "Prices update automatically when quantities change.";
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal launchCartModal" data-testid="launch-cart"><header class="modalHead"><div><small>Services selected</small><h2>Adjust Launch Cart</h2></div><button class="iconBtn" data-action="close-overlay">×</button></header><div class="modalBody"><section class="launchCartSummary" data-testid="launch-cart-summary"><div><span>Systems selected</span><b data-cart-summary="systems">${selected.length}</b></div><div><span>Total deployments</span><b data-cart-summary="units">${totalUnits}</b></div><div><span>One-time total</span><b data-cart-summary="setup">${money(state.pricing.catalogSetup)}</b></div><div><span>Monthly total</span><b data-cart-summary="monthly">${money(state.pricing.catalogMonthly)}</b></div></section><p class="fieldHelp launchCartPricingNote">${pricingNote}</p><div class="launchCartList">${rows}</div></div><footer class="modalFoot"><button class="primaryBtn" data-action="close-overlay" data-testid="launch-cart-done">Done</button></footer></section></div>`;
}

function lineItemPricingModal() {
  recalculatePrice();
  const lines = priceLineItems();
  const total = priceSummary();
  const draft = combinedOfferDraft || {
    name: "Combined Growth Offer",
    serviceIds: lines.map(service => service.id),
    setup: state.pricing.catalogSetup,
    monthly: state.pricing.catalogMonthly,
    applied: false
  };
  combinedOfferDraft = draft;
  const chosen = new Set(Array.isArray(draft.serviceIds) ? draft.serviceIds : []);
  const combinedServices = lines.map(service => `<button type="button" class="combinedOfferService ${chosen.has(service.id) ? "on" : ""}" data-action="combined-offer-toggle-service" data-id="${esc(service.id)}" aria-pressed="${chosen.has(service.id)}"><i>${service.icon}</i><span>${esc(service.name)}</span><b>${chosen.has(service.id) ? "✓" : "+"}</b></button>`).join("");
  const combinedPanel = `<section class="combinedOfferPanel ${state.combinedOffer?.applied ? "isApplied" : ""}" data-testid="combined-offer-panel"><header><div><small>ONE PRICE FOR A CUSTOM COMBINATION</small><h3>Combine selected services</h3><p>Group any two or more services into one offer. Other selected services keep their individual prices. This stays separate from saved packages.</p></div>${state.combinedOffer?.applied ? `<span class="combinedOfferApplied">ACTIVE OFFER ✓</span>` : ""}</header><div class="combinedOfferServices" role="group" aria-label="Services in combined offer">${combinedServices || `<span class="combinedOfferEmpty">Select services first.</span>`}</div><div class="combinedOfferFields"><label><span>Offer name</span><input type="text" value="${esc(draft.name)}" data-combined-offer-draft="name" aria-label="Combined offer name"></label><label><span>One-time offer price</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" value="${Math.max(0, Number(draft.setup) || 0)}" data-combined-offer-draft="setup" aria-label="Combined one-time offer price"></span></label><label><span>Monthly offer price</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" value="${Math.max(0, Number(draft.monthly) || 0)}" data-combined-offer-draft="monthly" aria-label="Combined monthly offer price"></span></label><div class="combinedOfferActions"><button class="primaryBtn" data-action="combined-offer-apply" data-testid="apply-combined-offer">Apply Combined Offer</button>${state.combinedOffer?.applied ? `<button class="ghostBtn" data-action="combined-offer-remove">Remove</button>` : ""}</div></div></section>`;
  const rows = lines.length ? lines.map(service => `<article class="lineItemPriceRow" data-service-id="${service.id}" data-testid="line-item-price-row-${service.id}">
    <div class="lineItemPriceIdentity"><i>${service.icon}</i><div><b>${esc(service.name)}</b><span>${service.quantity > 1 ? `Qty ${service.quantity} · ` : ""}Ready time: ${esc(serviceTimeToLive(service))}</span></div></div>
    <label>One-time, per item<span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" inputmode="decimal" value="${esc(service.unitSetup)}" data-bind="pricing.serviceOverrides.${service.id}.setup" data-line-item-price="setup" data-service-id="${service.id}" data-testid="line-item-setup-${service.id}"></span></label>
    <label>Monthly, per item<span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" inputmode="decimal" value="${esc(service.unitMonthly)}" data-bind="pricing.serviceOverrides.${service.id}.monthly" data-line-item-price="monthly" data-service-id="${service.id}" data-testid="line-item-monthly-${service.id}"></span></label>
    <div class="lineItemPriceTotal"><small>Line total</small><b data-line-item-total="${service.id}">${money(service.setup)}${service.monthly ? ` + ${money(service.monthly)}/mo` : ""}</b></div>
  </article>`).join("") : empty("◇", "No systems in the launch cart", "Add a system first, then its individual price can be set here.");
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal lineItemPricingModal" data-testid="line-item-pricing-modal"><header class="modalHead"><div><small>Launch investment</small><h2>Set Prices</h2></div><button class="iconBtn" data-action="close-overlay" aria-label="Close item pricing">×</button></header><div class="modalBody">${combinedPanel}<section class="lineItemPricingIntro"><div><b>Or price every service separately.</b><p>Line-item pricing remains available whenever a combined offer is not required.</p></div><button class="ghostBtn" data-action="use-line-item-prices">Use line-item total</button></section><section class="lineItemPricingTotals" data-testid="line-item-pricing-totals"><div><span>Selected systems</span><b>${lines.length}</b></div><div><span>Agreed one-time price</span><b data-line-item-summary="setup">${money(total.standardSetup)}</b></div><div><span>Agreed monthly price</span><b data-line-item-summary="monthly">${money(total.monthly)}</b></div></section><div class="lineItemPricingRows">${rows}</div></div><footer class="modalFoot"><button class="primaryBtn" data-action="close-overlay" data-testid="line-item-pricing-done">Done</button></footer></section></div>`;
}

function packageTemplatePrice(template) {
  const services = template?.allServices ? Object.values(state.serviceConfig) : selectedServices();
  const fallbackSetup = services.reduce((sum, service) => sum + Math.max(0, Number(service.setup) || 0), 0);
  const fallbackMonthly = services.reduce((sum, service) => sum + Math.max(0, Number(service.monthly) || 0), 0);
  return {
    setup: Math.max(0, Number(template?.setup) || fallbackSetup),
    monthly: Math.max(0, Number(template?.monthly) || fallbackMonthly)
  };
}

function packageBuilderModal() {
  const packages = Array.isArray(state.packageConfig) ? state.packageConfig : [];
  const current = packageDraft || state.activePackage || {};
  const quantity = Math.max(1, Math.min(99, Math.floor(Number(current.quantity) || 1)));
  const unitSetup = Math.max(0, Number(current.setup) || 0);
  const unitMonthly = Math.max(0, Number(current.monthly) || 0);
  const cards = packages.length ? packages.map(item => {
    const selected = current.id === item.id;
    const configured = packageTemplatePrice(item);
    const icon = item.id === "complete-digital-infrastructure" ? "🏗️" : item.id === "digital-market-mastery" ? "🚀" : "📦";
    return `<button type="button" class="packageTemplateCard ${selected ? "on" : ""}" data-action="package-select" data-id="${esc(item.id)}" aria-pressed="${selected}"><i>${icon}</i><span><b>${esc(item.name)}</b><small>${item.allServices ? "Complete seven-service package" : "Build around the services selected today"}</small></span><em>${money(configured.setup)}${configured.monthly ? ` + ${money(configured.monthly)}/mo` : ""}</em></button>`;
  }).join("") : empty("＋", "No package templates yet", "Add a package template in Settings first.");
  const editor = current.id ? `<section class="packageBuilderEditor" data-testid="package-builder-editor"><label><span>Package name</span><input type="text" value="${esc(current.name)}" data-package-draft="name" aria-label="Package name"></label><label><span>Quantity</span><input type="number" min="1" max="99" value="${quantity}" data-package-draft="quantity" aria-label="Package quantity"></label><label><span>One-time, each</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" value="${unitSetup}" data-package-draft="setup" aria-label="Package setup price"></span></label><label><span>Monthly, each</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" value="${unitMonthly}" data-package-draft="monthly" aria-label="Package monthly price"></span></label><div class="packageBuilderTotal"><span>Package total</span><b data-package-preview="setup">${money(unitSetup * quantity)}</b><em data-package-preview="monthly">${unitMonthly ? `${money(unitMonthly * quantity)}/mo` : "No monthly fee"}</em></div></section>` : `<div class="packageBuilderPrompt">Choose a package above, then confirm its name, quantity and price.</div>`;
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal packageBuilderModal" data-testid="package-builder-modal"><header class="modalHead"><div><small>PACKAGE PRICING</small><h2>Build Package</h2><p>Use a saved package or keep pricing the plan service by service.</p></div><button class="iconBtn" data-action="close-overlay" aria-label="Close package builder">×</button></header><div class="modalBody"><div class="packageTemplateGrid">${cards}</div>${editor}</div><footer class="modalFoot"><button class="ghostBtn" data-action="close-overlay">Cancel</button><button class="primaryBtn" data-action="package-apply" data-testid="apply-package" ${current.id ? "" : "disabled"}>Add Package to Plan</button></footer></section></div>`;
}

function updatePackageBuilderPreview() {
  const root = document.querySelector('[data-testid="package-builder-modal"]');
  if (!root) return;
  const quantity = Math.max(1, Math.min(99, Math.floor(Number(packageDraft?.quantity) || 1)));
  const setup = Math.max(0, Number(packageDraft?.setup) || 0) * quantity;
  const monthly = Math.max(0, Number(packageDraft?.monthly) || 0) * quantity;
  const setupNode = root.querySelector('[data-package-preview="setup"]');
  const monthlyNode = root.querySelector('[data-package-preview="monthly"]');
  if (setupNode) setupNode.textContent = money(setup);
  if (monthlyNode) monthlyNode.textContent = monthly ? `${money(monthly)}/mo` : "No monthly fee";
}

function updateLineItemPricingPreview() {
  recalculatePrice();
  const root = document.querySelector('[data-testid="line-item-pricing-modal"]');
  if (!root) return;
  const total = priceSummary();
  root.querySelector('[data-line-item-summary="setup"]')?.replaceChildren(document.createTextNode(money(total.standardSetup)));
  root.querySelector('[data-line-item-summary="monthly"]')?.replaceChildren(document.createTextNode(money(total.monthly)));
  priceLineItems().forEach(service => {
    const line = root.querySelector(`[data-line-item-total="${service.id}"]`);
    if (line) line.textContent = `${money(service.setup)}${service.monthly ? ` + ${money(service.monthly)}/mo` : ""}`;
  });
}

function updateLaunchCartPreview() {
  const root = document.querySelector('[data-testid="launch-cart"]');
  if (!root) return;
  const selected = selectedServices();
  const outputs = {
    systems: selected.length,
    units: selected.reduce((sum, service) => sum + service.quantity, 0),
    setup: money(state.pricing.catalogSetup),
    monthly: money(state.pricing.catalogMonthly)
  };
  Object.entries(outputs).forEach(([key, value]) => {
    const element = root.querySelector(`[data-cart-summary="${key}"]`);
    if (element) element.textContent = value;
  });
  Object.values(state.serviceConfig).forEach(service => {
    const quantity = serviceQuantity(service.id);
    const row = root.querySelector(`[data-testid="launch-cart-row-${service.id}"]`);
    row?.classList.toggle("isSelected", quantity > 0);
    row?.classList.toggle("isInactive", quantity === 0);
    if (row) row.dataset.cartSelected = String(quantity > 0);
    const input = root.querySelector(`[data-cart-quantity="${service.id}"]`);
    if (input) input.value = String(quantity);
    const status = root.querySelector(`[data-cart-status="${service.id}"]`);
    if (status) {
      status.textContent = `${PILLARS[service.pillar]?.name || "Most Wanted service"} · ${quantity > 0 ? "In your plan" : state.services[service.id].status === "later" ? "Saved for later" : "Available"} `;
      const timing = document.createElement("small");
      timing.className = "serviceTimeToLive";
      timing.dataset.serviceTtl = service.id;
      timing.dataset.testid = `launch-cart-service-ttl-${service.id}`;
      timing.textContent = `· ⏱️ Ready time: ${serviceTimeToLive(service)}`;
      status.append(timing);
    }
  });
}

function renderRecommendation() {
  const urgency = opportunityUrgencyScores()[0];
  const included = selectedServices();
  const ranked = Object.values(state.serviceConfig).sort((a, b) => {
    const weight = service => state.services[service.id]?.status === "recommended" ? 0 : state.services[service.id]?.status === "optional" ? 1 : 2;
    return weight(a) - weight(b);
  });
  const suggested = ranked.slice(0, 3);
  const suggestionRows = suggested.map(service => {
    const item = state.services[service.id];
    const explanation = item.status === "recommended" ? service.problem : item.status === "optional" ? "Include this only if it strengthens today’s launch." : "Available, but not essential for today’s launch.";
    return `<article class="planSuggestion ${item.selected ? "isAdded" : ""}" data-service-id="${service.id}"><div class="planServiceIdentity"><i>${service.icon}</i><div><b>${esc(service.name)}</b><p>${esc(explanation)}</p></div></div><div class="planSuggestionFoot"><span>⏱️ ${esc(serviceTimeToLive(service))}</span><button class="${item.selected ? "ghostBtn" : "primaryBtn"} presenterOnly" data-action="plan-toggle-service" data-id="${service.id}" aria-pressed="${item.selected}">${item.selected ? "Included Today ✓" : "Include Today"}</button></div></article>`;
  }).join("");
  const finalRows = included.map(service => {
    const pricing = state.mode === "presenter"
      ? `<label>One-time setup<span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" inputmode="decimal" value="${esc(service.setup)}" data-bind="pricing.serviceOverrides.${service.id}.setup" data-plan-price="setup" data-service-id="${service.id}" aria-label="One-time setup price for ${esc(service.name)}"></span></label><label>Monthly<span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" inputmode="decimal" value="${esc(service.monthly)}" data-bind="pricing.serviceOverrides.${service.id}.monthly" data-plan-price="monthly" data-service-id="${service.id}" aria-label="Monthly price for ${esc(service.name)}"></span></label>`
      : `<span class="finalPlanPrice"><small>Setup</small><b>${money(service.setup)}</b></span><span class="finalPlanPrice"><small>Monthly</small><b>${money(service.monthly)}</b></span>`;
    return `<article class="finalPlanRow" data-service-id="${service.id}"><div class="planServiceIdentity"><i>${service.icon}</i><div><b>${esc(service.name)}${service.quantity > 1 ? ` · Qty ${service.quantity}` : ""}</b><span>Ready in ${esc(serviceTimeToLive(service))}</span></div></div>${pricing}<button class="iconBtn presenterOnly" data-action="plan-toggle-service" data-id="${service.id}" aria-label="Remove ${esc(service.name)} from final plan">×</button></article>`;
  }).join("");
  recalculatePrice();
  const totals = priceSummary();
  const urgencyLine = urgency ? `${urgency.score}/100 ${urgency.label.toLowerCase()} urgency around ${urgency.name.toLowerCase()}.` : "Based on what you told us.";
  return sceneFrame(`Choose what we <span class="accent">launch today</span>`, `Your answers point to the strongest place to start: ${urgencyLine} Finalise the scope and agreed price here. If eligible, this exact plan can be secured with a $1 commitment today.`, `<div class="planBuilder" data-testid="recommendation"><section class="planRecommendations"><header><small>START-TODAY RECOMMENDATION</small><h3>Strongest systems to launch now</h3><p>Each recommendation is tied to a problem you identified.</p></header><div class="planSuggestionList">${suggestionRows}</div><div class="ecosystemActions"><button class="ghostBtn" data-action="explore-all">See Every Service</button><button class="ghostBtn" data-action="go-infrastructure">Business Map</button><button class="ghostBtn presenterOnly" data-action="launch-cart" data-testid="adjust-launch-cart">Adjust Today’s Plan</button></div></section><section class="finalPlan"><header><div><small>TODAY’S FINAL PLAN</small><h3>What we launch when you say yes</h3><p class="planDollarCue"><strong>$1</strong> eligible commitment secures today’s launch</p></div><div class="finalPlanTotals"><span>Full setup <b data-plan-total="setup">${money(totals.standardSetup)}</b></span><span>Monthly <b data-plan-total="monthly">${money(totals.monthly)}</b></span></div></header><div class="finalPlanList">${finalRows || empty("＋", "No services selected for today", "Use Include Today on the recommended services.")}</div></section></div>`, { badge: `$1 eligible launch · ${included.length} service${included.length === 1 ? "" : "s"}`, checkpoint: "Is this the exact plan you are prepared to launch today?", checkpointKey: "recommendation" });
}

function recommendRow(service) {
  const selected = state.services[service.id];
  return `<article class="recommendRow"><i>${service.icon}</i><div><h4>${esc(service.name)}${service.quantity > 1 ? ` · Qty ${service.quantity}` : ""}</h4><p contenteditable="${state.mode === "presenter"}" data-reason="${service.id}">${esc(selected.reason)}</p><div class="recommendMeta"><span>${esc(service.problem)}</span><span class="serviceTimeToLive" data-service-ttl="${service.id}" data-testid="recommendation-service-ttl-${service.id}">⏱️ Ready time: ${esc(serviceTimeToLive(service))}</span><span class="servicePrice">${money(service.setup)} setup${Number(service.monthly) ? ` + ${money(service.monthly)}/mo` : ""}</span></div></div><span class="chip">${service.quantity > 1 ? `Included · Qty ${service.quantity}` : "Included"}</span></article>`;
}

function renderInfrastructure() {
  const stageAssets = [
    "app/assets/storefront/stage-0.png", "app/assets/storefront/stage-1.webp", "app/assets/storefront/stage-2.png", "app/assets/storefront/stage-3.png",
    "app/assets/storefront/stage-4.png", "app/assets/storefront/stage-5.webp", "app/assets/storefront/stage-6.png", "app/assets/storefront/stage-7.webp"
  ];
  const positions = {
    website: { x: 220, y: 135 }, seo: { x: 500, y: 120 }, reviews: { x: 780, y: 135 },
    ads: { x: 90, y: 300 }, crm: { x: 910, y: 300 }, receptionist: { x: 270, y: 440 }, chatbot: { x: 730, y: 440 }
  };
  const services = Object.values(state.serviceConfig);
  const activeCount = services.filter(service => state.services[service.id]?.selected).length;
  const lines = services.map(service => {
    const position = positions[service.id];
    const item = state.services[service.id];
    return `<line x1="${position.x}" y1="${position.y}" x2="500" y2="286" class="systemConnection ${item.status} ${item.selected ? "active" : "muted"}" data-service-line="${service.id}" data-status="${item.status}" vector-effect="non-scaling-stroke"><title>${esc(service.name)} ${item.selected ? "connected" : item.status === "optional" ? "available as an add-on" : "saved for later"}</title></line>`;
  }).join("");
  const nodes = services.map(service => {
    const position = positions[service.id];
    const item = state.services[service.id];
    const quantity = serviceQuantity(service.id);
    const statusLabel = item.selected ? `Included${quantity > 1 ? ` · Qty ${quantity}` : ""}` : item.status === "optional" ? "Optional" : "Later";
    const content = `<i>${service.icon}</i><b>${esc(service.name)}</b><span class="infrastructureNodeMeta">${statusLabel}</span>`;
    return `<article class="infrastructureNode moduleCard ${item.status} ${item.selected ? "active" : "muted"}" data-service-node="${service.id}" data-status="${item.status}" style="--node-x:${position.x / 10}%;--node-y:${position.y / 5.6}%" data-testid="infrastructure-node-${service.id}">${state.mode === "presenter" ? `<button type="button" class="infrastructureNodeToggle" data-action="map-service-toggle" data-id="${service.id}" aria-pressed="${item.selected}" aria-label="${item.selected ? "Remove" : "Add"} ${esc(service.name)} ${item.selected ? "from" : "to"} the plan">${content}</button>` : content}</article>`;
  }).join("");
  const business = esc(state.prospect.business || "Your local business");
  return sceneFrame("How your plan works <span class=\"accent\">together</span>", "Each service has one job, and they all support the same goal: helping more customers book with you.", `<section class="connectedSystemMap" data-testid="infrastructure-map" data-image-ready="false" aria-label="Services working together for ${business}"><svg class="systemConnections" viewBox="0 0 1000 560" preserveAspectRatio="none" role="img" aria-label="Connections between selected Most Wanted services and ${business}" data-testid="infrastructure-lines" style="visibility:hidden"><g>${lines}</g></svg><div class="infrastructureNodes" role="list" aria-label="Available Most Wanted services">${nodes}</div><article class="businessHub" data-testid="business-hub"><img class="storefrontImage" src="${stageAssets[activeCount]}" alt="${business} with ${activeCount} of ${services.length} services selected" data-storefront-stage="${activeCount}" data-testid="storefront-image" decoding="async"><div class="businessHubLabel"><small>Built around</small><h3>${business}</h3><span>${activeCount} of ${services.length} systems connected</span></div></article></section><div class="connectedSystemLegend"><span><i class="legendActive"></i>In your plan</span><span><i class="legendOptional"></i>Could add later</span><span><i class="legendLater"></i>Not needed now</span></div>`, { badge: `${activeCount} services in your plan`, hideNext: true, extra: `<button class="ghostBtn" data-action="go-ecosystem">Back To Your Plan</button>` });
}

let infrastructureResizeObserver = null;
const infrastructureImageMasks = new WeakMap();

function cacheInfrastructureImageMask(image) {
  if (!image?.complete || !image.naturalWidth || !image.naturalHeight) return null;
  const cached = infrastructureImageMasks.get(image);
  if (cached) return cached;
  try {
    const maxSide = 480;
    const ratio = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
    const width = Math.max(2, Math.round(image.naturalWidth * ratio));
    const height = Math.max(2, Math.round(image.naturalHeight * ratio));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) return null;
    context.clearRect(0, 0, width, height);
    context.drawImage(image, 0, 0, width, height);
    const mask = { width, height, alpha: context.getImageData(0, 0, width, height).data };
    infrastructureImageMasks.set(image, mask);
    return mask;
  } catch {
    return null;
  }
}

function containedInfrastructureImageRect(image) {
  const rect = image.getBoundingClientRect();
  if (!image.naturalWidth || !image.naturalHeight || !rect.width || !rect.height) return rect;
  const naturalRatio = image.naturalWidth / image.naturalHeight;
  const boxRatio = rect.width / rect.height;
  const fit = getComputedStyle(image).objectFit || "contain";
  let width = rect.width;
  let height = rect.height;
  if (fit === "cover") {
    if (naturalRatio > boxRatio) width = height * naturalRatio;
    else height = width / naturalRatio;
  } else if (fit !== "fill") {
    if (naturalRatio > boxRatio) height = width / naturalRatio;
    else width = height * naturalRatio;
  }
  return {
    left: rect.left + (rect.width - width) / 2,
    top: rect.top + (rect.height - height) / 2,
    width,
    height
  };
}

function visibleInfrastructureStoreEdge(image, mask, from, to) {
  if (!image || !mask) return null;
  const box = image.getBoundingClientRect();
  const draw = containedInfrastructureImageRect(image);
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.max(1, Math.hypot(dx, dy));
  const steps = 640;
  for (let step = 0; step <= steps; step += 1) {
    const progress = step / steps;
    const x = from.x + dx * progress;
    const y = from.y + dy * progress;
    if (x < box.left || x > box.right || y < box.top || y > box.bottom || x < draw.left || x > draw.left + draw.width || y < draw.top || y > draw.top + draw.height) continue;
    const maskX = Math.max(0, Math.min(mask.width - 1, Math.floor(((x - draw.left) / draw.width) * mask.width)));
    const maskY = Math.max(0, Math.min(mask.height - 1, Math.floor(((y - draw.top) / draw.height) * mask.height)));
    if (mask.alpha[(maskY * mask.width + maskX) * 4 + 3] >= 82) {
      const nudge = Math.min(2.6, (length / steps) * 1.35);
      return { x: x + (dx / length) * nudge, y: y + (dy / length) * nudge };
    }
  }
  return null;
}

function updateInfrastructureConnections() {
  const map = document.querySelector("[data-testid='infrastructure-map']");
  const image = map?.querySelector("[data-testid='storefront-image']");
  const svg = map?.querySelector("[data-testid='infrastructure-lines']");
  if (!map || !image || !svg || map.dataset.imageReady !== "true") return;
  const mapRect = map.getBoundingClientRect();
  const imageRect = image.getBoundingClientRect();
  if (!mapRect.width || !mapRect.height || !imageRect.width || !imageRect.height) return;
  const point = value => ({
    x: ((value.x - mapRect.left) / mapRect.width) * 1000,
    y: ((value.y - mapRect.top) / mapRect.height) * 560
  });
  const center = rect => ({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
  const hub = center(imageRect);
  const mask = cacheInfrastructureImageMask(image);
  Object.keys(state.serviceConfig).forEach(id => {
    const node = map.querySelector(`[data-service-node="${id}"]`);
    const line = svg.querySelector(`[data-service-line="${id}"]`);
    if (!node || !line) return;
    const startClient = center(node.getBoundingClientRect());
    const endClient = visibleInfrastructureStoreEdge(image, mask, startClient, hub) || hub;
    const start = point(startClient);
    const end = point(endClient);
    line.setAttribute("x1", start.x.toFixed(2));
    line.setAttribute("y1", start.y.toFixed(2));
    line.setAttribute("x2", end.x.toFixed(2));
    line.setAttribute("y2", end.y.toFixed(2));
    line.dataset.edgeMode = mask ? "visible-alpha" : "center-fallback";
  });
  svg.style.visibility = "visible";
  map.dataset.connectionsReady = "true";
}

function requestInfrastructureConnections() {
  requestAnimationFrame(() => requestAnimationFrame(updateInfrastructureConnections));
}

function trackInfrastructureConnections(duration = 900) {
  const end = performance.now() + duration;
  const redraw = timestamp => {
    updateInfrastructureConnections();
    if (timestamp < end) requestAnimationFrame(redraw);
  };
  requestAnimationFrame(redraw);
}

async function prepareInfrastructureMap() {
  infrastructureResizeObserver?.disconnect();
  infrastructureResizeObserver = null;
  const map = document.querySelector("[data-testid='infrastructure-map']");
  const image = map?.querySelector("[data-testid='storefront-image']");
  if (!map || !image) return;
  const ready = () => {
    if (!map.isConnected) return;
    const mask = cacheInfrastructureImageMask(image);
    map.dataset.imageReady = "true";
    map.dataset.alphaMaskReady = mask ? "true" : "fallback";
    image.dataset.imageReady = "true";
    requestInfrastructureConnections();
    trackInfrastructureConnections();
    if (typeof ResizeObserver === "function") {
      infrastructureResizeObserver = new ResizeObserver(requestInfrastructureConnections);
      infrastructureResizeObserver.observe(map);
      infrastructureResizeObserver.observe(image);
    }
  };
  if (image.complete && image.naturalWidth) {
    try { await image.decode(); } catch { /* A loaded image can still be positioned when decode is unavailable. */ }
    ready();
  } else {
    image.addEventListener("load", ready, { once: true });
    image.addEventListener("error", () => { map.dataset.imageReady = "error"; }, { once: true });
  }
}

function resolvedDemoUrl(demo) {
  const id = typeof demo === "string" ? demo : demo?.id;
  const config = typeof demo === "string" ? state.demosConfig[id] : demo;
  if (!id) return "";
  if (id === "website") {
    return String(state.prospect.demoUrl || state.prospect.websiteUrl || state.demos[id]?.url || config?.url || "").trim();
  }
  return String(state.demos[id]?.url || config?.url || "").trim();
}

function renderProof() {
  const relevant = Object.values(state.demosConfig).filter(demo => state.showAllDemos || !demo.service || state.services[demo.service]?.selected);
  const selected = state.demosConfig[state.selectedDemo];
  const selectedUrl = selected ? resolvedDemoUrl(selected) : "";
  return sceneFrame("See your plan <span class=\"accent\">working</span>", "Try the website and selected systems now, so you can approve today’s plan with confidence instead of buying on promises.", `<div class="demoLayout"><nav class="demoQueue">${relevant.map(demo => `<button class="${state.selectedDemo === demo.id ? "on" : ""}" data-action="select-demo" data-id="${demo.id}"><i>${demo.icon}</i><b>${esc(demo.name)}</b><span class="${state.demos[demo.id]?.viewed ? "demoSeen" : ""}">${state.demos[demo.id]?.viewed ? "Viewed ✅" : "Open"}</span></button>`).join("")}</nav><section class="demoStage">${selectedUrl ? `<iframe src="${esc(selectedUrl)}" title="${esc(selected?.name)}" loading="eager" allow="autoplay; fullscreen"></iframe><div class="demoTools"><button data-action="open-demo" data-url="${esc(selectedUrl)}" data-title="${esc(selected?.name || "Website demo")}">Open Full Screen</button></div>` : `<div class="demoEmpty"><div><i>${selected?.icon || "🧪"}</i><b>${selected ? esc(selected.name) : "Choose a demo"}</b><p>${selected ? "This demo link has not been added yet. We will only show real working examples." : "The demos that match your plan appear first. You can open every demo if you want to see more."}</p></div></div>`}</section></div>`, { badge: state.showAllDemos ? "All demos" : "Proof for today’s plan", extra: `<button class="ghostBtn" data-action="toggle-all-demos">${state.showAllDemos ? "Show Demos For My Plan" : "See Every Demo"}</button>`, checkpoint: "Have you seen enough to decide whether we launch this today?", checkpointKey: "product" });
}

function renderWebsite() {
  const url = String(state.prospect.demoUrl || state.prospect.websiteUrl || "").trim();
  const preview = String(state.prospect.previewImageUrl || "").trim();
  const changes = state.websiteLaunch.requestedChanges || [];
  const websiteStage = url
    ? `<iframe src="${esc(url)}" title="Launch version prepared for ${esc(state.prospect.business || "your business")}" loading="eager" allow="fullscreen"></iframe><div class="demoTools"><button data-action="website-launch-open" data-url="${esc(url)}" data-title="${esc(state.prospect.business || "Website launch version")}">Open Full Screen</button></div>`
    : preview
      ? `<img class="websitePreviewImage" src="${esc(preview)}" alt="Launch version prepared for ${esc(state.prospect.business || "your business")}"><div class="demoTools"><button data-action="website-launch-open" data-url="${esc(preview)}" data-title="${esc(state.prospect.business || "Website launch version")}">Open Full Screen</button></div>`
      : `<div class="demoEmpty"><div><i>🖥️</i><b>Your website preview</b><p>The website preview has not been added yet. Any changes you ask for can still be written down now.</p></div></div>`;
  const visibleStart = Math.max(0, changes.length - 3);
  const visibleChanges = changes.slice(visibleStart);
  const changeRows = visibleChanges.length
    ? visibleChanges.map((change, visibleIndex) => { const index = visibleStart + visibleIndex; return `<article class="recommendRow" data-testid="website-change-${index}"><i>✍️</i><div><h4>Requested change ${index + 1}</h4><p>${esc(change)}</p></div>${state.mode === "presenter" ? `<button class="ghostBtn" data-action="website-change-remove" data-index="${index}" aria-label="Remove requested change ${index + 1}">Remove</button>` : ""}</article>`; }).join("")
    : empty("✍️", "No changes added yet", "Add each requested change separately so everyone agrees on what will be done.");
  const editor = state.mode === "presenter"
    ? `${field("websiteLaunch.draftChange", "Requested website change", "textarea", { full: true, placeholder: "Add one clear change at a time" })}<button class="primaryBtn" data-action="website-change-add" data-testid="add-website-change">Add To Launch Version</button>`
    : "";
  const changeSummary = changes.length > 3 ? `<button class="ghostBtn websiteChangesAll" data-action="website-changes" data-testid="website-changes-all">Review all ${changes.length} changes</button>` : "";
  return sceneFrame(`Your website. Your <span class="accent">version.</span>`, "Review the website together and write down every change you want before it goes live.", `<div class="heardGrid" data-testid="website-launch-version"><section class="demoStage">${websiteStage}</section><aside class="heardEditor websiteChangeEditor" style="display:flex;min-height:0;flex-direction:column;gap:12px"><div><h3 style="margin:0">Changes before it goes live</h3><p class="sceneLead">Add one request per note. The latest three stay visible here.</p></div>${editor}<div class="recommendedList websiteChangesSummary" style="padding:0">${changeRows}</div>${changeSummary}</aside></div>`, { badge: `${changes.length} requested change${changes.length === 1 ? "" : "s"}` });
}

function websiteChangesModal() {
  const changes = state.websiteLaunch.requestedChanges || [];
  const rows = changes.length
    ? changes.map((change, index) => `<article class="recommendRow" data-testid="website-change-modal-${index}"><i>✍️</i><div><h4>Requested change ${index + 1}</h4><p>${esc(change)}</p></div>${state.mode === "presenter" ? `<button class="ghostBtn" data-action="website-change-remove" data-index="${index}">Remove</button>` : ""}</article>`).join("")
    : empty("✍️", "No requested changes yet", "Add changes from the website scene.");
  return simpleModal("Your Complete Change List", `<div class="websiteChangesModal" data-testid="website-changes-modal"><p class="sceneLead">Every agreed change stays attached to this launch version.</p><div class="recommendedList">${rows}</div></div>`);
}

function renderDecision() {
  const standardCards = [
    ["🎯", "What You Want", state.heard.objective || state.prospect.growthGoal || "The desired outcome has not been entered."],
    ["🧩", "Why This Fits", "The plan is based on what you told us, and you have seen the main services working."],
    ["🤝", "What You Need To Do", "Send your business details and account access through the secure onboarding portal, then approve the work when we ask. Your dedicated support team handles the rest."]
  ];
  const timingCard = `<article class="decisionCard summaryCard decisionTimingCard" data-testid="decision-time-to-live"><span class="cardIcon">⏱️</span><b>Ready Time</b><p>${esc(overallLaunchTiming())}</p><button class="ghostBtn" data-action="service-timing">View Service Timing</button></article>`;
  return sceneFrame("Your <span class=\"accent\">decision</span> summary", "This is the exact result, plan, ready time and responsibility you are deciding whether to launch today.", `<div class="fourGrid" data-testid="decision-summary">${standardCards.slice(0, 2).map(([icon, name, copy]) => `<article class="decisionCard summaryCard"><span class="cardIcon">${icon}</span><b>${name}</b><p>${esc(copy)}</p></article>`).join("")}${timingCard}${standardCards.slice(2).map(([icon, name, copy]) => `<article class="decisionCard summaryCard"><span class="cardIcon">${icon}</span><b>${name}</b><p>${esc(copy)}</p></article>`).join("")}</div>`, { badge: "Ready for today’s decision", checkpoint: "Does this solve what you wanted us to solve today?", checkpointKey: "decision" });
}

function serviceTimingModal() {
  return simpleModal("Service Ready Times", `<div class="serviceTimingModal" data-testid="service-timing-modal">${serviceTimingRows(selectedServices(), "decision")}<div class="decisionTimingSummary"><span>Overall ready time</span><strong>${esc(overallLaunchTiming())}</strong></div></div>`);
}

function renderSupport() {
  const s = state.support;
  const join = values => values.filter(Boolean).join(" ");
  const systems = selectedServices().map(service => service.name).join(", ") || "the systems selected together";
  const cards = [
    ["🛠️", "We Build It", `Most Wanted designs, configures and completes ${systems}. You are not handed a blank tool and a help article.`],
    ["🔗", "We Connect It", "We connect the services so calls, messages and customer details go to the right place, then test everything before launch."],
    ["🛟", "We Support It", join([s.onboarding, "Website hosting is handled within the Most Wanted service, and lifetime human support stays available for what we build.", s.channels, s.hours && `Operating hours: ${s.hours}.`, s.responseTarget && `Response target: ${s.responseTarget}.`, s.changePolicy, s.urgentProcess, s.monitoring, s.updates, s.approval, s.included])],
    ["🔐", "You Own It", join([s.ownership || "You own the website, domain and business data created for your launch.", s.transfer || "Ownership and transfer are kept clear so the business remains in control."])]
  ];
  const body = `<div class="fourGrid" data-testid="done-for-you-support">${cards.map(([icon, name, copy]) => `<article class="supportCard"><span class="cardIcon">${icon}</span><b>${name}</b><p>${esc(copy)}</p></article>`).join("")}</div>`;
  return sceneFrame("You are <span class=\"accent\">not</span> buying software and being left to figure it out.", "Most Wanted handles the build, connection, hosting and human support. You keep control of what belongs to your business.", body, { badge: "Done for you · owned by you" });
}

function renderPledge() {
  const g = state.guarantee;
  if (!guaranteeFullyConfigured()) return sceneFrame("The on-time promise is <span class=\"accent\">not</span> included", "This promise is not part of the current plan.", empty("🛡️", "No on-time promise is active", "Ask us if you would like more detail about ready times."), { badge: "Not included" });
  return sceneFrame("The Most Wanted <span class=\"accent\">On-Time</span> Launch Pledge", `If Most Wanted misses ${esc(g.deadlineRule)} for work within our control, you receive both items below.`, `<div class="pledgeLayout pledgeLayoutSimple" data-testid="on-time-pledge"><section class="pledgeCondition" data-testid="pledge-condition"><span class="cardIcon">⏱️</span><div><small>When it applies</small><h3>${esc(g.trigger)}</h3><p>The promise uses the ready times written in your signed Launch Plan.</p></div></section><section class="pledgeRemedies" aria-label="What the customer receives"><article class="pledgeRemedy buyerRemedy" data-testid="pledge-store-credit"><span class="pledgeNumber">💳</span><div><small>What you receive</small><h3>${money(g.buyerCredit)} ${esc(g.buyerCreditLabel)}</h3><p>We issue this directly to you if the promise applies.</p></div></article><div class="pledgePlus" aria-label="plus">+</div><article class="pledgeRemedy charityRemedy" data-testid="pledge-meals"><span class="pledgeNumber">🍽️</span><div><small>What we also give</small><h3>${number(g.mealQuantity)} meals donated</h3><p>Most Wanted also funds ${number(g.mealQuantity)} meals through ${esc(g.charityName)}. This is in addition to your store credit.</p></div></article></section><div class="recommendMeta pledgeMeta"><span>Pledge dated ${esc(g.versionDate)}</span>${g.termsUrl ? `<a class="chip" href="${esc(g.termsUrl)}" target="_blank" rel="noopener">View full terms</a>` : ""}</div></div>`, { badge: `${money(g.buyerCredit)} credit + ${number(g.mealQuantity)} meals` });
}

function renderLaunch() {
  buildLaunchPlan();
  const reviewIncluded = Boolean(state.services.reviews?.selected);
  const stages = [
    ["today", "🚀", "Today", "Agreement, payment and onboarding", `You approve the plan, complete payment and use the secure onboarding portal.${reviewIncluded ? " Your Google Review System also begins." : ""}`],
    ["72", "🛠️", "Next 3 days", "Your launch begins", "Your website goes live and we work through the other agreed parts of your plan."],
    ["week", "📈", "First week", "Regular SEO launches", "Regular SEO is launched and the remaining agreed deliverables are handed over."],
    ["ongoing", "🤝", "Ongoing", "Review, tighten and improve", "At the end of the first month, we review regular SEO and tighten the process for the next stage of growth."]
  ];
  const timeline = stages.map(([id, icon, phase, headline, copy]) => `<section class="timelineGroup launchStage" data-launch-phase="${id}"><h3><span>${icon}</span> ${phase}</h3><div class="launchStageDetail"><b>${headline}</b><p>${copy}</p></div></section>`).join("");
  return sceneFrame("What happens after you say <span class=\"accent\">yes</span>", "Four clear stages, from agreeing the plan today to improving it after launch.", `<div class="launchGrid launchGridSimple" data-testid="launch-plan"><div class="timeline">${timeline}</div><aside class="motiveCard"><i>✅</i><div><h3>You always know what happens next</h3><p>Your onboarding portal shows what we need, what Most Wanted is doing and what is ready for you to review.</p></div><div class="launchWindowSummary" data-testid="launch-plan-overall-window"><small>Ready times for your plan</small><strong>${esc(overallLaunchTiming())}</strong></div></aside></div>`, { badge: "Four clear stages" });
}

function launchTaskMarkup(task) {
  return `<article class="task ${task.serviceId ? "serviceLaunchTask" : ""}" ${task.serviceId ? `data-service-id="${task.serviceId}" data-testid="launch-plan-service-${task.serviceId}"` : ""}><b>${esc(task.name)}</b><small class="${task.serviceId ? "serviceTimeToLive" : ""}" ${task.serviceId ? `data-service-ttl="${task.serviceId}"` : ""}>${task.serviceId ? "⏱️ Ready time: " : ""}${esc(task.duration)} · Needs: ${esc(task.dependency)}</small><small class="taskOwner">${/Most Wanted/.test(task.owner) && /Customer/.test(task.owner) ? "Most Wanted + You" : /Most Wanted/.test(task.owner) ? "Most Wanted Handles This" : "We Need This From You"}${task.guaranteed ? " · On-time promise" : ""}</small></article>`;
}

function launchTasksModal() {
  const phase = LAUNCH_PHASES[launchTasksGroup] || LAUNCH_PHASES.today;
  const tasks = state.launchPlan.tasks.filter(task => task.group === launchTasksGroup);
  return simpleModal(`${phase.label} Tasks`, `<div class="launchTasksModal" data-testid="launch-tasks-modal"><p class="sceneLead">Every task remains saved in your Launch Plan.</p><div class="taskList">${tasks.map(launchTaskMarkup).join("") || empty("✓", "Nothing due in this phase", "The next phase contains the work for this plan.")}</div></div>`);
}

function renderCalculator() {
  // The calculator always reads the current configured launch price. It is not a second pricing editor.
  recalculatePrice();
  const result = calculateBreakEven();
  const basisNote = result.basis === "revenue equivalent"
    ? "Because profit was not entered, this is a revenue-equivalent estimate using the average job price, not a profit calculation."
    : "This uses the profit you said the business keeps from each completed job.";
  return sceneFrame("How many extra jobs would <span class=\"accent\">cover</span> the cost?", "Your plan price is already linked. Add the value of a completed job to see the answer.", `<div class="calculatorGrid" data-testid="break-even"><section class="calcInputs"><div class="calculatorPlanSync"><span>Current selected plan</span><b>${money(result.firstYear)}</b><small>Automatically synced from your launch plan and today’s saving.</small></div><div class="formGrid">${field("pricing.setup", "One-time setup price, linked", "number", { min: 0, readonly: true, currency: true })}${field("pricing.monthly", "Monthly support, linked", "number", { min: 0, readonly: true, currency: true })}${field("prospect.averageJobRevenue", "Average completed job value", "number", { min: 0, currency: true })}${field("prospect.grossProfitPerJob", "Profit kept from each job", "number", { min: 0, currency: true })}${field("prospect.customerLifetimeValue", "Optional repeat-customer value", "number", { min: 0, currency: true })}${field("customScenarioJobs", "Extra completed jobs per month", "number", { min: 0 })}</div></section><section class="calcResult"><small>Jobs needed to cover the cost</small><h3>${result.perJob ? `${number(result.jobs)} jobs` : "Add your numbers"}</h3><p>${result.perJob ? `Based on the numbers entered, about ${number(result.jobs)} extra completed jobs would cover the first-year cost.` : "Enter the value of one completed job. If you know the profit, use that for the most accurate result."}</p>${result.perJob ? `<p class="fieldHelp">${basisNote}</p>` : ""}<div class="scenarioTabs">${[["quarterly1", "1 per quarter"], ["monthly1", "1 per month"], ["monthly2", "2 per month"], ["custom", "Custom"]].map(([id, label]) => `<button class="${state.calculatorScenario === id ? "on" : ""}" data-action="scenario" data-id="${id}">${label}</button>`).join("")}</div><div class="calcStats"><div class="calcStat"><span>Current plan cost</span><b>${money(result.firstYear)}</b></div><div class="calcStat"><span>Estimated time to cover it</span><b>${result.months ? `${number(result.months)} mo` : "Not available"}</b></div><div class="calcStat"><span>Example value over 12 months</span><b>${money(result.yearlyValue)}</b></div></div><p class="fieldHelp">This example only uses the numbers entered here. It is not a performance guarantee.</p></section></div>`, { badge: result.perJob ? "Based on your numbers" : "Add your numbers" });
}

function renderClose() {
  const selected = selectedServices();
  const price = priceSummary();
  const calc = calculateBreakEven();
  const concern = state.checkpoints.certainty && state.checkpoints.certainty !== "Nothing" ? state.checkpoints.certainty : "";
  const summary = [
    ["🧩", "Services in your plan", selected.length ? selected.map(service => service.quantity > 1 ? `${service.name} × ${service.quantity}` : service.name).join(", ") : "No services selected"],
    ["💵", "Price to get started", `${money(price.effectiveSetup)} today${price.monthly ? ` + ${money(price.monthly)} monthly` : ""}`],
    ["📈", "Jobs to cover it", calc.perJob ? `${number(calc.jobs)} extra completed jobs` : "Add the profit kept from each job"],
    ["⏱️", "Ready time", overallLaunchTiming()]
  ];
  return sceneFrame("Shall we get <span class=\"accent\">started?</span>", "If anything is still unclear, ask now. If everything makes sense, move on to the agreement, payment and secure onboarding portal.", `<div class="recommendGrid" data-testid="close-decision"><section class="recommendedList"><div class="fourGrid">${summary.map(([icon, name, copy]) => `<article class="decisionCard summaryCard"><span class="cardIcon">${icon}</span><b>${esc(name)}</b><p>${esc(copy)}</p></article>`).join("")}</div></section><aside class="heardSide"><h3>${concern ? `Let’s talk about ${esc(concern).toLowerCase()}.` : "Everything is clear."}</h3><p>${concern ? "Open the answer that matches your question, then come back here when you are ready." : "We have reviewed your plan, tried the services, covered the ready times, price and possible payback."}</p><div class="confirmBlock"><b>One clear choice</b><p>Start the selected plan now, or use the 24-hour build window. We will not chase you with repeated follow-up calls.</p></div><button class="ghostBtn" style="margin-top:12px" data-action="objections">${concern ? `Talk About ${esc(concern)}` : "Ask A Question"}</button></aside></div>`, {
    badge: "Decision",
    extra: `<button class="ghostBtn" data-action="close-no" data-testid="close-not-today">Not Today</button>`,
    nextAction: "close-yes",
    nextLabel: "Launch My Growth System"
  });
}

function renderCertainty() {
  const prompt = "If the numbers make sense, what, if anything, would still stop you from moving forward today?";
  return sceneFrame("Before I show you the <span class=\"accent\">investment...</span>", prompt, `<div class="threeGrid checkpointOptionGrid" role="group" aria-label="${esc(prompt)}">${CHECKPOINT_OPTIONS.certainty.map((item, index) => checkpointChoiceButton("certainty", item, { className: "choice", icon: ["✅", "📈", "🤝", "⏱️", "💵", "👥"][index] })).join("")}</div>`, { badge: "One honest question", checkpoint: "Choose the closest answer. Your selection is saved until you press Continue." });
}

function renderLowUrgency() {
  const leaks = calculateLeaks();
  const monthly = leaks.monthly || 0;
  return sceneFrame("Is this worth fixing now, or is it honestly not a current <span class=\"accent\">priority?</span>", "This check only uses what you told us: the main problem, your goal, the ready time and any numbers entered.", `<div class="recommendGrid"><section class="recommendedList"><div class="summaryRows"><div class="summaryRow"><label>Main problem</label><textarea readonly>${esc(state.leaks.primary ? opportunityLossLabel(state.leaks.primary) : "Not chosen yet")}</textarea></div><div class="summaryRow"><label>Calls and enquiries each month</label><textarea readonly>${esc(state.prospect.monthlyOpportunities || "Not known")}</textarea></div><div class="summaryRow"><label>Possible cost over 90 days</label><textarea readonly>${monthly ? money(monthly * 3) : "We need more numbers to work this out"}</textarea></div><div class="summaryRow"><label>Your goal</label><textarea readonly>${esc(state.heard.objective)}</textarea></div><div class="summaryRow"><label>Why it matters</label><textarea readonly>${esc(state.heard.motive)}</textarea></div><div class="summaryRow"><label>Soonest ready time</label><textarea readonly>${esc(earliestLaunch())}</textarea></div></div></section><aside class="heardSide"><h3>What would need to be true for this to become a priority?</h3>${field("prospect.priorityCondition", "Your answer", "textarea", { full: true })}</aside></div>`, { badge: "Priority check" });
}

function earliestLaunch() {
  return overallLaunchTiming();
}

function renderPrice() {
  recalculatePrice();
  const selected = selectedServices();
  const visibleSelected = selected.slice(0, 3);
  const hiddenSelectedCount = Math.max(0, selected.length - visibleSelected.length);
  const calc = calculateBreakEven();
  const price = priceSummary();
  const today = price.timing !== "after";
  const setupEditor = "";
  const dollarCommitment = state.pricing.dollarCommitmentEligible ? `<article class="summaryCard eligibleCommitment ${state.pricing.dollarCommitmentSelected ? "isSelected" : ""}" data-testid="eligible-dollar-commitment"><span class="cardIcon">$1</span><div><b>Secure today’s launch with $1</b><p>Applied to the agreed price. It is not the full service price.</p></div><button class="${state.pricing.dollarCommitmentSelected ? "primaryBtn" : "ghostBtn"}" data-action="select-dollar-commitment" aria-pressed="${state.pricing.dollarCommitmentSelected}">${state.pricing.dollarCommitmentSelected ? "$1 selected ✓" : "Choose $1 start"}</button></article>` : "";
  const commitment = `<section class="commitmentPanel" data-testid="commitment-selector"><header><div><small>Choose your launch timing</small><h3>When would you like to begin?</h3></div><span class="chip">20% saving is for starting on this call</span></header><div class="commitmentTiming" role="group" aria-label="Purchase timing"><button class="${today ? "primaryBtn" : "ghostBtn"}" data-action="price-timing" data-value="today" aria-pressed="${today}"><span class="timingFlame" aria-hidden="true">🔥</span><span>Today on this call</span></button><button class="${!today ? "primaryBtn" : "ghostBtn"}" data-action="price-timing" data-value="after" aria-pressed="${!today}">Within 24 hours</button></div><div class="discountControl ${today ? "active" : "inactive"}"><div class="discountCopy"><span>On-call saving</span><b data-price-output="discount-label">${price.discount}%</b><small>${today ? "The saving is applied immediately when you launch on this call." : "Choose Today on this call to apply the on-call saving."}</small></div><input type="range" min="1" max="20" step="1" value="${Math.min(20, Math.max(1, Number(state.pricing.discount) || 1))}" data-bind="pricing.discount" data-testid="paid-today-discount-slider" aria-label="On-call discount percentage" ${today ? "" : "disabled"}><div class="discountScale"><span>Saving selected</span><strong><span data-price-output="discount-inline">${price.discount}%</span> off today</strong></div><div class="downPaymentPreview" data-testid="down-payment-preview"><span>Due today</span><b data-price-output="down-payment">${money(price.downPayment)}</b><small data-price-output="down-payment-copy">${state.pricing.dollarCommitmentSelected ? "Your $1 launch commitment" : "Full start-today setup price"}</small></div></div>${dollarCommitment}</section>`;
  const totals = `<div class="priceTotals" data-testid="price-totals"><div class="priceTotal"><span>Standard setup price</span><b data-price-output="standard-setup">${money(price.standardSetup)}</b></div><div class="priceTotal saving"><span>You save today</span><b data-price-output="saving">${money(price.saving)}</b></div><div class="priceTotal"><span>Monthly support</span><b data-price-output="monthly">${money(price.monthly)}</b></div></div>`;
  const academy = `<section class="summaryCard growthAcademy" data-testid="growth-academy"><span class="cardIcon">🎓</span><b>Most Wanted Growth Academy</b>${state.pricing.academyRevealed ? `<p><strong>Lifetime access</strong> to a growing 10–20+ video library, with useful new lessons added regularly. There is no public checkout and it cannot be purchased separately.${today ? " It is included when you start today." : " It is not included when you start after this call."}</p>` : `<p>Included today.</p>`}<button class="ghostBtn" data-action="toggle-academy">${state.pricing.academyRevealed ? (today ? "Academy included ✓" : "Included when you start today") : "Show Growth Academy"}</button></section>`;
  const priceSystems = visibleSelected.map(service => `<div class="priceSystem" data-service-id="${service.id}"><i>${service.icon}</i><b>${esc(service.name)}</b>${service.quantity > 1 ? `<span class="chip">Qty ${service.quantity}</span>` : ""}</div>`).join("");
  const moreSystems = hiddenSelectedCount ? `<div class="priceSystem priceSystemMore"><i>＋</i><b>${hiddenSelectedCount} more</b></div>` : "";
  const planSummary = `<section class="pricePlanSummary"><header><small>Included in your launch</small><strong data-testid="price-overall-launch-window">Ready within the timeframes shown once we receive what we need.</strong></header><div class="priceSystems priceSystems--summary" data-testid="selected-price-systems">${priceSystems || `<span class="fieldHelp">Choose the services to include.</span>`}${moreSystems}</div></section>`;
  const dollarStart = today && state.pricing.dollarCommitmentEligible && state.pricing.dollarCommitmentSelected;
  const headlineAmount = dollarStart ? price.downPayment : price.effectiveSetup;
  const headlineCopy = dollarStart
    ? `<b>$1 is paid today and applied to your agreed setup price.</b> The remaining setup balance is ${money(price.remainingSetup)}. Plus ${money(price.monthly)} monthly support.`
    : `${today && price.saving ? `${money(price.saving)} saved by deciding today. ` : ""}Plus <b>${money(price.monthly)}</b> monthly support.`;
  return sceneFrame(`Launch Your <span class="accent">Growth</span> System`, "Eligible clients can secure today’s launch with a $1 commitment. The full agreed price, saving and remaining balance stay completely visible.", `<div class="priceBusinessName">${esc(state.prospect.business || "Your Business")}</div><div class="priceGrid" data-testid="price-screen"><section class="pricePlan pricePlan--client"><div class="priceDecisionMain">${commitment}${totals}</div><div class="priceSupportingRow">${planSummary}${academy}</div><div class="recommendMeta" aria-hidden="true"><span data-price-output="break-even">Jobs to cover the cost: ${calc.perJob ? number(calc.jobs) : "add job profit"}</span>${guaranteeFullyConfigured() ? "<span>On-Time Launch Pledge included</span>" : ""}<span>Payment plan: ${esc(state.pricing.paymentOption || "To be confirmed")}</span></div></section><aside class="priceBottom ${today ? "todayPrice" : "standardPrice"} ${dollarStart ? "dollarStart" : ""}"><small data-price-output="summary-eyebrow">${dollarStart ? "Eligible launch commitment" : today ? "Your start-today price" : "Price if you wait"}</small><h3 data-price-output="summary-title">${dollarStart ? "Secure it today" : today ? "Launch today" : "Start within 24 hours"}</h3><div class="amount" data-price-output="headline-amount">${money(headlineAmount)}</div><p data-price-output="headline-copy">${headlineCopy}</p><div class="standardPriceReference"><span data-price-output="reference-label">${dollarStart ? "Full discounted setup price" : "Price after today"}</span><b data-price-output="standard-reference">${money(dollarStart ? price.effectiveSetup : price.standardSetup)}</b></div>${price.effectiveFirstYear > 0 ? `<button class="primaryBtn" data-action="next" data-testid="launch-growth-system">${dollarStart ? "Secure My Launch for $1" : "Continue With Today’s Price"}</button>` : `<button class="primaryBtn" data-action="next" data-testid="launch-growth-system" disabled>Enter the agreed price to continue</button><p class="fieldHelp">Enter a price before continuing.</p>`}<div class="secondaryStack"><button class="ghostBtn presenterOnly" data-action="launch-cart">Change Services</button><button class="ghostBtn presenterOnly" data-action="line-item-pricing" data-testid="open-line-item-pricing">Price Each Service</button><button class="ghostBtn" data-action="payment-options">Payment Options</button><button class="ghostBtn" data-action="objections">Ask a Question</button></div></aside></div>`, { badge: dollarStart ? `$1 secures today’s launch · ${price.discount}% saving` : today ? `${price.discount}% start-today saving` : "Standard price within 24 hours", hideNext: true, nextDisabled: price.standardSetup <= 0 && price.monthly <= 0 });
}

function updatePricingPreview() {
  const price = priceSummary();
  const calc = calculateBreakEven();
  const setText = (key, value) => document.querySelectorAll(`[data-price-output="${key}"]`).forEach(node => { node.textContent = value; });
  setText("discount-label", `${price.discount}%`);
  setText("discount-inline", `${price.discount}%`);
  setText("standard-setup", money(price.standardSetup));
  setText("saving", money(price.saving));
  setText("monthly", money(price.monthly));
  setText("first-year", money(price.effectiveFirstYear));
  const dollarStart = price.timing === "today" && state.pricing.dollarCommitmentEligible && state.pricing.dollarCommitmentSelected;
  setText("effective-setup", money(price.effectiveSetup));
  setText("headline-amount", money(dollarStart ? price.downPayment : price.effectiveSetup));
  setText("down-payment", money(price.downPayment));
  setText("down-payment-copy", state.pricing.dollarCommitmentSelected ? "Your $1 launch commitment" : "Full start-today setup price");
  setText("monthly-inline", money(price.monthly));
  setText("standard-reference", money(dollarStart ? price.effectiveSetup : price.standardSetup));
  setText("reference-label", dollarStart ? "Full discounted setup price" : "Price after today");
  setText("summary-eyebrow", dollarStart ? "Eligible launch commitment" : price.timing === "today" ? "Your start-today price" : "Price if you wait");
  setText("summary-title", dollarStart ? "Secure it today" : price.timing === "today" ? "Launch today" : "Start within 24 hours");
  setText("headline-copy", dollarStart ? `$1 is paid today and applied to your agreed setup price. The remaining setup balance is ${money(price.remainingSetup)}. Plus ${money(price.monthly)} monthly support.` : `${price.timing === "today" && price.saving ? `${money(price.saving)} saved by deciding today. ` : ""}Plus ${money(price.monthly)} monthly support.`);
  setText("summary-saving", price.timing === "today" && price.saving ? `${money(price.saving)} saved by deciding today. ` : "");
  setText("break-even", `Jobs to cover the cost: ${calc.perJob ? number(calc.jobs) : "add job profit"}`);
  const launchButton = document.querySelector("[data-testid='launch-growth-system']");
  if (launchButton) {
    const enabled = price.standardSetup > 0 || price.monthly > 0;
    launchButton.disabled = !enabled;
    launchButton.textContent = enabled ? (dollarStart ? "Secure My Launch for $1" : "Continue With Today’s Price") : "Enter the agreed price to continue";
    const warning = launchButton.nextElementSibling?.classList.contains("fieldHelp") ? launchButton.nextElementSibling : null;
    if (enabled) warning?.remove();
    else if (!warning) launchButton.insertAdjacentHTML("afterend", `<p class="fieldHelp">Enter a price before continuing.</p>`);
  }
}

function launchTimingChoicesMarkup(scope) {
  return `<div class="launchTimingChoices" role="radiogroup" aria-label="When should the launch begin?" data-testid="launch-timing-${scope}">${LAUNCH_TIMING_OPTIONS.map((option, index) => `<button type="button" class="launchTimingChoice ${state.launchStart.timing === option ? "on" : ""}" role="radio" aria-checked="${state.launchStart.timing === option}" data-action="launch-start-timing" data-value="${esc(option)}" data-testid="launch-timing-${scope}-${index + 1}"><span>${esc(option)}</span></button>`).join("")}</div>`;
}

function renderCheckout() {
  const selected = selectedServices();
  const price = priceSummary();
  const checkoutScope = `<section class="checkoutScopeSummary" data-testid="checkout-launch-cart-summary"><header><small>Your plan</small><h3>Your selected plan</h3><p data-testid="checkout-overall-launch-window">${esc(overallLaunchTiming())}</p></header><div class="checkoutScopeServices">${selected.map(service => `<article class="checkoutScopeService" data-service-id="${service.id}" data-testid="checkout-service-${service.id}"><span><i>${service.icon}</i><b>${esc(service.name)}${service.quantity > 1 ? ` · Qty ${service.quantity}` : ""}</b></span><strong class="serviceTimeToLive" data-service-ttl="${service.id}" data-testid="checkout-service-ttl-${service.id}">⏱️ Ready time: ${esc(serviceTimeToLive(service))}</strong></article>`).join("") || `<span class="fieldHelp">No services are selected yet.</span>`}</div></section>`;
  const checkoutDetails = `<section class="checkoutScopeSummary checkoutScopeSummary--compact" data-testid="checkout-saved-configuration"><header><small>Saved today</small><h3>Your saved plan</h3></header><div class="checkoutSavedDetails"><div class="priceTotals"><div class="priceTotal"><span>Setup due</span><b>${money(price.effectiveSetup)}</b></div><div class="priceTotal"><span>Monthly support</span><b>${money(price.monthly)}</b></div></div><div class="checkoutSavedCounts"><button class="ghostBtn" data-action="checkout-saved-plan" data-testid="checkout-view-saved-plan">View Full Plan</button></div></div></section>`;
  const launchQuestions = `<section class="launchStartQuestions" data-testid="launch-start-questions">
    <header class="launchStartHead"><small>Three quick details</small><h3>Tell us how you want to begin</h3><p>We’ll save these with your plan and send them to your support team.</p></header>
    <div class="launchStartQuestion" data-testid="launch-timing-question"><span class="launchQuestionNumber">01</span><div><h3>When should we begin?</h3>${launchTimingChoicesMarkup("checkout")}</div></div>
    <div class="launchStartQuestion" data-testid="launch-domain-question"><span class="launchQuestionNumber">02</span><div><h3>Which domain should we use?</h3>${field("launchStart.domain", "Domain to use", "text", { full: true, testid: "launch-domain-input", placeholder: "example.com or I need help choosing" })}</div></div>
    <div class="launchStartQuestion launchStartContact" data-testid="launch-contact-question"><span class="launchQuestionNumber">03</span><div><h3>Who should receive launch updates?</h3><div class="formGrid">${field("launchStart.contactPhone", "Best phone number", "tel", { testid: "launch-phone-input", placeholder: "+1 555 000 0000" })}${field("launchStart.contactEmails", "Contact email address(es)", "textarea", { testid: "launch-emails-input", placeholder: "owner@example.com" })}</div></div></div>
  </section>`;
  const actions = [
    ["📄", "Agreement", "Open the agreement and check the services, ready times, price and on-time promise.", "Open Agreement", "agreement"],
    ["🔒", "Secure Payment", "Open the secure payment page and record the amount paid today.", "Open Payment", "payment"],
    ["🚀", "Secure Setup Page", "Send the details your support team needs to start the work and keep you updated.", "Open Setup Page", "onboarding"]
  ];
  const actionCards = `<div class="checkoutGrid">${actions.map(([icon, name, copy, label, action]) => `<article class="checkoutCard"><i>${icon}</i><h3>${name}</h3><p>${copy}</p>${action === "payment" ? `${field("outcome.cashCollected", "Amount paid today", "number", { min: 0, testid: "amount-paid-today", currency: true })}${field("outcome.contractValue", "Total contract value", "number", { min: 0, currency: true })}` : ""}<button class="primaryBtn" data-action="checkout-${action}">${label}</button></article>`).join("")}</div>`;
  return sceneFrame("Complete the <span class=\"accent\">launch</span>", "Three steps: check the agreement, make the secure payment and send us the details we need to start.", `${checkoutScope}${checkoutDetails}${launchQuestions}${actionCards}`, { badge: "Your plan is saved", backAction: false, hideNext: true, extra: `<button class="ghostBtn presenterOnly" data-action="takeaway-menu">Take Away</button><button class="ghostBtn presenterOnly" data-action="record-outcome">Save Call Result</button>` });
}

function checkoutSavedPlanModal() {
  const selected = selectedServices();
  const searches = portalTargetSearches();
  const changes = portalRequestedChanges();
  const price = priceSummary();
  const services = selected.map(service => `<article class="checkoutScopeService"><span><i>${service.icon}</i><b>${esc(service.name)}${service.quantity > 1 ? ` · Qty ${service.quantity}` : ""}</b></span><strong>⏱️ ${esc(serviceTimeToLive(service))}</strong></article>`).join("") || `<p class="fieldHelp">No services are selected.</p>`;
  const searchList = searches.length ? `<ul>${searches.map(search => `<li>${esc(search)}</li>`).join("")}</ul>` : `<p class="fieldHelp">No target searches were recorded.</p>`;
  const changeList = changes.length ? `<ul>${changes.map(change => `<li>${esc(change)}</li>`).join("")}</ul>` : `<p class="fieldHelp">No website changes were recorded.</p>`;
  return simpleModal("Your Full Saved Plan", `<div class="checkoutSavedPlanModal" data-testid="checkout-saved-plan-modal"><section><h3>Services and ready times</h3><div class="checkoutScopeServices">${services}</div></section><section class="checkoutModalCommercials"><h3>Agreed investment</h3><div class="priceTotals"><div class="priceTotal"><span>Standard setup</span><b>${money(price.standardSetup)}</b></div><div class="priceTotal saving"><span>Saving today</span><b>${money(price.saving)}</b></div><div class="priceTotal"><span>Setup due</span><b>${money(price.effectiveSetup)}</b></div><div class="priceTotal"><span>Monthly support</span><b>${money(price.monthly)}</b></div></div></section><section><h3>Target searches</h3>${searchList}</section><section><h3>Website changes</h3>${changeList}</section></div>`);
}

function empty(icon, title, copy) { return `<div class="emptyState"><div><i>${icon}</i><b>${title}</b><p>${copy}</p></div></div>`; }
function industryTerm() {
  if (state.language.opportunityTerm && state.language.opportunityTerm !== "Automatic") return state.language.opportunityTerm.toLowerCase();
  const industry = state.prospect.industry.toLowerCase();
  if (/doctor|dental|clinic|health/.test(industry)) return "patients";
  if (/law|legal|attorney/.test(industry)) return "cases";
  if (/restaurant|salon|appointment/.test(industry)) return "bookings";
  return "jobs";
}

function flowTabs(group, items) {
  const active = state.activeTabs?.[group] || items[0]?.id;
  return `<nav class="flowTabs" aria-label="${esc(group)} sections">${items.map((item, index) => `<button type="button" class="${active === item.id ? "on" : ""}" data-action="flow-tab" data-group="${esc(group)}" data-id="${esc(item.id)}" aria-pressed="${active === item.id}"><span>${index + 1}</span><b>${esc(item.label)}</b></button>`).join("")}</nav>`;
}

function renderBriefIntro() {
  const outcomes = [
    ["🔎", "Get Found", "Put your business in front of people already searching for what you sell."],
    ["📞", "Answer Calls", "Capture the calls and enquiries your marketing creates before they move on."],
    ["⭐", "Get Chosen", "Turn attention into trust, booked work and customers who come back."]
  ];
  return sceneFrame("Digital Infrastructure. <span class=\"accent\">One Connected System.</span>", "One accountable partner connects the systems that make your business easier to discover, contact and choose.", `<div class="briefIntro briefIntroV3"><section class="briefIntroStatement"><small class="introMissionEyebrow">OUR MISSION</small><h2>Make digital growth simple, connected and commercially useful.</h2><p>Most Wanted replaces fragmented providers and disconnected tools with one clear operating system, shaped around the outcome your business needs.</p><div class="briefIntroTrust"><span>🏷️ Most Wanted is the DBA</span><span>🇦🇪 Kailan Industries FZCO · UAE</span><span>🇺🇸 Sales underwritten by Regen</span></div><div class="briefIntroPromise"><div class="briefIntroLaunchCue"><span aria-hidden="true">🚀</span><small>SECURE TODAY’S LAUNCH</small><b>Start From $1</b></div><div class="briefIntroSaving"><strong>20%</strong><span>Off when launching today</span></div></div></section><div class="briefIntroCapabilities">${outcomes.map(([icon,name,copy],index) => `<article><i>${icon}</i><div><b>${name}</b><p>${copy}</p></div><span class="briefIntroOutcomeStep">0${index + 1}</span></article>`).join("")}</div></div>`, { badge: "What Most Wanted does", nextLabel: "Let’s Talk About Your Business" });
}

function renderDiscoveryV3() {
  const tabs = [
    { id:"business", label:"Where Revenue Comes From" },
    { id:"problems", label:"Where Revenue Is Lost" },
    { id:"outcome", label:"What I Want to Fix" }
  ];
  const active = state.activeTabs.discovery || "business";
  const sources = [
    ["People Refer To Me", "Referrals"], ["People Find Me On Google Maps", "Google Maps"], ["People Find Me On Google Search", "Google Search"],
    ["People Find Me On Social Media", "Social Media"], ["I Run Paid Ads That Bring Clients To Us", "Paid Ads"], ["Repeat Customers Are Key For My Business", "Repeat Customers"],
    ["Offline Advertising (In Person / Door To Door) Is Key", "Offline Marketing"], ["I Run Community-Based Marketing", "Community Marketing"], ["My Current Website Is My Source Of Work", "My Website"]
  ];
  const problems = [
    ["People Cannot Find Me Online", "Not Visible Online"], ["I Don’t Receive Many Inquiries Overall", "Not Enough Inquiries"], ["Lead Service I Use Sucks", "Poor Lead Service"],
    ["People Don’t Find Me On Maps / AI Search", "Not Found on Maps / AI"], ["I Have Trouble Following Up With People", "Weak Follow-Up"], ["I Do Miss Calls Sometimes When Busy / Working", "Missed Calls"],
    ["Current Website Not Making Me A Return", "Website Not Paying Back"], ["My Paid Ads Are Not Doing So Well", "Ads Underperforming"], ["My Back-End Workflow System Is Stressing Me Out", "Messy Workflow"]
  ];
  const outcomes = [
    ["Make Me More Money (Overall)", "Make More Money"],
    ["Book More Jobs More Smoothly", "Book More Jobs"],
    ["Never Miss A Call (Money) Again", "Never Miss a Call"],
    ["Connect My Entire Operation Into One System", "Connect Everything"],
    ["Become More Present Locally", "Get Found Locally"],
    ["Become The Go-To Choice Locally Over Competitors", "Become the Local Choice"],
    ["Build My Reputation Consistently Over Time", "Build My Reputation"],
    ["Create A Pay-Per-Job (Ads) System That Delivers ROI", "Make Ads Pay"],
    ["Book Jobs Directly Into My Calendar", "Book Directly to My Calendar"]
  ];
  const stageTabs = `<nav class="flowTabs discoveryStageTabs" aria-label="Discovery sections">${tabs.map((item,index) => `<button type="button" class="${active === item.id ? "on" : ""}" data-action="flow-tab" data-group="discovery" data-id="${item.id}" aria-pressed="${active === item.id}"><span>${index + 1}</span><b>${item.label}</b></button>`).join("")}</nav>`;
  const optionBoard = choices => `<section class="discoveryChoiceWorkspace"><div class="choiceGrid discoveryChoices discoveryChoices--nine">${choices}</div></section>`;
  const answerPanel = fields => `<aside class="discoveryAnswerPanel discoveryAnswerPanel--compact"><div class="formGrid discoveryQuestionGrid">${fields}</div></aside>`;
  const businessChoices = sources.map(([value,label],index) => choice("prospect.currentChannels", value, label, ["🤝","📍","🔎","📱","📣","🔁","🚪","🏘️","🖥️"][index])).join("");
  const problemChoices = problems.map(([value,label],index) => choice("prospect.blockerSelections", value, label, ["📉","🚫","🧾","🫥","🔁","📵","🧩","📣","😵‍💫"][index])).join("");
  const outcomeChoices = outcomes.map(([value,label],index) => choice("prospect.wishSelections", value, label, ["💰","📅","📞","🔗","📍","🏆","⭐","📈","🗓️"][index])).join("");
  const targetJobs = Math.max(0, Number(state.prospect.desiredJobsMonthly) || 0);
  const averageJobValue = Math.max(0, Number(state.prospect.averageJobRevenue) || 0);
  const targetRevenue = targetJobs > 0 && averageJobValue > 0 ? targetJobs * averageJobValue : null;
  const goalPanel = `<aside class="discoveryAnswerPanel discoveryGoalPanel"><div class="discoveryGoalIntro"><small>MONTHLY GROWTH TARGET</small><h3>How many additional jobs do you want each month?</h3><p>One clear target links the business goal directly to the investment.</p></div><div class="goalPrimaryInput">${field("prospect.desiredJobsMonthly","Additional Jobs Wanted Each Month","number",{min:0})}</div><article class="goalRevenueTarget"><small>VALUE OF THAT MONTHLY TARGET</small><b data-goal-revenue>${targetRevenue !== null ? money(targetRevenue) : "Add the target"}</b><span data-goal-formula>${targetRevenue !== null ? `${number(targetJobs)} additional job${targetJobs === 1 ? "" : "s"} × ${money(averageJobValue)}` : "Uses the average job value from Step 1"}</span></article></aside>`;
  const business = `<section class="flowPanel discoveryFlowPanel discoveryFlowPanel--business">${optionBoard(businessChoices)}${answerPanel(`${field("prospect.competitiveEdge","Why Are You The Best?")}${field("prospect.hasWebsite","Do You Have A Current Website?","select",{items:["","Yes","No","Being built","Not sure"]})}${field("prospect.monthlyOpportunities","How Many Calls Do You Get Monthly?","number",{min:0})}${field("prospect.averageJobRevenue","Average Job Value (Revenue)","number",{min:0,currency:true})}`)}</section>`;
  const problem = `<section class="flowPanel discoveryFlowPanel discoveryFlowPanel--problems">${optionBoard(problemChoices)}${answerPanel(`${field("prospect.websitePerformance","Current Website Performance","select",{items:["","No website","Not making a return","Underperforming","Performing well","Not sure"]})}${field("prospect.missedHandling","Missed Calls Handling Process","select",{items:["","Answered live","Voicemail and callback","Sometimes missed","Frequently missed","Automated handling","Not sure"]})}${field("prospect.reviewsProcess","How I Manage Google Reviews","select",{items:["","No process","Ask occasionally","Ask every customer manually","Automated process","Not sure"]})}${field("prospect.missedPercent","Percent Of Calls I Lose","number",{min:0,max:100,suffix:"%"})}`)}</section>`;
  const outcome = `<section class="flowPanel discoveryFlowPanel discoveryFlowPanel--outcome">${optionBoard(outcomeChoices)}${goalPanel}</section>`;
  return sceneFrame("Understanding your business <span class=\"accent\">comes first</span>", "A focused conversation about demand, lost revenue and the outcome worth building toward.", `<div class="flowTabLayout discoveryV3Layout">${stageTabs}${active === "business" ? business : active === "problems" ? problem : outcome}</div>`, { badge: "3 focused sections" });
}

function renderCostV3() {
  const tabs = [{ id:"impact", label:"Revenue Gap" }, { id:"symptoms", label:"Why It Happens" }, { id:"cost", label:"Detailed Calculator" }];
  const active = state.activeTabs.cost || "impact";
  const result = calculateLeaks();
  const scores = opportunityUrgencyScores(result);
  const average = Math.round(scores.reduce((sum,item) => sum + item.score, 0) / Math.max(1,scores.length));
  const gapMonthly = result.knownResponseValue !== null ? money(result.knownResponseValue) : "ADD 2 NUMBERS";
  const gapAnnual = result.annual !== null ? money(result.annual) : "—";
  const gapFormula = result.knownResponseValue !== null ? result.estimateFormula : "Additional jobs wanted × average revenue per completed job.";
  const impact = `<section class="flowPanel revenueGapV4"><div class="revenueGapHero"><article class="revenueGapHeadline"><small>ESTIMATED MONTHLY REVENUE GAP</small><strong data-revenue-gap-monthly>${gapMonthly}</strong><p data-revenue-gap-formula>${esc(gapFormula)}</p><span>This is not a forecast. It is the value of the additional work the business already wants to win.</span></article><article class="revenueGapInputs"><header><small>DEFINE THE DISTANCE</small><b>Two numbers make the opportunity tangible.</b></header><div class="revenueGapInputGrid">${field("prospect.desiredJobsMonthly","Additional Jobs Wanted Each Month","number",{ min:0 })}${field("prospect.averageJobRevenue","Average Revenue Per Completed Job","number",{ min:0, currency:true })}</div><footer><span>If the same gap stays open for 12 months</span><b data-revenue-gap-annual>${gapAnnual}</b></footer></article></div><div class="revenueGapDrivers">${scores.map((item, index) => `<article class="revenueGapDriver ${item.level}" data-loss-area="${esc(item.id)}"><header><span>0${index + 1}</span><small>${esc(item.label)}</small><b>${item.score}/100</b></header><h3>${esc(item.name)}</h3><p>${esc(item.meaning)}</p></article>`).join("")}</div><aside class="revenueGapConclusion"><small>THE COMMERCIAL QUESTION</small><strong>How much longer should this revenue remain unwon?</strong><span>Fix the operating breaks. Close the gap.</span></aside></section>`;
  const evidenceFor = item => {
    const p = state.prospect;
    const selected = p.blockerSelections || [];
    const matches = item.id === "response" ? /call|follow|workflow|multiple companies|providers/i : item.id === "visibility" ? /inquir|maps|search|ads|lead service|visible|online/i : /website|review|reputation/i;
    const answers = selected.filter(answer => matches.test(answer));
    if (item.id === "response") {
      const callSelected = selected.some(answer => /call/i.test(answer));
      if (callSelected && p.missedHandling) answers.push(`Call process: ${p.missedHandling}`);
      if (callSelected && p.missedPercent !== "") answers.push(`${number(p.missedPercent)}% of calls may be lost`);
    }
    if (item.id === "visibility") {
      if (!answers.length) (p.currentChannels || []).slice(0, 2).forEach(channel => answers.push(`Current demand source: ${channel}`));
    }
    if (item.id === "trust") {
      if (p.websitePerformance) answers.push(`Website: ${p.websitePerformance}`);
      if (p.reviewsProcess) answers.push(`Reviews: ${p.reviewsProcess}`);
    }
    return [...new Set(answers)].slice(0, 4);
  };
  const symptoms = `<section class="flowPanel biggestLeaksV3">${scores.map(item => { const answers = evidenceFor(item); return `<article class="biggestLeakCard ${item.level}" data-loss-area="${esc(item.id)}"><header><i>${item.icon}</i><small>${item.score}/100 REVENUE LEAKAGE</small><strong>${item.score}</strong><h3>${esc(item.name)}</h3></header><div class="discoveryEvidence">${answers.length ? answers.map(answer => `<span>${esc(answer)}</span>`).join("") : `<span>No specific issue selected in this area.</span>`}</div><p>${esc(item.reason)}</p></article>`; }).join("")}</section>`;
  const estimate = calculateRevenueLossEstimate();
  const callsLocked = state.prospect.commercialSources?.monthlyOpportunities === "discovery";
  const revenueLocked = state.prospect.commercialSources?.averageJobRevenue === "discovery";
  const linkedField = (path, label, options = {}, locked = false) => `<div class="commercialInput ${locked ? "isLinked" : ""}">${field(path, label, "number", { min: 0, ...options, readonly: locked })}${locked ? `<small>Linked from discovery ✓</small>` : ""}</div>`;
  const cost = `<section class="flowPanel costCalculator costCalculatorV3"><div class="revenueEstimateInputs"><section class="revenueQuickBlock"><header><small>FASTEST WAY TO CALCULATE</small><b>Two numbers reveal the monthly gap.</b></header><div class="formGrid two commercialInputs">${linkedField("prospect.desiredJobsMonthly","Additional Jobs Wanted Each Month")}${linkedField("prospect.averageJobRevenue","Average Revenue Per Completed Job",{currency:true},revenueLocked)}</div></section><section class="revenueRefineBlock"><header><small>OPTIONAL ACCURACY LAYER</small><b>Add call data only when it is known.</b></header><div class="formGrid three commercialInputs">${linkedField("prospect.monthlyOpportunities","Calls And Enquiries Per Month",{},callsLocked)}${linkedField("prospect.missedPercent","Missed Or Unanswered %",{max:100})}${linkedField("prospect.closeRate","What % Becomes A Job?",{max:100})}</div></section></div><div class="lostRevenueResults"><article class="lostRevenueCard monthly"><small>POSSIBLE REVENUE LEAKING EVERY MONTH</small><strong>${result.knownResponseValue !== null ? money(result.knownResponseValue) : "Add two numbers"}</strong><p data-loss-monthly-copy>${result.knownResponseValue !== null ? "This is the single monthly opportunity-gap figure used throughout the presentation." : "Add additional jobs wanted and average job value for an instant estimate."}</p></article><article class="lostRevenueCard annual"><small>IF THE SAME GAP CONTINUES FOR 12 MONTHS</small><strong>${result.annual !== null ? money(result.annual) : "Not calculated"}</strong><p data-loss-annual-copy>${result.knownResponseValue !== null ? "Every month left unresolved repeats the same commercial gap." : "The annual figure appears from the same monthly calculation."}</p></article></div><p class="calculationDisclaimer">The quick estimate uses the monthly job goal. Complete call data can refine the same output without double-counting it. Illustrative only, not a performance guarantee.</p></section>`;
  return sceneFrame("The gap between current revenue and <span class=\"accent\">what should be won</span>", "Two business numbers reveal the commercial distance. Three operating breaks show what is creating it.", `<div class="flowTabLayout costV3Layout">${flowTabs("cost", tabs)}${active === "impact" ? impact : active === "symptoms" ? symptoms : cost}</div>`, { badge: `${average}/100 gap urgency` });
}

function updateCostPreview() {
  if (state.currentScene !== "cost") return;
  const result = calculateLeaks();
  const monthly = document.querySelector(".lostRevenueCard.monthly strong");
  const annual = document.querySelector(".lostRevenueCard.annual strong");
  const method = document.querySelector("[data-loss-method]");
  const formula = document.querySelector("[data-loss-formula]");
  const monthlyCopy = document.querySelector("[data-loss-monthly-copy]");
  const annualCopy = document.querySelector("[data-loss-annual-copy]");
  const gapMonthly = document.querySelector("[data-revenue-gap-monthly]");
  const gapAnnual = document.querySelector("[data-revenue-gap-annual]");
  const gapFormula = document.querySelector("[data-revenue-gap-formula]");
  if (monthly) monthly.textContent = result.knownResponseValue !== null ? money(result.knownResponseValue) : "Add two numbers";
  if (annual) annual.textContent = result.annual !== null ? money(result.annual) : "Not calculated";
  if (method) method.textContent = result.estimateMethodLabel;
  if (formula) formula.textContent = result.estimateFormula;
  if (monthlyCopy) monthlyCopy.textContent = result.knownResponseValue !== null ? "This is the single monthly opportunity-gap figure used throughout the presentation." : "Add additional jobs wanted and average job value for an instant estimate.";
  if (annualCopy) annualCopy.textContent = result.knownResponseValue !== null ? "Every month left unresolved repeats the same commercial gap." : "The annual figure appears from the same monthly calculation.";
  if (gapMonthly) gapMonthly.textContent = result.knownResponseValue !== null ? money(result.knownResponseValue) : "ADD 2 NUMBERS";
  if (gapAnnual) gapAnnual.textContent = result.annual !== null ? money(result.annual) : "—";
  if (gapFormula) gapFormula.textContent = result.knownResponseValue !== null ? result.estimateFormula : "Additional jobs wanted × average revenue per completed job.";
}

function updateEconomicsGoalPreview() {
  if (state.currentScene !== "economics") return;
  const target = calculateMonthlyGrowthTarget();
  const estimate = calculateRevenueLossEstimate();
  const price = priceSummary();
  const monthlyProblem = estimate.monthlyValue !== null ? money(estimate.monthlyValue) : "$0";
  const titleValue = document.querySelector(".scene[data-scene='economics'] .sceneTitle .accent");
  const problemValue = document.querySelector(".economicsProblemHeader strong");
  const problemFormula = document.querySelector(".economicsProblemHeader span");
  const comparisonValue = document.querySelector(".economicsProblemSolution .problem b");
  const recoveryHeading = document.querySelector(".economicsRecovery h2");
  const recoveryCopy = document.querySelector(".economicsRecovery p");
  if (titleValue) titleValue.textContent = `${monthlyProblem} per month`;
  if (problemValue) problemValue.textContent = estimate.monthlyValue !== null ? monthlyProblem : "ADD YOUR GOAL";
  if (problemFormula) problemFormula.textContent = estimate.monthlyValue !== null
    ? estimate.formula
    : "complete the monthly job goal in discovery";
  if (comparisonValue) comparisonValue.textContent = estimate.monthlyValue !== null ? monthlyProblem : "Not calculated";
  const jobsToCover = target.averageJobValue > 0 && price.effectiveSetup > 0 ? Math.ceil(price.effectiveSetup / target.averageJobValue) : null;
  if (recoveryHeading) recoveryHeading.textContent = jobsToCover
    ? `${number(jobsToCover)} completed job${jobsToCover === 1 ? "" : "s"}`
    : price.effectiveSetup <= 0 ? "Add the launch price" : "Add the average job value";
  if (recoveryCopy) recoveryCopy.textContent = jobsToCover
    ? `At ${money(target.averageJobValue)} average revenue per completed job.`
    : price.effectiveSetup <= 0 && target.averageJobValue > 0
      ? `Your ${money(target.averageJobValue)} average job value is linked. Add the plan price to calculate the jobs needed.`
      : "Add the average value of one completed job to make the comparison tangible.";
}

function updateDiscoveryGoalPreview() {
  if (state.currentScene !== "discovery" || state.activeTabs.discovery !== "outcome") return;
  const target = calculateMonthlyGrowthTarget();
  const average = document.querySelector("[data-goal-average]");
  const revenue = document.querySelector("[data-goal-revenue]");
  const formula = document.querySelector("[data-goal-formula]");
  if (average) average.textContent = target.averageJobValue > 0 ? money(target.averageJobValue) : "Add in Step 1";
  if (revenue) revenue.textContent = target.monthlyValue !== null ? money(target.monthlyValue) : "Calculated here";
  if (formula) formula.textContent = target.monthlyValue !== null
    ? `${number(target.jobs)} additional job${target.jobs === 1 ? "" : "s"} × ${money(target.averageJobValue)}`
    : "Add both figures to reveal the goal";
}

const AGENCY_FAILURES = [
  { id:"slow", icon:"🐌", title:"Slow, inconsistent changes", pain:"A simple request becomes another queue, handoff and week of waiting while the opportunity keeps moving.", consequence:"Your business loses momentum after you have already paid." },
  { id:"cost", icon:"💸", title:"Hidden costs everywhere", pain:"Edits, hosting, software, support and ‘out of scope’ work keep appearing after the original commitment.", consequence:"You never know the real cost of getting the result." },
  { id:"roi", icon:"📉", title:"No ROI on your investment", pain:"A website or campaign launches, but nobody owns the path from attention to enquiries, jobs and revenue.", consequence:"You pay for activity instead of a commercial outcome." }
];

function renderAgencyV3() {
  const cards = AGENCY_FAILURES.map((item, index) => `<article class="agencyContrastCard agencyPainCard"><header><span>${String(index + 1).padStart(2,"0")}</span><i>${item.icon}</i><small>THE PAIN BUSINESSES ARE FORCED TO ACCEPT</small></header><h2>${esc(item.title)}</h2><p>${esc(item.pain)}</p><footer><small>COMMERCIAL DAMAGE</small><strong>${esc(item.consequence)}</strong></footer></article>`).join("");
  return sceneFrame("Normal agencies keep the <span class=\"accent dangerAccent\">same pain alive</span>", "Slow changes, surprise costs and no commercial return are not isolated mistakes. They are the operating model businesses have been forced to accept.", `<div class="agencyContrast agencyContrast--pain"><section class="agencyContrastGrid">${cards}</section><aside class="agencyContrastManifesto"><i>⚠️</i><div><small>THIS IS THE INDUSTRY PROBLEM</small><strong>Businesses should not have to chase the people they pay, fear the next invoice or wonder whether the work will ever produce a return.</strong></div></aside></div>`, { badge: "Three pains. Zero excuses." });
}

function testimonialMedia(value) {
  const raw = String(value || "").trim();
  if (!raw) return null;
  const drive = raw.match(/drive\.google\.com\/(?:file\/d\/|open\?(?:[^#]*&)?id=|uc\?(?:[^#]*&)?id=)([A-Za-z0-9_-]{10,})/i);
  if (drive) return { type: "iframe", src: `https://drive.google.com/file/d/${drive[1]}/preview` };
  const youtube = raw.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/))([A-Za-z0-9_-]{6,})/i);
  if (youtube) return { type: "iframe", src: `https://www.youtube-nocookie.com/embed/${youtube[1]}?rel=0` };
  const vimeo = raw.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
  if (vimeo) return { type: "iframe", src: `https://player.vimeo.com/video/${vimeo[1]}` };
  if (/\.(?:mp4|webm|ogg)(?:[?#].*)?$/i.test(raw)) return { type: "video", src: raw };
  return { type: "iframe", src: raw };
}

function renderTestimonialsV3() {
  const testimonials = (state.testimonialsConfig || []).filter(item => item.enabled && item.videoUrl).slice(0, 3);
  const cards = testimonials.map(item => {
    const media = testimonialMedia(item.videoUrl);
    const rating = Math.min(5, Math.max(1, Number(item.rating) || 5));
    const ratingText = Number.isInteger(rating) ? rating.toFixed(1) : String(rating);
    const resultLabel = String(item.resultLabel || item.quote || "Verified client result").trim();
    const progress = Math.round((rating / 5) * 100);
    const video = media?.type === "video"
      ? `<video controls preload="metadata" playsinline src="${esc(media.src)}" aria-label="Video testimonial from ${esc(item.clientName || item.businessName || "a Most Wanted client")}"></video>`
      : `<iframe src="${esc(media?.src || "")}" title="Video testimonial from ${esc(item.clientName || item.businessName || "a Most Wanted client")}" loading="eager" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
    return `<article class="testimonialCard" style="--testimonial-progress:${progress}%" data-testid="video-testimonial-card"><div class="testimonialVideo">${video}</div><div class="testimonialProof"><div class="testimonialCountry"><span aria-hidden="true">🇺🇸</span><b>AMERICAN CLIENT</b></div><div class="testimonialIdentity"><i>▶</i><div><h2>${esc(item.clientName || "Most Wanted client")}</h2><p>${esc([item.role, item.businessName].filter(Boolean).join(" · ") || "Client video testimonial")}</p></div></div><section class="testimonialResult"><header><span>CLIENT RETURN</span><b>${esc(resultLabel)}</b></header><div class="testimonialResultTrack" aria-hidden="true"><i></i></div><div class="testimonialRating"><span aria-label="${ratingText} out of 5 stars">★★★★★</span><b>${ratingText} / 5</b></div></section>${item.quote && item.quote !== resultLabel ? `<blockquote>“${esc(item.quote)}”</blockquote>` : ""}</div></article>`;
  }).join("");
  const body = cards || `<section class="testimonialEmpty"><i class="testimonialPlayIcon" aria-hidden="true">▶</i><h2>Add your client video testimonials</h2><p>Paste approved YouTube, Google Drive, Vimeo or direct video links in Settings. Up to three enabled testimonials appear here.</p><button class="primaryBtn presenterOnly" data-action="open-testimonial-settings">Open Testimonial Settings</button></section>`;
  return sceneFrame("Hear it directly from <span class=\"accent\">our clients, picked at random</span>", "Real clients, speaking in their own words about their experience with Most Wanted.", `<div class="testimonialsV3 ${testimonials.length ? "hasTestimonials" : "isEmpty"}" data-testid="video-testimonials">${body}</div>`, { badge: "Client video testimonials" });
}

const REGEN_DIFFERENCES = [
  { id:"payments", icon:"💎", title:"0 monthly fees. Long-term partnership.", copy:"No endless agency retainer. We build for ownership, continuity and a relationship that stays useful long after launch.", removes:"Hidden monthly costs" },
  { id:"speed", icon:"⚡", title:"8.4-hour average change time. Fast delivery.", copy:"A direct team and clear ownership keep everyday changes moving while the commercial opportunity is still alive.", removes:"Slow, inconsistent changes" },
  { id:"contacts", icon:"🤝", title:"1–2 points of contact. Treated like family.", copy:"A small accountable team learns your business, stays close and keeps every decision connected to the result.", removes:"Distance and weak accountability" }
];

function renderRegenV3() {
  const cards = REGEN_DIFFERENCES.map((item, index) => `<article class="agencyContrastCard regenSolutionCard"><header><span>${String(index + 1).padStart(2,"0")}</span><i>${item.icon}</i><small>BUILT DIFFERENTLY FROM DAY ONE</small></header><h2>${esc(item.title)}</h2><p>${esc(item.copy)}</p><footer><small>INTENTIONALLY ELIMINATES</small><strong>${esc(item.removes)}</strong></footer></article>`).join("");
  return sceneFrame("Most Wanted was built to <span class=\"accent\">eliminate agency pain</span>", "We intentionally designed Most Wanted from the ground up to change the agency industry, not copy it: less cost, more speed and real human accountability.", `<div class="agencyContrast agencyContrast--solution"><section class="agencyContrastGrid">${cards}</section><aside class="agencyContrastManifesto"><i>✓</i><div><small>THE MOST WANTED OPERATING MODEL</small><strong>Every part of Most Wanted exists because businesses told us what they hated about agencies. We designed the opposite.</strong></div></aside></div>`, { badge: "Built to change the industry" });
}

function renderSystemV3() {
  const groups = [
    ["🖥️","Website",["website"]],["🔎","Regular SEO + AI Optimization",["seo"]],["⭐","Google Maps review system",["reviews"]],
    ["🗂️","CRM + follow-up",["crm"]],["💬","Chatbot + receptionist",["chatbot","receptionist"]],["📣","Paid ads",["ads"]]
  ];
  const selected = selectedServices();
  const allSelected = Object.keys(state.services).every(id => state.services[id]?.selected);
  return sceneFrame("One connected revenue growth system, or <span class=\"accent\">pick and mix</span>", "Build the final plan manually from what the discovery showed. Pricing is handled separately once the right services are selected.", `<div class="systemV3"><header><div><small>FINAL PLAN</small><strong>${selected.length} service${selected.length === 1 ? "" : "s"} included</strong></div><div class="systemHeaderActions"><button class="primaryBtn compareHeadButton" data-action="service-compare-open" data-id="seo">Compare MW Vs. Others</button><button class="ghostBtn presenterOnly" data-action="system-select-all">${allSelected ? "Restore Previous Plan" : "Select Complete System"}</button><button class="ghostBtn presenterOnly" data-action="build-package">Add Bundle</button></div></header><div class="systemChoiceGrid">${groups.map(([icon,name,ids]) => { const on = ids.some(id => state.services[id]?.selected); return `<article class="systemChoiceCard ${on ? "on" : ""}"><i>${icon}</i><div><h3>${esc(name)}</h3><p>${on ? "Included in the final plan" : "Available if the business needs it"}</p></div><div>${ids.map(id => `<button class="${state.services[id]?.selected ? "primaryBtn" : "ghostBtn"}" data-action="plan-toggle-service" data-id="${id}">${state.services[id]?.selected ? "Included ✓" : `Add ${esc(state.serviceConfig[id]?.name || id)}`}</button>`).join("")}</div></article>`; }).join("")}</div></div>`, { badge: "Choose only what fits" });
}

function renderGuaranteeV3() {
  const guarantee = state.guarantee || {};
  const trigger = String(guarantee.trigger || "Most Wanted misses the agreed delivery time for a Most Wanted-controlled reason").trim().replace(/[.!?]+$/, "");
  const credit = Math.max(0, Number(guarantee.buyerCredit) || 1000);
  const meals = Math.max(0, Number(guarantee.mealQuantity) || 1000);
  const charity = String(guarantee.charityName || "Feeding America").trim();
  const credibility = [["🏷️","Most Wanted","DBA of Kailan Industries FZCO"],["🇦🇪","United Arab Emirates","Kailan Industries FZCO is based here"],["🇺🇸","Regen","Contractually underwrites all sales"],["🖥️","5,329","US websites completed last year"],["📈","Fast growing","Built for long-term support"]];
  return sceneFrame("The Most Wanted delivery time <span class=\"accent\">guarantee</span>", `${esc(trigger)}. Both commitments activate.`, `<div class="guaranteeV3"><div class="guaranteeRemedies"><article class="guaranteeRemedy guaranteeRemedy--credit"><header><i>🛡️</i><small>PERFORMANCE PROTECTION</small></header><div class="guaranteeRemedyValue"><strong>${money(credit)}</strong><h3>Most Wanted performance credit</h3></div><p>If the performance guarantee is triggered, you receive ${money(credit)} in Most Wanted performance credit.</p></article><article class="guaranteeRemedy guaranteeRemedy--community"><header><i>❤️</i><small>ACCOUNTABILITY IN ACTION</small></header><div class="guaranteeRemedyValue"><strong>${number(meals)}</strong><h3>Meals funded through ${esc(charity)}</h3></div><p>If the performance guarantee is triggered, Most Wanted also funds ${number(meals)} meals for Americans through ${esc(charity)}.</p></article></div><div class="credibilityStrip">${credibility.map(([icon,value,label]) => `<article><i>${icon}</i><div><strong>${value}</strong><span>${label}</span></div></article>`).join("")}</div><p class="guaranteeFinePrint">The signed plan defines the agreed delivery time, required access and the work within Most Wanted’s control.</p></div>`, { badge: `${money(credit)} credit + ${number(meals)} meals` });
}

function renderProofV3() {
  const configured = Object.values(state.demosConfig).filter(demo => resolvedDemoUrl(demo));
  const relevant = configured;
  const selectedId = relevant.some(item => item.id === state.selectedDemo)
    ? state.selectedDemo
    : (relevant.some(item => item.id === "website") ? "website" : relevant[0]?.id);
  const selected = relevant.find(item => item.id === selectedId);
  const selectedUrl = selected ? resolvedDemoUrl(selected) : "";
  const navigation = relevant.length
    ? relevant.map(demo => `<button class="${selectedId === demo.id ? "on" : ""}" data-action="select-demo" data-id="${demo.id}"><i>${demo.icon}</i><b>${esc(demo.name)}</b><span>${selectedId === demo.id ? "Viewing" : "Open"}</span></button>`).join("")
    : `<div class="proofNoDemos"><i>🖥️</i><b>No demos configured</b><span>Add a custom website in Client Details or a verified demo URL in Settings.</span></div>`;
  return sceneFrame("See it before you <span class=\"accent\">decide</span>", "Open the website concept and any relevant live demo. The decision should be based on what you can actually see.", `<div class="proofV3"><nav>${navigation}</nav><section class="demoStage">${selectedUrl ? `<iframe src="${esc(selectedUrl)}" title="${esc(selected?.name || "Most Wanted demo")}" loading="eager" allow="fullscreen"></iframe><div class="demoTools"><button data-action="open-demo" data-url="${esc(selectedUrl)}" data-title="${esc(selected?.name || "Most Wanted demo")}">Open Full Screen</button></div>` : `<div class="demoEmpty"><div><i>🖥️</i><b>Nothing added yet</b><p>Only demos configured in Client Details or Settings appear on this screen.</p></div></div>`}</section></div>`, { badge: "Real proof, not promises", nextLabel: "See The Economics" });
}

function renderSeoCompareV3() {
  const approaches = [
    {
      className: "none",
      number: "01",
      icon: "🧱",
      label: "0 SEO",
      provider: "0 SEO Whatsoever",
      factor: "0×",
      factorLabel: "Ongoing SEO. Near-zero visibility.",
      headline: "They might add a favicon and a description, but it creates no meaningful impact.",
      bullets: ["Virtually no real impact on the site's visibility", "No specialist regularly improving visibility", "The site is unlikely to be discovered organically"],
      outcome: "A site online, with no visibility engine."
    },
    {
      className: "once",
      number: "02",
      icon: "📦",
      label: "ONE TIME",
      provider: "SEO One Time If That",
      factor: "1×",
      factorLabel: "SEO done once, at launch",
      headline: "The website is optimized for one moment in time.",
      bullets: ["Initial audit and launch setup, usually", "Work commonly slows after launch instead of growing", "Ongoing SEO often comes with a significant price tag"],
      outcome: "A launch task, not a continuing process."
    },
    {
      className: "regular",
      number: "03",
      icon: "📈",
      label: "REGULAR",
      provider: "Regular SEO Tightening",
      factor: "12×",
      factorLabel: "Strategic reviews every year",
      headline: "Search is treated as repeated work, not a launch checkbox.",
      bullets: ["Monthly keyword tightening that fortifies growth", "Technical, page, local and AI-search work completed", "Every system works together as one complete system"],
      outcome: "Continuous improvement with one accountable partner."
    }
  ];
  const commercialSignals = {
    none: [10,10,11,10,9,10,9,8,9,8,7,8],
    once: [7,20,34,30,27,24,22,20,19,18,17,16],
    regular: [10,18,26,34,43,52,60,68,76,84,91,100]
  };
  const cards = approaches.map(item => `<article class="seoCompareCard ${item.className}"><header><span>${item.number}</span><i>${item.icon}</i><div><small>${item.label}</small><h2>${item.provider}</h2></div></header><div class="seoFactor"><strong>${item.factor}</strong><div><span>SEO ACTIVITY FACTOR</span><em>${item.factorLabel}</em></div></div><p>${item.headline}</p><ul>${item.bullets.map(point => `<li>${point}</li>`).join("")}</ul><div class="seoCommercialSignal" aria-label="Illustrative twelve month search momentum"><div>${commercialSignals[item.className].map((height,index) => `<i style="--signal:${height}%;--signal-delay:${index}"></i>`).join("")}</div><span>${item.className === "regular" ? "MONTHLY MOMENTUM BUILDS" : item.className === "once" ? "LAUNCH SPIKE, THEN FLAT" : "NO ENGINE, NO MOMENTUM"}</span></div><strong>${item.outcome}</strong></article>`).join("");
  return sceneFrame("Three SEO levels. One <span class=\"accent\">keeps tightening</span>", "Compare no SEO, one launch-time setup and regular strategic work throughout the year.", `<div class="seoCompareV3"><section class="seoCompareGrid">${cards}</section><footer><b>SEO compounds.</b><div class="seoFooterCopy"><span>Regular tightening creates twelve deliberate chances to improve relevance instead of relying on one launch-day setup.</span><small>The chart visualizes work cadence, not a traffic or ranking promise.</small></div><div class="seoMomentum" aria-hidden="true"><div class="seoMomentumLabels"><span>LEFT ALONE</span><span>ACTIVE GROWTH</span></div><div class="seoMomentumTrack"><i class="seoMomentumRunner"></i></div></div></footer></div>`, { badge: "0× vs 1× vs 12× activity", headAction: `<button class="primaryBtn compareHeadButton" data-action="service-compare-open" data-id="seo">Compare MW Vs. Others</button>`, nextLabel: "Build Your System" });
}

function renderEconomicsV3() {
  state.pricing.timing = "today";
  state.pricing.discount = 20;
  recalculatePrice();
  const price = priceSummary();
  const growthTarget = calculateMonthlyGrowthTarget();
  const revenueEstimate = calculateRevenueLossEstimate();
  const monthlyLostRevenue = revenueEstimate.monthlyValue;
  const averageJobValue = Number(state.prospect.averageJobRevenue) || 0;
  const jobsToCoverLaunch = averageJobValue > 0 && price.effectiveSetup > 0 ? Math.ceil(price.effectiveSetup / averageJobValue) : null;
  const services = selectedServices();
  const packageSummary = state.combinedOffer?.applied && state.combinedOffer.name
    ? `<div class="economicsPackage combinedOfferSummary" data-testid="active-combined-offer-summary"><span>🔗 COMBINED OFFER</span><b>${esc(state.combinedOffer.name)}</b><em>${Math.max(0, (state.combinedOffer.serviceIds || []).length)} services · One agreed price</em></div>`
    : state.activePackage?.applied && state.activePackage.name
    ? `<div class="economicsPackage" data-testid="active-package-summary"><span>📦 PACKAGE</span><b>${esc(state.activePackage.name)}</b><em>Qty ${Math.max(1, Number(state.activePackage.quantity) || 1)}</em></div>`
    : "";
  const monthlyProblem = monthlyLostRevenue !== null ? money(monthlyLostRevenue) : "$0";
  const jobsLabel = jobsToCoverLaunch
    ? `${number(jobsToCoverLaunch)} completed job${jobsToCoverLaunch === 1 ? "" : "s"}`
    : price.effectiveSetup <= 0 ? "Add the launch price" : "Add the average job value";
  const recoveryCopy = jobsToCoverLaunch
    ? `At ${money(averageJobValue)} average revenue per completed job.`
    : price.effectiveSetup <= 0 && averageJobValue > 0
      ? `Your ${money(averageJobValue)} average job value is linked. Add the plan price to calculate the jobs needed.`
      : "Add the average value of one completed job to make the comparison tangible.";
  const launchCommitment = state.pricing.dollarCommitmentEligible ? "YOU CHOOSE" : money(price.downPayment);
  return sceneFrame(
    `The investment to solve your <span class="accent">${monthlyProblem} per month</span> problem today`,
    "See the urgent monthly problem beside the solution you can launch today.",
    `<div class="economicsV3">
      <section class="economicsOffer economicsSolutionPanel">
        <header class="economicsStartToday"><small>STANDARD PRICE BEFORE SAVING</small><strong>${money(price.standardSetup)}</strong><div class="economicsSavedToday"><span>🔥 YOU SAVE ${money(price.saving)} TODAY</span><b>${money(price.effectiveSetup)}</b><em>PRICE YOU PAY · 20% OFF APPLIED</em></div></header>
        <div class="preparedWorkProof preparedWorkProof--economics"><i>🛠️</i><div><small>WORK COMPLETED BEFORE THIS MEETING</small><b>Your site is ready to launch · ≈6 focused hours invested</b><span>Human design and engineering completed specifically for this business.</span></div></div>
        <div class="economicsTotals"><article><span>Standard setup</span><b>${money(price.standardSetup)}</b></article><article class="saving"><span>20% saving</span><b>${money(price.saving)}</b></article><article class="minimumLaunch"><span>🚀 Name Your Price</span><b>${launchCommitment}</b><em>SECURE TODAY</em></article><article><span>Monthly</span><b>${money(price.monthly)}</b></article></div>
        ${packageSummary}
        <div class="economicsServices">${services.length ? services.map(service => `<span><i>${service.icon}</i><b>${esc(service.name)}</b></span>`).join("") : `<span><b>No services selected yet</b></span>`}</div>
        <div class="economicsActions presenterOnly"><button class="ghostBtn" data-action="launch-cart">Choose Services</button><button class="ghostBtn" data-action="line-item-pricing">Set Prices</button><button class="ghostBtn" data-action="payment-options">Payment Options</button><button class="ghostBtn" data-action="build-package" data-testid="build-package">Build Package</button></div>
      </section>
      <section class="economicsCalculator economicsProblemPanel">
        <header class="economicsProblemHeader"><small>THE GAP · REVENUE NOT YET WON</small><strong>${monthlyLostRevenue !== null ? monthlyProblem : "ADD YOUR GOAL"}</strong><span>${monthlyLostRevenue !== null ? esc(revenueEstimate.formula) : "complete the monthly job goal in discovery"}</span></header>
        <div class="economicsRecovery"><small>WHAT DOES TODAY'S INVESTMENT NEED TO RECOVER?</small><h2>${jobsLabel}</h2><p>${recoveryCopy}</p></div>
        <div class="economicsJobInput">${field("prospect.averageJobRevenue","Average completed job value","number",{min:0,currency:true})}</div>
        <div class="economicsProblemSolution"><article class="problem"><span>Monthly opportunity gap</span><b>${monthlyLostRevenue !== null ? monthlyProblem : "Not calculated"}</b></article><i>→</i><article class="solution"><span>Start-today solution</span><b>${money(price.effectiveSetup)}</b></article></div>
        <p class="calculationDisclaimer">Illustrative comparison based only on the business figures entered. It is not a performance guarantee.</p>
      </section>
    </div>`,
    { badge: `${state.pricing.dollarCommitmentEligible ? "Name Your Price" : `${launchCommitment} minimum launch`} · 20% saving` }
  );
}

function renderDecisionV3() {
  const price = priceSummary();
  const todaySaving = price.standardSetup * .20;
  const todayPrice = Math.max(0, price.standardSetup - todaySaving);
  const monthlyLostRevenue = calculateRevenueLossEstimate().monthlyValue;
  const problemValue = monthlyLostRevenue !== null && monthlyLostRevenue > 0 ? money(monthlyLostRevenue) : "Your identified revenue problem";
  const commercialLogic = monthlyLostRevenue !== null && monthlyLostRevenue > 0
    ? `Continuing to accept a ${money(monthlyLostRevenue)} monthly problem to avoid a low-entry launch is the more expensive decision.`
    : "Leaving the identified problem untouched means accepting the same commercial loss while the prepared opportunity disappears.";
  return sceneFrame(
    "One commercially clear <span class=\"accent\">decision</span>",
    `${commercialLogic} Today you can protect the build, the production slot and the ${money(todaySaving)} saving with a Name Your Price commitment, starting from $1 where eligible.`,
    `<div class="decisionV3 decisionRealityGrid">
      <section class="decisionPath launchNow decisionReality launchReality">
        <small>REALITY 1 · SOLVE IT TODAY</small>
        <h2>Keep The Solution We Launch Today.</h2>
        <div class="decisionRealityHero"><span>START TODAY</span><strong>${money(todayPrice)}</strong><em>${money(todaySaving)} saved</em></div>
        <div class="preparedWorkProof preparedWorkProof--decision"><i>🛠️</i><div><small>ALREADY CREATED FOR YOU</small><b>Prepared site · ≈6 focused hours complete</b><span>Protect the design and engineering work already invested.</span></div></div>
        <div class="decisionEntry"><i>🚀</i><div><span>LOW BARRIER TO START</span><b>Name Your Price</b><em>From $1 where eligible. Your commitment is applied to the agreed launch price.</em></div></div>
        <ul><li>Your prepared website and production slot are secured</li><li>The revenue problem starts being solved now</li><li>Agreement, payment and onboarding move forward today</li></ul>
        <button class="primaryBtn" data-action="decision-launch">Secure My Build Today</button>
      </section>
      <section class="decisionPath takeTime decisionReality lossReality">
        <small>REALITY 2 · LEAVE IT UNSOLVED</small>
        <h2>Keep the problem. Lose the opportunity.</h2>
        <div class="decisionProblemValue decisionLostTodayHero"><span>MONEY LOST TODAY</span><strong>${money(todaySaving)}</strong><em>Your launch-today saving disappears.</em></div>
        <div class="decisionLosses"><article><i>💰</i><div><span>DISCOUNT LOST TODAY</span><b>${money(todaySaving)} saving disappears</b></div></article><article><i>🏗️</i><div><span>BUILD SLOT RELEASED</span><b>Production capacity moves on</b></div></article><article><i>🗑️</i><div><span>PREPARED SITE DELETED</span><b>≈6 focused hours removed after 48 hours</b></div></article></div>
        <p><b>${esc(problemValue)}</b> remains unresolved while the saving, production slot and completed website are lost.</p>
        <button class="ghostBtn" data-action="decision-48">Leave It Open For 48 Hours</button>
      </section>
    </div>`,
    { badge: "Solve it today or preserve the problem", hideNext: true }
  );
}

function renderOfferV3() {
  const price = priceSummary();
  const todaySaving = price.standardSetup * .20;
  const monthlyLostRevenue = calculateRevenueLossEstimate().monthlyValue;
  const monthlyProblem = monthlyLostRevenue !== null && monthlyLostRevenue > 0 ? `${money(monthlyLostRevenue)} / month` : "Revenue loss continues";
  const timer = state.opening?.buildAccessExpiresAt ? expiryCountdownMarkup({ offerOnly: true }) : `<div class="expiryTimer"><small>SITE DELETED IN</small><b><span>48</span><i>:</i><span>00</span><i>:</i><span>00</span></b></div>`;
  return sceneFrame(
    `Your prepared site is deleted in <span class="accent">48 hours</span>`,
    `Today’s ${money(todaySaving)} saving is no longer available. The prepared site and approximately six focused hours of completed work remain reserved only until the clock reaches zero.`,
    `<div class="offerV3 offerDeadlineV3">
      <section class="offerCountdown offerDeletionCountdown">
        ${timer}
        <h2>Permanent site-deletion countdown.</h2>
        <p>The prepared website remains reserved only until zero. Approximately six focused hours of human design and engineering are already complete. There is no follow-up meeting and Most Wanted does not chase.</p>
        <div class="preparedWorkProof preparedWorkProof--offer"><i>🛠️</i><div><small>ALREADY INVESTED BEFORE THE CALL</small><b>≈6 focused hours</b><span>Your prepared site was designed and coded specifically for this business.</span></div></div>
        <div class="offerPainStack">
          <article><span>💸 SAVING LOST TODAY</span><strong>${money(todaySaving)}</strong></article>
          <article><span>⚠️ PROBLEM STILL CONTINUES</span><strong>${esc(monthlyProblem)}</strong></article>
        </div>
      </section>
      <aside class="offerActions offerDeadlineActions offerRiskActions">
        <header><small>WHAT IS CURRENTLY RESERVED</small><h2>A finished site. A real build slot.</h2><p>This is completed production work prepared for this business, not a blank proposal or future promise.</p></header>
        <div class="offerReservedAssets">
          <article><i>🖥️</i><div><span>PREPARED WEBSITE</span><b>Ready to move into launch</b></div></article>
          <article><i>🛠️</i><div><span>HUMAN WORK</span><b>≈6 focused hours complete</b></div></article>
          <article><i>📍</i><div><span>PRODUCTION SLOT</span><b>Held for this opportunity</b></div></article>
        </div>
        <div class="offerDeletionConsequences">
          <small>WHEN THE TIMER REACHES ZERO</small>
          <ul>
            <li><i>🗑️</i><div><b>PREPARED SITE DELETED</b><span>The website and completed work are permanently removed.</span></div></li>
            <li><i>📍</i><div><b>BUILD SLOT RELEASED</b><span>Production capacity moves to the next business.</span></div></li>
            <li><i>💸</i><div><b>PRICE PROTECTION ENDS</b><span>The reserved offer and pricing window close.</span></div></li>
            <li><i>⚠️</i><div><b>REVENUE PROBLEM REMAINS</b><span>The identified commercial problem stays unsolved.</span></div></li>
          </ul>
        </div>
        <div class="offerNoChase"><small>NO FOLLOW-UP SALES SEQUENCE</small><strong>The timer is the decision window.</strong><span>Most Wanted does not chase. At zero, the prepared opportunity closes.</span></div>
      </aside>
    </div>`,
    { badge: "48-hour deletion clock · No chase", hideNext: true }
  );
}

const REGEN_ROOM_BRAND_LOGOS = Object.freeze({
  amazon: "app/brand-logos/amazon.svg",
  walmart: "app/brand-logos/walmart.svg",
  target: "app/brand-logos/target.svg",
  apple: "app/brand-logos/apple.svg",
  "home-depot": "app/brand-logos/home-depot.svg",
  starbucks: "app/brand-logos/starbucks.svg",
  dunkin: "app/brand-logos/dunkin.svg",
  subway: "app/brand-logos/subway.svg"
});

function regenRoomBrandLogo(brand) {
  const logo = REGEN_ROOM_BRAND_LOGOS[brand];
  return logo ? `<img src="${logo}?v=${APP_VERSION}" alt="" loading="eager" decoding="sync">` : "";
}

function renderRegenRoomV3() {
  const room = state.regenRoom || {};
  const roomUrl = String(room.url || "").trim();
  const windowHours = regenRoomWindowHours();
  const duration = regenRoomDurationLabel(windowHours);
  const expired = buildAccessExpired();
  const giftCards = [
    { name: "Amazon", brand: "amazon" },
    { name: "Walmart", brand: "walmart" },
    { name: "Target", brand: "target" },
    { name: "Apple", brand: "apple" },
    { name: "The Home Depot", brand: "home-depot" },
    { name: "Starbucks", brand: "starbucks" },
    { name: "Dunkin’", brand: "dunkin" },
    { name: "Subway", brand: "subway" }
  ];
  const timer = expiryCountdownMarkup({ offerOnly: true, label: "SITE DELETED IN" });
  const roomZones = regenRoomTimeZones();
  const centralZone = roomZones.find(zone => zone.id === "central") || { label: "CST" };
  const roomTimeCards = roomZones.map(zone => `<article class="${zone.primary ? "primary" : ""}"><small>${esc(zone.label)}</small><b>${esc(zone.time)}</b></article>`).join("");
  const roomLink = roomUrl
    ? `<a class="regenRoomOpenV4" href="${esc(roomUrl)}" target="_blank" rel="noopener">Open Zoom Room <span>↗</span></a>`
    : `<div class="regenRoomOpenV4 isMissing">Room link is being sent</div>`;
  const brands = giftCards.map(card => `<button class="regenRoomBrandV4 ${room.giftCardChoice === card.name ? "on" : ""}" data-action="regen-room-gift" data-value="${esc(card.name)}" aria-pressed="${room.giftCardChoice === card.name}" ${expired ? "disabled" : ""}>
    <span class="regenRoomBrandMarkV7" data-brand="${esc(card.brand)}" aria-hidden="true">${regenRoomBrandLogo(card.brand)}</span><b>${esc(card.name)}</b>
  </button>`).join("");

  return sceneFrame(
    `We don't do follow ups, we do <span class="accent">Most Wanted Room Concierge</span>`,
    "Bring the other decision-maker, see the site again and get one clear answer without another sales call.",
    `<div class="regenRoomV4 ${expired ? "isExpired" : ""}" data-testid="regen-room">
      <section class="regenRoomDecisionV4">
        <header class="regenRoomWindowV4">
          <div><small>PRIVATE DAILY DROP-IN · ACTIVE FOR ${esc(duration.toUpperCase())}</small><h2><i class="regenRoomLivePulseV6" aria-hidden="true"></i>1:00–2:00 PM <span>${esc(centralZone.label)}</span></h2><p>No appointment inside the hour. We set this time aside for you.</p></div>
          <div class="regenRoomTimerV4">${timer}</div>
        </header>
        <div class="regenRoomTimesV4" aria-label="Daily Most Wanted Room times across United States time zones">
          ${roomTimeCards}
        </div>
        <div class="regenRoomUsesV4">
          <article><i>👥</i><span><small>BRING THEM</small><b>Another decision-maker</b></span></article>
          <article><i>🖥️</i><span><small>SEE IT AGAIN</small><b>Your prepared site</b></span></article>
          <article><i>✓</i><span><small>LEAVE CLEAR</small><b>Launch, adjust or say no</b></span></article>
        </div>
        <div class="regenRoomPromiseV4"><span>🔒</span><div><b>Private. Pressure-free. Useful.</b><p>Ten focused minutes to resolve the one thing still stopping a clear decision.</p></div></div>
        <p class="regenRoomOutsideV4"><b>Can’t make the hour?</b> Use the same link and wait 5–10 minutes. Outside-hour availability is not guaranteed.</p>
      </section>
      <aside class="regenRoomJoinV4">
        <header><small>PRIVATE CONCIERGE ACCESS</small><h2>Your Zoom room.</h2></header>
        <div class="regenRoomAccessV5 regenRoomAccessV6">
          <span class="regenRoomZoomV6" aria-label="Zoom"><svg viewBox="0 0 64 64" role="img" aria-hidden="true"><rect width="64" height="64" rx="16" fill="#2d8cff"/><rect x="10" y="19" width="31" height="26" rx="7" fill="#fff"/><path d="M43 27.5 55 20v24L43 36.5z" fill="#fff"/></svg></span>
          <div><small>PRIVATE ZOOM ROOM</small>${roomLink}</div>
        </div>
        <button class="regenRoomConfirmV4 ${room.attendanceConfirmed ? "isConfirmed" : ""}" data-action="regen-room-confirm" aria-pressed="${Boolean(room.attendanceConfirmed)}" ${expired ? "disabled" : ""}><span>${expired ? "×" : "✓"}</span><div><small>${expired ? "WINDOW CLOSED" : (room.attendanceConfirmed ? "ATTENDANCE NOTED" : "CONFIRM ATTENDANCE")}</small><b>${expired ? "The Most Wanted Room has closed." : (room.attendanceConfirmed ? "We’ll expect you in the room." : "Yes, expect me in the room")}</b></div></button>
        <section class="regenRoomRewardV4 regenRoomRewardV5">
          <header><span class="regenRoomGiftIconV5">🎁</span><div><small>YOUR TIME, OUR TREAT</small><strong>$10 Giftcard If We See You There</strong><h3>Choose your favorite.</h3></div></header>
          <p>Show up for ten minutes and it is yours. No purchase. No strings. Even if the answer is no.</p>
          <div class="regenRoomBrandsV4" role="group" aria-label="Choose a gift card">${brands}</div>
        </section>
        <p class="regenRoomDeletionV4"><span>⏳</span><b>Prepared site + build slot reserved for ${esc(duration)}.</b></p>
      </aside>
    </div>`,
    { badge: `${regenRoomWindowLabel(windowHours)} decision window`, hideNext: true }
  );
}

function renderCloserChecklist() {
  const items = [
    ["meetingCompleted", "Meeting set as completed", "✅"],
    ["callNotesAdded", "Call notes added to deal notes", "📝"],
    ["reminderSent", `Email and text sent (${regenRoomWindowLabel()} Most Wanted Room access)`, "✉️"],
    ["finalReminderScheduled", "Final-day reminder scheduled", "⏰"],
    ["feedbackScheduled", `${regenRoomWindowHours()} hour feedback request scheduled`, "💬"],
    ["waterCompleted", "Drink a cup of water", "💧"],
    ["pushUpsCompleted", "Do 10 push ups", "💪"]
  ];
  const complete = items.filter(([id]) => Boolean(state.closerChecklist?.[id])).length;
  const rows = items.map(([id, label, icon], index) => {
    const done = Boolean(state.closerChecklist?.[id]);
    return `<button class="closerCheckItem ${done ? "isDone" : ""}" data-action="closer-check" data-id="${id}" aria-pressed="${done}" data-testid="closer-check-${id}">
      <span class="closerCheckState" aria-hidden="true">${icon}</span>
      <span class="closerCheckCopy"><small>STEP ${String(index + 1).padStart(2, "0")}</small><b>${esc(label)}</b></span>
    </button>`;
  }).join("");
  const percent = Math.round((complete / items.length) * 100);
  return sceneFrame(
    `Did you complete your <span class="accent">specialist post-call checklist?</span>`,
    "Internal only. Complete every operational step before closing the opportunity.",
    `<section class="closerChecklist" data-testid="closer-checklist">
      <header class="closerChecklistProgress">
        <div><small>CLOSER ONLY</small><strong>${complete} of ${items.length} complete</strong><span>${complete === items.length ? "Everything is wrapped up." : "Finish the remaining actions before moving on."}</span></div>
        <div class="closerProgressMeter" aria-label="${percent}% complete"><i style="--closer-progress:${percent}%"></i><b>${percent}%</b></div>
      </header>
      <div class="closerChecklistGrid">${rows}</div>
      <aside class="closerChecklistNote"><i>📄</i><div><small>NOTE</small><strong>If the client hinted that a proposal or formal offer is needed, export the PDF.</strong></div></aside>
    </section>`,
    { badge: "Internal closer use", hideNext: true }
  );
}

const RENDERERS = { opening: renderOpening, intro: renderBriefIntro, discovery: renderDiscoveryV3, cost: renderCostV3, agency: renderAgencyV3, testimonials: renderTestimonialsV3, regen: renderRegenV3, system: renderSystemV3, guarantee: renderGuaranteeV3, proof: renderProofV3, seoCompare: renderSeoCompareV3, economics: renderEconomicsV3, regenRoom: renderRegenRoomV3, closerChecklist: renderCloserChecklist, checkout: renderCheckout };

/* Latin American Spanish presentation layer. The English source and all saved
   prospect data stay untouched; only the rendered client-facing stage changes. */
const PRESENTATION_ES = Object.freeze({
  "Digital Infrastructure.":"Infraestructura digital.","One Connected System.":"Un sistema conectado.",
  "Most Wanted connects the systems that help local businesses get found, get answered and get chosen.":"Most Wanted conecta los sistemas que ayudan a los negocios locales a ser encontrados, responder y ser elegidos.",
  "One connected system. Built around one commercial goal.":"Un sistema conectado. Creado para una meta comercial.",
  "We connect the exact tools your business needs so the entire journey works together, from first search to booked job.":"Conectamos lo que su negocio necesita, desde la primera búsqueda hasta el trabajo reservado.",
  "ATTRACT":"ATRAER","RESPOND":"RESPONDER","CONVERT":"CONVERTIR","Website, Search, Maps & Ads":"Sitio, búsqueda, Maps y anuncios","Calls, Chat & Enquiries":"Llamadas, chat y consultas","Reviews, CRM & Follow-Up":"Reseñas, CRM y seguimiento",
  "SECURE TODAY’S LAUNCH":"ASEGURE SU LANZAMIENTO HOY","Start From $1":"DESDE $1","Off when launching today":"DE DESCUENTO AL LANZAR HOY",
  "Get Found":"Sea encontrado","Answer Calls":"Conteste llamadas","Get Chosen":"Sea elegido",
  "Reach people who are actively looking for what your business sells.":"Llegue a personas que ya buscan lo que su negocio ofrece.","Capture calls and enquiries before the customer chooses someone else.":"Atienda consultas antes de que el cliente elija a otro.","Build trust, follow up and turn more opportunities into paying work.":"Genere confianza, dé seguimiento y convierta oportunidades en ventas.",
  "What Most Wanted does":"Lo que hace Most Wanted","Let’s Talk About Your Business":"Hablemos de su negocio",
  "Started in":"Iniciamos en","Based in":"Con sede en","Client details":"Datos del cliente","Take Away":"Materiales","Offer Tools":"Herramientas de oferta","Call Notes":"Notas de la llamada","Full screen":"Pantalla completa","Settings":"Configuración","Previous":"Anterior","Next":"Siguiente","What Most Wanted Does":"Lo que hace Most Wanted","Most Wanted, DBA of Kailan Industries FZCO out of the UAE, all sales are contractually underwritten by Regen Digital, based in Delaware":"Most Wanted, nombre comercial de Kailan Industries FZCO de los EAU; todas las ventas están respaldadas contractualmente por Regen Digital, con sede en Delaware",
  "Your Business":"Su negocio","The Cost":"El costo","Why Agencies Fail":"Por qué fallan las agencias","Client Stories":"Historias de clientes","Why Most Wanted":"Por qué Most Wanted","SEO Comparison":"Comparación SEO","Your System":"Su sistema","See It":"Véalo","Economics":"Inversión","Decision":"Decisión","48-Hour Deadline":"Plazo de 48 horas","Closer Checklist":"Lista posllamada",
  "Understanding your business":"Entender su negocio","comes first":"es lo primero","A focused conversation about demand, lost revenue and the outcome worth building toward.":"Una conversación clara sobre demanda, ingresos perdidos y la meta que vale la pena alcanzar.",
  "Where Revenue Comes From":"De dónde llegan los ingresos","Where Revenue Is Lost":"Dónde se pierden ingresos","What I Want to Fix":"Lo que quiero resolver","Find demand":"Detectar demanda","Find friction":"Detectar fricción","Set direction":"Definir el rumbo",
  "STEP 1 · CURRENT DEMAND":"PASO 1 · DEMANDA ACTUAL","How does work reach you now?":"¿Cómo llegan hoy los clientes?","Choose every source that currently brings in real opportunities.":"Elija las fuentes que hoy generan oportunidades reales.",
  "QUICK CONTEXT":"CONTEXTO RÁPIDO","Four useful answers":"Cuatro respuestas clave","Enough context to make the rest of the conversation specific.":"El contexto necesario para hacer la conversación específica.",
  "Why Are You The Best?":"¿Por qué lo eligen?","Do You Have A Current Website?":"¿Tiene un sitio web?","How Many Calls Do You Get Monthly?":"¿Cuántas consultas recibe al mes?","Average Job Value (Revenue)":"Ingreso promedio por trabajo",
  "STEP 2 · LOST OPPORTUNITY":"PASO 2 · OPORTUNIDAD PERDIDA","Where does revenue break down?":"¿Dónde se pierden los ingresos?","Mark the friction you recognise. We will turn it into a clear priority.":"Marque los problemas que reconoce. Los convertiremos en prioridades claras.",
  "REALITY CHECK":"REALIDAD ACTUAL","What happens today?":"¿Qué ocurre hoy?","These answers connect the symptoms to a measurable cost.":"Estas respuestas convierten los síntomas en un costo medible.",
  "Current Website Performance":"Rendimiento del sitio","Missed Calls Handling Process":"Manejo de consultas perdidas","How I Manage Google Reviews":"Gestión de reseñas en Google","Percent Of Calls I Lose":"% de consultas que pierdo",
  "STEP 3 · THE WIN":"PASO 3 · LA META","What must the new system achieve?":"¿Qué debe lograr el nuevo sistema?","Choose the outcomes that would make this project feel commercially worthwhile.":"Elija los resultados que harían rentable este proyecto.",
  "MONTHLY TARGET":"META MENSUAL","Turn the goal into a number":"Convierta la meta en una cifra","Set the extra jobs wanted. We connect that goal directly to the commercial comparison.":"Defina los trabajos adicionales. Vincularemos la meta con la comparación comercial.",
  "Additional Jobs Wanted Each Month":"Trabajos adicionales por mes","ONE COMPLETED JOB":"UN TRABAJO COMPLETADO","Average revenue already entered":"Ingreso promedio ya ingresado","NEW MONTHLY REVENUE TARGET":"NUEVA META DE INGRESOS","Add in Step 1":"Añádalo en el paso 1","Calculated here":"Se calcula aquí","Add both figures to reveal the goal":"Añada ambas cifras para ver la meta","This becomes the problem-versus-investment figure shown later in the presentation.":"Esta cifra comparará el problema con la inversión más adelante.",
  "Referrals":"Referidos","Google Maps":"Google Maps","Google Search":"Búsqueda en Google","Social Media":"Redes sociales","Paid Ads":"Anuncios pagados","Repeat Customers":"Clientes recurrentes","Offline Marketing":"Marketing presencial","Community Marketing":"Marketing comunitario","My Website":"Mi sitio web",
  "Website Not Paying Back":"El sitio no genera retorno","Not Enough Inquiries":"Pocas consultas","Poor Lead Service":"Servicio de leads deficiente","Not Found on Maps / AI":"No aparezco en Maps o IA","Weak Follow-Up":"Seguimiento débil","Missed Calls":"Consultas perdidas","Too Many Providers":"Demasiados proveedores","Ads Underperforming":"Anuncios sin resultados","Messy Workflow":"Flujo de trabajo caótico",
  "Not Visible Online":"Sin visibilidad en línea","Restore Previous Plan":"Restaurar plan anterior","Add Bundle":"Añadir paquete",
  "Make More Money":"Generar más ingresos","Book More Jobs":"Reservar más trabajos","Never Miss a Call":"No perder consultas","Connect Everything":"Conectarlo todo","Get Found Locally":"Ser visible localmente","Become the Local Choice":"Ser la opción local","Build My Reputation":"Fortalecer mi reputación","Make Ads Pay":"Rentabilizar anuncios","Book Directly to My Calendar":"Reservas directas al calendario",
  "Yes":"Sí","No":"No","Being built":"En construcción","Not sure":"No estoy seguro","No website":"Sin sitio web","Not making a return":"No genera retorno","Underperforming":"Rinde poco","Performing well":"Funciona bien","Answered live":"Respuesta en vivo","Voicemail and callback":"Buzón y devolución de llamada","Sometimes missed":"A veces se pierden","Frequently missed":"Se pierden con frecuencia","Automated handling":"Atención automatizada","No process":"Sin proceso","Ask occasionally":"Pido reseñas a veces","Ask every customer manually":"Pido a cada cliente","Automated process":"Proceso automatizado",
  "The revenue you’re leaking, losing, leaving on the table":"Ingresos que se escapan y quedan sobre la mesa","Urgency Score":"Nivel de urgencia","Biggest Leaks":"Mayores fugas","Lost Revenue":"Ingresos perdidos","REVENUE LEAKAGE":"FUGA DE INGRESOS","Revenue leakage score":"Nivel de fuga de ingresos","Warning signs need attention":"Hay señales que requieren atención","Revenue is being lost now":"Se están perdiendo ingresos","LOWER LEAKAGE":"MENOR FUGA","HIGHER LEAKAGE":"MAYOR FUGA",
  "People Can’t Pay You If They Can’t See You":"Si no lo ven, no pueden contratarlo","You’re Creating Trust Issues Online":"Su presencia digital genera dudas","Clients Call, No One Gets To Them":"Las oportunidades no reciben respuesta","Calls And Enquiries Per Month":"Consultas por mes","What % Do You Miss / Not Answer":"% sin respuesta","What % Becomes A Job?":"% que se convierte en trabajo","Average Revenue (Pre Costs) Per Job?":"Ingreso promedio por trabajo","PER MONTH":"POR MES","PER YEAR":"POR AÑO",
  "The normal agency model is built to fail you":"El modelo tradicional de agencia está hecho para fallarle","We built Most Wanted to be the opposite":"Creamos Most Wanted para ser lo opuesto",
  "Hear it directly from":"Escúchelo directamente de","our clients":"nuestros clientes","our clients, picked at random":"nuestros clientes, elegidos al azar","Real clients, speaking in their own words about their experience with Most Wanted.":"Clientes reales cuentan su experiencia con Most Wanted.","AMERICAN CLIENT":"CLIENTE EN EE. UU.","CLIENT RETURN":"RESULTADO DEL CLIENTE",
  "Three SEO levels. One":"Tres niveles de SEO. Uno","keeps tightening":"mejora siempre","Compare no SEO, one launch-time setup and regular strategic work throughout the year.":"Compare: sin SEO, SEO al lanzar y trabajo estratégico todo el año.",
  "0 SEO":"SIN SEO","0 SEO Whatsoever":"Sin SEO","ONE TIME":"UNA VEZ","SEO One Time If That":"SEO una sola vez","REGULAR":"REGULAR","Regular SEO Tightening":"Ajuste de SEO Regular","REGULAR SEO INCLUDED":"SEO REGULAR INCLUIDO","Regular SEO + AI Optimization":"SEO Regular + Optimización con IA","Regular SEO":"SEO Regular",
  "Ongoing SEO. Near-zero visibility.":"Sin SEO continuo. Visibilidad casi nula.","SEO done once, at launch":"SEO hecho una vez al lanzar","Strategic reviews every year":"Revisiones estratégicas cada año","SEO ACTIVITY FACTOR":"NIVEL DE ACTIVIDAD SEO","The website is optimized for one moment in time.":"El sitio se optimiza para un solo momento.","Search is treated as repeated work, not a launch checkbox.":"La visibilidad se trabaja continuamente, no solo al lanzar.","Continuous improvement with one accountable partner.":"Mejora continua con un socio responsable.","SEO compounds.":"El SEO se acumula.","LEFT ALONE":"ABANDONADO","ACTIVE GROWTH":"CRECIMIENTO ACTIVO","Compare MW Vs. Others":"Compare MW con otros","Build Your System":"Construya su sistema",
  "See it before you":"Véalo antes de","decide":"decidir","Open the website concept and any relevant live demo. The decision should be based on what you can actually see.":"Abra el sitio preparado y las demos relevantes. Decida con base en lo que puede ver.","Real proof, not promises":"Pruebas reales, no promesas","No demos configured":"No hay demos configuradas","Nothing added yet":"Aún no se añadió nada","Open Full Screen":"Abrir en pantalla completa","Viewing":"Viendo","Open":"Abrir","See The Economics":"Ver la inversión",
  "The Most Wanted Delivery Time":"La garantía de entrega","GUARANTEE":"DE MOST WANTED","DELIVERY GUARANTEE":"GARANTÍA DE ENTREGA","PERFORMANCE GUARANTEE":"GARANTÍA DE DESEMPEÑO","GIVING BACK IF WE MISS":"APOYO COMUNITARIO SI FALLAMOS","Most Wanted performance credit":"Crédito de desempeño Most Wanted","Meals funded via Feeding America":"Comidas financiadas con Feeding America","Most Wanted is the DBA":"Most Wanted es el nombre comercial","Kailan Industries FZCO · UAE":"Kailan Industries FZCO · EAU","Sales underwritten by Regen":"Ventas respaldadas por Regen","DBA of Kailan Industries FZCO":"Nombre comercial de Kailan Industries FZCO","United Arab Emirates":"Emiratos Árabes Unidos","Kailan Industries FZCO is based here":"Kailan Industries FZCO tiene su sede aquí","Regen":"Regen","Contractually underwrites all sales":"Respalda contractualmente todas las ventas","US websites completed last year":"Sitios de EE. UU. completados el año pasado","Fast growing":"Crecimiento rápido","Built for long-term support":"Soporte a largo plazo",
  "The investment to solve your":"La inversión para resolver hoy su problema de","problem today":"al mes","See the urgent monthly problem beside the solution you can launch today.":"Compare el problema mensual con la solución que puede lanzar hoy.","STANDARD PRICE BEFORE SAVING":"PRECIO ESTÁNDAR","PRICE YOU PAY · 20% OFF APPLIED":"PRECIO FINAL · 20% APLICADO","WORK COMPLETED BEFORE THIS MEETING":"TRABAJO TERMINADO ANTES DE LA REUNIÓN","Your site is ready to launch · ≈6 focused hours invested":"Su sitio está listo · ≈6 horas de trabajo","Human design and engineering completed specifically for this business.":"Diseño e ingeniería creados para este negocio.","Standard setup":"Precio estándar","20% saving":"Ahorro del 20%","🚀 Name Your Price":"🚀 Usted elige el monto","SECURE TODAY":"ASEGURE HOY","Monthly":"Mensual","Choose Services":"Elegir servicios","Set Prices":"Definir precios","Payment Options":"Opciones de pago","Build Package":"Crear paquete","THE GAP · REVENUE NOT YET WON":"LA BRECHA · INGRESOS AÚN NO GANADOS","ADD YOUR GOAL":"AÑADA SU META","WHAT DOES TODAY'S INVESTMENT NEED TO RECOVER?":"¿QUÉ DEBE RECUPERAR LA INVERSIÓN?","Add the launch price":"Añada el precio de lanzamiento","Add the average job value":"Añada el ingreso promedio","Average completed job value":"Ingreso promedio por trabajo","Monthly opportunity gap":"Brecha mensual","Start-today solution":"Solución de hoy","Not calculated":"Sin calcular","Name Your Price":"Usted elige el monto",
  "One commercially clear":"Una decisión comercial","decision":"clara","REALITY 1 · SOLVE IT TODAY":"REALIDAD 1 · RESUÉLVALO HOY","Keep the opportunity.":"Conserve la oportunidad.","START TODAY":"EMPIECE HOY","saved":"de ahorro","ALREADY CREATED FOR YOU":"YA CREADO PARA USTED","Prepared site · ≈6 focused hours complete":"Sitio preparado · ≈6 horas completadas","Protect the design and engineering work already invested.":"Proteja el trabajo ya invertido.","LOW BARRIER TO START":"ENTRADA ACCESIBLE","From $1 where eligible. Your commitment is applied to the agreed launch price.":"Desde $1 si es elegible. Su aporte se aplica al precio acordado.","Secure My Build Today":"Asegurar mi proyecto hoy","REALITY 2 · LEAVE IT UNSOLVED":"REALIDAD 2 · DÉJELO SIN RESOLVER","Keep the problem. Lose the opportunity.":"Conserve el problema. Pierda la oportunidad.","THE PROBLEM CONTINUES":"EL PROBLEMA CONTINÚA","DISCOUNT LOST":"DESCUENTO PERDIDO","BUILD SLOT":"CUPO DE PRODUCCIÓN","Released":"Liberado","PREPARED SITE":"SITIO PREPARADO","Deleted after 48 hours":"Eliminado en 48 horas","MONEY LOST TODAY":"DINERO PERDIDO HOY","Your launch-today saving disappears.":"El ahorro por lanzar hoy desaparece.","DISCOUNT LOST TODAY":"DESCUENTO PERDIDO HOY","saving disappears":"de ahorro desaparecen","BUILD SLOT RELEASED":"CUPO DE PRODUCCIÓN LIBERADO","Production capacity moves on":"La capacidad de producción pasa a otro negocio","PREPARED SITE DELETED":"SITIO PREPARADO ELIMINADO","focused hours removed after 48 hours":"horas de trabajo eliminadas después de 48 horas","Leave It Open For 48 Hours":"Mantenerlo 48 horas",
  "Your prepared site is deleted in":"Su sitio preparado se elimina en","48 hours":"48 horas","SITE DELETED IN":"EL SITIO SE ELIMINA EN","Permanent site-deletion countdown.":"Cuenta regresiva para eliminar el sitio.","ALREADY INVESTED BEFORE THE CALL":"TRABAJO YA INVERTIDO","≈6 focused hours":"≈6 horas enfocadas","SAVING LOST TODAY":"AHORRO PERDIDO HOY","PROBLEM STILL CONTINUES":"EL PROBLEMA CONTINÚA","WHAT IS CURRENTLY RESERVED":"LO QUE ESTÁ RESERVADO","A finished site. A real build slot.":"Un sitio terminado. Un cupo real.","PREPARED WEBSITE":"SITIO PREPARADO","Ready to move into launch":"Listo para lanzar","HUMAN WORK":"TRABAJO HUMANO","≈6 focused hours complete":"≈6 horas completadas","PRODUCTION SLOT":"CUPO DE PRODUCCIÓN","Held for this opportunity":"Reservado para esta oportunidad","WHEN THE TIMER REACHES ZERO":"CUANDO EL RELOJ LLEGUE A CERO","PREPARED SITE DELETED":"SITIO PREPARADO ELIMINADO","BUILD SLOT RELEASED":"CUPO LIBERADO","PRICE PROTECTION ENDS":"TERMINA LA PROTECCIÓN DEL PRECIO","REVENUE PROBLEM REMAINS":"EL PROBLEMA DE INGRESOS CONTINÚA","NO FOLLOW-UP SALES SEQUENCE":"SIN SECUENCIA DE SEGUIMIENTO","The timer is the decision window.":"El reloj marca el plazo para decidir.","48-hour deletion clock · No chase":"Reloj de 48 horas · Sin persecución",
  "Did you complete your":"¿Completó su","specialist post-call checklist?":"lista posllamada?","Internal only. Complete every operational step before closing the opportunity.":"Solo uso interno. Complete cada paso antes de cerrar.","CLOSER ONLY":"SOLO PARA EL ESPECIALISTA","Meeting set as completed":"Marcar reunión como completada","Call notes added to deal notes":"Agregar notas al negocio","Email and text sent (48 hour reminder)":"Enviar email y mensaje de 48 horas","24 hour final reminders scheduled":"Programar recordatorio de 24 horas","72 hour feedback request scheduled":"Programar solicitud de opinión a 72 horas","Drink a cup of water":"Beber un vaso de agua","Do 10 push ups":"Hacer 10 flexiones","NOTE":"NOTA","Everything is wrapped up.":"Todo está completado.","Finish the remaining actions before moving on.":"Complete las acciones restantes.","Internal closer use":"Uso interno",
  "Select all that apply":"Elija todas las que correspondan",
  "The revenue you’re leaking, losing, leaving on the table":"Ingresos que se escapan y quedan sobre la mesa","There is no reasonable reason you can’t win 50–150% of the figure below within 30–90 days post launch.":"Es razonable recuperar entre 50% y 150% de esta cifra durante los 30 a 90 días posteriores al lanzamiento.","REVENUE LEAKAGE SCORE":"NIVEL DE FUGA DE INGRESOS","The warning signs are already costing momentum.":"Las señales actuales ya están frenando el crecimiento.","Your Online Presence Is Losing Trust":"Su presencia digital pierde confianza","Interest Isn’t Turning Into Enough Paid Work":"El interés no genera suficientes ventas",
  "The normal agency model is built to fail you":"El modelo tradicional de agencia está hecho para fallarle","These are the patterns businesses tell us they never want to experience again.":"Estos son los problemas que los negocios no quieren volver a vivir.","Separate Vendors":"Proveedores separados","Slow Delivery":"Entrega lenta","No Tangible ROI":"Sin retorno claro","Weak Accountability":"Poca responsabilidad","Disconnected Tech":"Tecnología desconectada","THE NORMAL AGENCY EXPERIENCE":"LA EXPERIENCIA TRADICIONAL","WHAT IT COSTS THE BUSINESS":"LO QUE LE CUESTA AL NEGOCIO","Nobody owns the whole result.":"Nadie se responsabiliza por el resultado completo.","You are passed between specialists, suppliers or departments. Each one protects their piece while you manage the gaps.":"Lo pasan entre especialistas y proveedores mientras usted coordina lo que queda sin resolver.","More meetings, repeated costs and no single person accountable for growth.":"Más reuniones, costos repetidos y nadie responsable del crecimiento.","Simple changes take weeks.":"Los cambios simples tardan semanas.","Your request enters a queue, gets handed off and disappears behind larger accounts.":"Su solicitud entra en una fila y queda detrás de cuentas más grandes.","The business keeps losing opportunities while you wait for work you already paid for.":"El negocio pierde oportunidades mientras espera un trabajo ya pagado.","A project launches, then nothing changes.":"El proyecto se lanza y después nada mejora.","You receive a website or campaign, but no clear link to enquiries, booked work or commercial value.":"Recibe un sitio o campaña sin conexión clara con consultas, reservas o valor comercial.","You are left wondering whether the spend did anything useful.":"Termina sin saber si la inversión produjo algo útil.","Excuses replace ownership.":"Las excusas sustituyen la responsabilidad.","Reporting sounds impressive, but deadlines move and nobody clearly owns the outcome.":"Los reportes suenan bien, pero los plazos cambian y nadie asume el resultado.","You carry the risk while the agency keeps billing.":"Usted asume el riesgo mientras la agencia sigue cobrando.","Every tool creates another problem.":"Cada herramienta crea otro problema.","Your website, calls, CRM, reviews, ads and follow-up all live in separate systems.":"Sitio, consultas, CRM, reseñas, anuncios y seguimiento viven separados.","Leads fall between the cracks and your team has to hold everything together.":"Las oportunidades se pierden y su equipo debe mantener todo unido.",
  "Add your client video testimonials":"Añada testimonios de clientes","Paste approved YouTube, Google Drive, Vimeo or direct video links in Settings. Up to three enabled testimonials appear here.":"Añada enlaces aprobados de YouTube, Google Drive, Vimeo o video directo en Configuración.","Open Testimonial Settings":"Abrir configuración de testimonios","Client video testimonials":"Testimonios en video",
  "We built Most Wanted to be the opposite":"Creamos Most Wanted para ser lo opuesto","Most Wanted was designed around eliminating the problems businesses have learned to expect from agencies.":"Most Wanted fue creado para eliminar los problemas que las empresas esperan de una agencia.","0 Monthly Fees":"0 cargos mensuales","1–24 Hour Changes":"Cambios en 1–24 horas","1–2 Contacts":"1–2 contactos","Delivery Guarantee":"Garantía de entrega","One Accountable Team":"Un equipo responsable","THE MOST WANTED MODEL":"EL MODELO MOST WANTED","Eliminate unnecessary monthly payments.":"Eliminamos pagos mensuales innecesarios.","Where a service does not need a recurring fee, we remove it. Any genuine ongoing cost is shown clearly before you decide.":"Si un servicio no necesita un cargo recurrente, lo eliminamos. Todo costo real se muestra antes de decidir.","Most everyday changes move in 1–24 hours.":"Los cambios habituales avanzan en 1–24 horas.","You are not swallowed into a slow corporate queue. Small changes are handled quickly, with larger work given a clear time.":"No entra en una fila corporativa lenta. Los cambios pequeños avanzan rápido y los grandes tienen un plazo claro.","One or two points of contact, maximum.":"Uno o dos contactos como máximo.","You know who owns the relationship. No endless hand-offs, ticket maze or repeating the story to a new person.":"Siempre sabe quién se responsabiliza. Sin traspasos ni repetir la historia.","The agreed delivery time has consequences for us.":"El plazo acordado tiene consecuencias para nosotros.","If Most Wanted misses the agreed delivery time for a Most Wanted-controlled reason, the remedies on your plan apply.":"Si Most Wanted incumple por una causa bajo su control, se aplican las garantías del plan.","One team connects the whole growth system.":"Un equipo conecta todo el sistema de crecimiento.","Website, search, reviews, calls, chat, CRM and ads can work together, with one accountable partner behind them.":"Sitio, búsqueda, reseñas, consultas, chat, CRM y anuncios trabajan juntos con un solo responsable.","Simple.":"Simple.","Fast.":"Rápido.","Accountable.":"Responsable.","Built around your business.":"Creado para su negocio.","Built differently":"Creado diferente",
  "One connected system. Or pick what you need":"Un sistema conectado. O elija lo necesario","One connected revenue growth system, or":"Un sistema conectado de crecimiento, o","pick and mix":"elija y combine","Build the final plan manually from what the discovery showed. Pricing is handled separately once the right services are selected.":"Construya el plan final según lo descubierto. El precio se define después de elegir los servicios correctos.","FINAL PLAN":"PLAN FINAL","Select Complete System":"Elegir sistema completo","Website":"Sitio web","Available if the business needs it":"Disponible si el negocio lo necesita","Included in the final plan":"Incluido en el plan final","Included ✓":"Incluido ✓","Google Maps review system":"Sistema de reseñas en Google Maps","CRM + follow-up":"CRM + seguimiento","Chatbot + receptionist":"Chatbot + recepcionista","Paid ads":"Anuncios pagados","Choose only what fits":"Elija solo lo necesario",
  "The Most Wanted delivery time guarantee":"La garantía de entrega de Most Wanted","Most Wanted misses a deadline for a launch lead time. Both commitments activate.":"Si Most Wanted incumple el plazo de lanzamiento, se activan ambos compromisos.","PERFORMANCE PROTECTION":"PROTECCIÓN DE DESEMPEÑO","ACCOUNTABILITY IN ACTION":"RESPONSABILIDAD EN ACCIÓN","If the performance guarantee is triggered, you receive $1,000 in Most Wanted performance credit.":"Si se activa la garantía, recibe $1,000 en crédito de desempeño Most Wanted.","If the performance guarantee is triggered, Most Wanted also funds 1,000 meals for Americans through Feeding America.":"Si se activa la garantía, Most Wanted también financia 1,000 comidas mediante Feeding America.","The signed plan defines the agreed delivery time, required access and the work within Most Wanted’s control.":"El plan firmado define el plazo, los accesos requeridos y el trabajo bajo control de Most Wanted.",
  "They might add a favicon and a description, but it creates no meaningful impact.":"Pueden añadir un ícono y una descripción, pero sin impacto real.","Virtually no real impact on the site's visibility":"Casi ningún impacto en la visibilidad","No specialist regularly improving visibility":"Ningún especialista mejora la visibilidad","The site is unlikely to be discovered organically":"Es improbable que el sitio aparezca orgánicamente","A site online, with no visibility engine.":"Un sitio en línea sin motor de visibilidad.","Initial audit and launch setup, usually":"Auditoría inicial y configuración al lanzar","Work commonly slows after launch instead of growing":"El trabajo se frena después del lanzamiento","Ongoing SEO often comes with a significant price tag":"El SEO continuo suele tener un costo alto","A launch task, not a continuing process.":"Una tarea de lanzamiento, no un proceso continuo.","Monthly keyword tightening that fortifies growth":"Ajuste mensual de palabras clave","Technical, page, local and AI-search work completed":"Trabajo técnico, local, de páginas y búsqueda con IA","Every system works together as one complete system":"Todos los sistemas trabajan como uno","Regular tightening keeps the website relevant as customers, competitors and search platforms change.":"El ajuste regular mantiene el sitio relevante ante clientes, competidores y buscadores.","The 0×, 1× and 12× figures describe work cadence, not a traffic or ranking promise.":"Las cifras 0×, 1× y 12× describen la frecuencia del trabajo, no prometen tráfico ni posiciones.",
  "Add a custom website in Client Details or a verified demo URL in Settings.":"Añada el sitio en Datos del cliente o una demo en Configuración.","Only demos configured in Client Details or Settings appear on this screen.":"Aquí solo aparecen las demos configuradas en Datos del cliente o Configuración.",
  "No services selected yet":"Aún no hay servicios seleccionados","YOU CHOOSE":"USTED ELIGE","Illustrative comparison based only on the business figures entered. It is not a performance guarantee.":"Comparación ilustrativa basada solo en las cifras ingresadas. No es una garantía de resultados.",
  "Keep The Solution We Launch Today.":"Conserve la solución que lanzamos hoy.","Your prepared website and production slot are secured":"Su sitio preparado y el cupo quedan asegurados","The revenue problem starts being solved now":"El problema de ingresos empieza a resolverse hoy","Agreement, payment and onboarding move forward today":"Acuerdo, pago e incorporación avanzan hoy","The commercial reality is simple: the problem stays, today’s saving disappears, the slot is reallocated and the prepared site, including approximately six focused hours of completed work, is permanently deleted when the window closes.":"La realidad es simple: el problema continúa, se pierde el ahorro, se libera el cupo y el sitio preparado se elimina al cerrar el plazo.",
  "The prepared website remains reserved only until zero. Approximately six focused hours of human design and engineering are already complete. There is no follow-up meeting and Most Wanted does not chase.":"El sitio permanece reservado hasta cero. Ya se completaron unas seis horas de diseño e ingeniería. No hay otra reunión y Most Wanted no persigue.","This is completed production work prepared for this business, not a blank proposal or future promise.":"Es trabajo de producción terminado para este negocio, no una promesa futura.","The website and completed work are permanently removed.":"El sitio y el trabajo terminado se eliminan para siempre.","Production capacity moves to the next business.":"La capacidad pasa al siguiente negocio.","The reserved offer and pricing window close.":"La oferta y su precio dejan de estar reservados.","The identified commercial problem stays unsolved.":"El problema comercial sigue sin resolverse.","Most Wanted does not chase. At zero, the prepared opportunity closes.":"Most Wanted no persigue. Al llegar a cero, la oportunidad se cierra.","If the client hinted that a proposal or formal offer is needed, export the PDF.":"Si el cliente pidió una propuesta formal, exporte el PDF.",
  "THE REVENUE YOU’RE LEAKING, LOSING, LEAVING ON THE TABLE":"INGRESOS QUE SE ESCAPAN Y QUEDAN SOBRE LA MESA","THE NORMAL AGENCY MODEL IS BUILT TO FAIL YOU":"EL MODELO TRADICIONAL DE AGENCIA ESTÁ HECHO PARA FALLARLE","WE BUILT MOST WANTED TO BE THE OPPOSITE":"CREAMOS MOST WANTED PARA SER LO OPUESTO","ONE CONNECTED SYSTEM. OR PICK WHAT YOU NEED":"UN SISTEMA CONECTADO. ELIJA LO NECESARIO","THE MOST WANTED DELIVERY TIME GUARANTEE":"GARANTÍA DE ENTREGA DE MOST WANTED","The investment to solve your":"La inversión para resolver su problema de","problem today":"hoy",
  "The revenue you’re":"Ingresos que se","leaking, losing, leaving":"escapan y se pierden","on the table":"hoy","The normal agency model is built to":"El modelo tradicional está hecho para","fail you":"fallarle","We built Most Wanted to be the":"Creamos Most Wanted para ser","opposite":"lo opuesto","One connected system. Or pick what you":"Un sistema conectado. Elija lo","need":"necesario","The Most Wanted delivery time":"Garantía de entrega","guarantee":"de Most Wanted","AI Chatbot":"Chatbot con IA","AI Receptionist":"Recepcionista con IA","Google Review System":"Sistema de reseñas de Google","CRM + Follow-Up":"CRM + seguimiento","Add Regular SEO + AI Optimization":"Añadir SEO Regular","Add Google Review System":"Añadir reseñas","Add AI Receptionist":"Añadir recepcionista","Add AI Chatbot":"Añadir chatbot","💸 SAVING LOST TODAY":"💸 AHORRO PERDIDO HOY","⚠️ PROBLEM STILL CONTINUES":"⚠️ EL PROBLEMA CONTINÚA",
  "Normal agencies keep the":"Las agencias tradicionales mantienen","same pain alive":"los mismos problemas","Slow changes, surprise costs and no commercial return are not isolated mistakes. They are the operating model businesses have been forced to accept.":"Cambios lentos, costos sorpresa y ningún retorno comercial no son errores aislados. Es el modelo que las empresas han tenido que soportar.","THE PAIN BUSINESSES ARE FORCED TO ACCEPT":"EL PROBLEMA QUE LAS EMPRESAS SOPORTAN","Slow, inconsistent changes":"Cambios lentos e inconsistentes","A simple request becomes another queue, handoff and week of waiting while the opportunity keeps moving.":"Una solicitud simple se convierte en otra fila, otro traspaso y otra semana de espera.","Your business loses momentum after you have already paid.":"Su negocio pierde impulso después de haber pagado.","Hidden costs everywhere":"Costos ocultos por todas partes","Edits, hosting, software, support and ‘out of scope’ work keep appearing after the original commitment.":"Ediciones, hosting, software, soporte y trabajo fuera de alcance aparecen después del acuerdo.","You never know the real cost of getting the result.":"Nunca conoce el costo real de obtener el resultado.","No ROI on your investment":"Sin retorno sobre su inversión","A website or campaign launches, but nobody owns the path from attention to enquiries, jobs and revenue.":"Se lanza un sitio o campaña, pero nadie se responsabiliza por convertir atención en consultas, trabajos e ingresos.","You pay for activity instead of a commercial outcome.":"Paga por actividad, no por un resultado comercial.","COMMERCIAL DAMAGE":"DAÑO COMERCIAL","THIS IS THE INDUSTRY PROBLEM":"ESTE ES EL PROBLEMA DE LA INDUSTRIA","Businesses should not have to chase the people they pay, fear the next invoice or wonder whether the work will ever produce a return.":"Las empresas no deberían perseguir a quienes pagan, temer la próxima factura ni dudar si el trabajo producirá retorno.","Three pains. Zero excuses.":"Tres problemas. Cero excusas.",
  "Most Wanted was built to":"Most Wanted fue creado para","eliminate agency pain":"eliminar el dolor de agencia","We intentionally designed Most Wanted from the ground up to change the agency industry, not copy it: less cost, more speed and real human accountability.":"Diseñamos Most Wanted desde cero para cambiar la industria, no copiarla: menos costo, más velocidad y responsabilidad humana.","BUILT DIFFERENTLY FROM DAY ONE":"CREADO DIFERENTE DESDE EL PRIMER DÍA","0 monthly fees. Long-term partnership.":"0 cargos mensuales. Alianza a largo plazo.","No endless agency retainer. We build for ownership, continuity and a relationship that stays useful long after launch.":"Sin mensualidad eterna. Construimos para la propiedad, continuidad y una relación útil después del lanzamiento.","8.4-hour average change time. Fast delivery.":"8.4 horas promedio por cambio. Entrega rápida.","A direct team and clear ownership keep everyday changes moving while the commercial opportunity is still alive.":"Un equipo directo mantiene los cambios avanzando mientras la oportunidad comercial sigue activa.","1–2 points of contact. Treated like family.":"1–2 contactos. Trato como familia.","A small accountable team learns your business, stays close and keeps every decision connected to the result.":"Un equipo pequeño aprende su negocio, se mantiene cerca y conecta cada decisión con el resultado.","INTENTIONALLY ELIMINATES":"ELIMINA INTENCIONALMENTE","Hidden monthly costs":"Costos mensuales ocultos","Distance and weak accountability":"Distancia y poca responsabilidad","THE MOST WANTED OPERATING MODEL":"EL MODELO OPERATIVO MOST WANTED","Every part of Most Wanted exists because businesses told us what they hated about agencies. We designed the opposite.":"Cada parte de Most Wanted existe porque las empresas nos dijeron qué odiaban de las agencias. Diseñamos lo opuesto.","Built to change the industry":"Creado para cambiar la industria",
  "Need more clarity? Enter the":"¿Necesita más claridad? Entre a la","Most Wanted Room":"Sala Most Wanted","Three private daily room windows to ask questions, bring another decision-maker, review the prepared site or adjust the offer.":"Tres horarios privados diarios para hacer preguntas, incluir a otra persona, revisar el sitio o ajustar la oferta.","YOUR 72-HOUR DECISION WINDOW":"SU PLAZO DE 72 HORAS","Your site remains reserved while this clock is running.":"Su sitio permanece reservado mientras corre este reloj.","The room has closed.":"La sala se cerró.","SITE SCHEDULED FOR DELETION IN":"EL SITIO SE ELIMINARÁ EN","MOST WANTED ROOM CLOSED":"SALA MOST WANTED CERRADA","DEDICATED CONSULTATION ROOM · NEXT THREE DAYS":"SALA PRIVADA · PRÓXIMOS TRES DÍAS","We expect to see you there.":"Esperamos verlo allí.","Confirm attendance now. There is no fixed appointment inside the hour. Bring your spouse, partner or any other decision-maker, even if they currently think the answer is no.":"Confirme su asistencia ahora. No hay cita fija dentro de la hora. Invite a su pareja, socio u otra persona que decida, incluso si hoy piensa que no.","Talk through doubts":"Hable de sus dudas","Say exactly how you feel. There is no pressure to launch.":"Diga lo que piensa. No hay presión para lanzar.","Bring another decision-maker":"Invite a otra persona","We can answer them directly, even if they are leaning no.":"Podemos responderle directamente, aunque piense que no.","See the site again":"Vea el sitio de nuevo","We can reopen the prepared work and explain any detail.":"Podemos mostrar el trabajo y explicar cada detalle.","Launch or modify the offer":"Lance o ajuste la oferta","Ask questions, change the scope, move forward or say no.":"Pregunte, cambie el alcance, avance o diga no.","Outside the dedicated hour:":"Fuera de la hora dedicada:","join the same Zoom and wait 5–10 minutes. There is roughly a 50/50 chance we can step in; availability is guaranteed only during the hour shown above.":"entre al mismo Zoom y espere 5–10 minutos. Hay cerca de 50% de posibilidad de que podamos entrar; solo garantizamos disponibilidad en la hora indicada.","WE WILL SEND THE LINK NOW":"ENVIAREMOS EL ENLACE AHORA","Scan it. Open it. Confirm you received it.":"Escanéelo. Ábralo. Confirme que lo recibió.","Before this call ends, make sure the Most Wanted Room opens on your phone.":"Antes de terminar, confirme que la Sala Most Wanted abre en su teléfono.","Open Most Wanted Room":"Abrir Sala Most Wanted","Add the room link in Settings":"Añada el enlace en Configuración","Confirm link received":"Confirmar enlace recibido","✓ Link received":"✓ Enlace recibido","CONFIRM ATTENDANCE":"CONFIRME ASISTENCIA","ATTENDANCE RECORDED":"ASISTENCIA REGISTRADA","Yes, note down that I’m coming.":"Sí, anote que asistiré.","We’ll expect you in the room.":"Lo esperamos en la sala.","NO STRINGS ATTACHED":"SIN CONDICIONES","$10 for 10 minutes · $60/hour":"$10 por 10 minutos · $60/hora","Choose a gift card even if you say no. It is emailed and usable immediately.":"Elija una tarjeta aunque diga no. Se envía por email y puede usarla de inmediato.","At zero:":"Al llegar a cero:","the prepared site is permanently deleted and the production slot is released.":"el sitio preparado se elimina para siempre y el cupo de producción se libera.","72 hours · Three daily room windows":"72 horas · Tres horarios diarios",
  "We don't do follow ups, we do":"No hacemos seguimientos. Ofrecemos","Most Wanted Room Concierge":"Conserjería Sala Most Wanted","Bring the other decision-maker, see the site again and get one clear answer without another sales call.":"Invite a la otra persona, vea el sitio de nuevo y obtenga una respuesta clara, sin otra llamada de ventas.","PRIVATE DAILY DROP-IN · NEXT THREE DAYS":"SALA PRIVADA DIARIA · PRÓXIMOS TRES DÍAS","No appointment inside the hour. We set this time aside for you.":"No necesita cita dentro de la hora. Reservamos este tiempo para usted.","BRING THEM":"INVÍTELO","SEE IT AGAIN":"VÉALO DE NUEVO","LEAVE CLEAR":"SALGA SEGURO","Another decision-maker":"Otra persona que decide","Your prepared site":"Su sitio preparado","Launch, adjust or say no":"Lance, ajuste o diga no","Private. Pressure-free. Useful.":"Privado. Sin presión. Útil.","Ten focused minutes to resolve the one thing still stopping a clear decision.":"Diez minutos para resolver lo único que impide una decisión clara.","Can’t make the hour?":"¿No puede en ese horario?","Use the same link and wait 5–10 minutes. Outside-hour availability is not guaranteed.":"Use el mismo enlace y espere 5–10 minutos. Fuera del horario no garantizamos disponibilidad.","PRIVATE CONCIERGE ACCESS":"ACCESO PRIVADO DE CONCIERGERÍA","Your Zoom room.":"Su sala privada en Zoom.","PRIVATE ZOOM ROOM":"SALA PRIVADA EN ZOOM","Open Zoom Room":"Abrir sala de Zoom","Room link is being sent":"El enlace de Zoom será enviado","CONFIRM NOW":"CONFIRME AHORA","ATTENDANCE NOTED":"ASISTENCIA ANOTADA","I’m coming to the Most Wanted Room":"Asistiré a la Sala Most Wanted","YOUR TIME, OUR TREAT":"SU TIEMPO, NUESTRA INVITACIÓN","$10 Giftcard If We See You There":"Tarjeta de regalo de $10 si lo vemos allí","Choose your favorite.":"Elija su favorito.","Show up for ten minutes and it is yours. No purchase. No strings. Even if the answer is no.":"Asista diez minutos y es suyo. Sin compra ni condiciones, incluso si decide no continuar.","Prepared site + build slot reserved for 72 hours.":"Sitio y cupo reservados por 72 horas.","72-hour decision window":"Plazo de decisión de 72 horas",
  "YOUR PRIVATE LINK IS SENT NOW":"SU ENLACE PRIVADO SE ENVÍA AHORA","Confirm your place.":"Confirme su asistencia.","PRIVATE MOST WANTED ROOM LINK":"ENLACE PRIVADO A LA SALA MOST WANTED","CONFIRM ATTENDANCE":"CONFIRME ASISTENCIA","Yes, expect me in the room":"Sí, espérenme en la sala","A THANK-YOU FOR YOUR TIME":"UN REGALO POR SU TIEMPO","$10 GIFT CARD":"TARJETA DE $10","Pick something you’ll actually enjoy.":"Elija algo que realmente disfrute.","Ten minutes. No purchase. No strings. Yours even if you decide not to launch.":"Diez minutos. Sin compra ni condiciones. Es suyo aunque decida no lanzar."
});

function translatePresentationText(value) {
  const source = String(value ?? "");
  const trimmed = source.trim();
  if (!trimmed) return source;
  let translated = PRESENTATION_ES[trimmed];
  if (!translated) {
    const decisionCopy = trimmed.match(/^Continuing to accept a (\$[\d,.]+) monthly problem .*? and the (\$[\d,.]+) saving .*$/);
    if (decisionCopy) translated = `Aceptar un problema mensual de ${decisionCopy[1]} es la decisión más costosa. Hoy puede proteger el proyecto, el cupo y el ahorro de ${decisionCopy[2]} con un aporte elegido por usted, desde $1 si es elegible.`;
    const offerCopy = trimmed.match(/^Today’s (\$[\d,.]+) saving is no longer available\./);
    if (offerCopy) translated = `El ahorro de ${offerCopy[1]} ya no está disponible. El sitio preparado y unas seis horas de trabajo terminado permanecen reservados solo hasta que el reloj llegue a cero.`;
  }
  if (!translated) {
    const addService = trimmed.match(/^Add (.+)$/);
    if (addService) translated = `Añadir ${PRESENTATION_ES[addService[1]] || addService[1]}`;
  }
  if (!translated) {
    for (const [pattern, replacement] of [
      [/^(\d+) selected$/, "$1 seleccionados"], [/^(\d+)\/100 REVENUE LEAKAGE$/, "$1/100 FUGA DE INGRESOS"],
      [/^(\d+) additional jobs? × (.+)$/, "$1 trabajos adicionales × $2"], [/^(\$[\d,.]+) saved$/, "$1 de ahorro"],
      [/^(\d+) of (\d+) complete$/, "$1 de $2 completados"], [/^STEP (\d+)$/, "PASO $1"],
      [/^Ready time: (.+)$/, "Tiempo de entrega: $1"], [/^Qty (\d+)$/, "Cant. $1"],
      [/^(\$[\d,.]+) per month$/, "$1 al mes"], [/^🔥 YOU SAVE (\$[\d,.]+) TODAY$/, "🔥 AHORRA $1 HOY"],
      [/^(\d+) services? included$/, "$1 servicios incluidos"],
      [/^Your (\$[\d,.]+) average job value is linked\. Add the plan price to calculate the jobs needed\.$/, "Su ingreso promedio de $1 ya está vinculado. Añada el precio del plan para calcular los trabajos necesarios."],
      [/^Today’s (\$[\d,.]+) saving is no longer available\./, "El ahorro de $1 ya no está disponible."],
      [/^Continuing to accept a (\$[\d,.]+) monthly problem/, "Aceptar un problema mensual de $1"],
      [/^(\$[\d,.]+) credit \+ ([\d,.]+) meals$/, "$1 de crédito + $2 comidas"]
    ]) if (pattern.test(trimmed)) { translated = trimmed.replace(pattern, replacement); break; }
  }
  return translated ? source.replace(trimmed, translated) : source;
}

function applyPresentationLanguage() {
  const locale = state.language?.locale === "es" ? "es" : "en";
  document.documentElement.dataset.locale = locale;
  document.documentElement.lang = locale === "es" ? "es-419" : "en";
  if (locale !== "es") return;
  const root = document.getElementById("regenStage");
  if (!root) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode(node) {
    if (!node.parentElement || node.parentElement.closest("script,style,[contenteditable='true']")) return NodeFilter.FILTER_REJECT;
    return node.nodeValue?.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
  }});
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(node => { node.nodeValue = translatePresentationText(node.nodeValue); });
  root.querySelectorAll("[placeholder],[aria-label],[title]").forEach(element => ["placeholder","aria-label","title"].forEach(attribute => {
    if (element.hasAttribute(attribute)) element.setAttribute(attribute, translatePresentationText(element.getAttribute(attribute)));
  }));
}

function fitSceneTitleToOneLine() {
  const title = document.querySelector(".sceneTitle");
  const container = title?.parentElement;
  if (!title || !container) return;
  title.style.removeProperty("font-size");
  title.style.setProperty("white-space", "nowrap", "important");
  title.style.setProperty("text-wrap", "nowrap", "important");
  let size = Number.parseFloat(getComputedStyle(title).fontSize) || 56;
  const available = Math.max(0, container.clientWidth);
  if (!available) return;
  const contentWidth = () => {
    const range = document.createRange();
    range.selectNodeContents(title);
    const renderedWidth = range.getBoundingClientRect().width;
    const transformedWidth = title.getBoundingClientRect().width;
    const layoutWidth = title.offsetWidth || title.clientWidth || 1;
    const scale = transformedWidth > 0 ? transformedWidth / layoutWidth : 1;
    return renderedWidth / (scale || 1);
  };
  const target = available * .985;
  const minimum = 30;
  const maximum = 170;
  while (contentWidth() > target && size > minimum) {
    size -= 1;
    title.style.setProperty("font-size", `${size}px`, "important");
  }
  while (contentWidth() < target && size < maximum) {
    size += 1;
    title.style.setProperty("font-size", `${size}px`, "important");
    if (contentWidth() > target) {
      size -= 1;
      title.style.setProperty("font-size", `${size}px`, "important");
      break;
    }
  }
}

function render({ shell = false } = {}) {
  if (state.currentScene === "ecosystem") state.currentScene = "recommendation";
  if (["takeaway", "decision", "offer", "buildExpiry"].includes(state.currentScene)) state.currentScene = "regenRoom";
  if (state.mode === "prospect" && state.currentScene === "closerChecklist") state.currentScene = "regenRoom";
  // Opening the Most Wanted Room starts one persisted 72-hour window. Refreshing or
  // returning to the slide never resets the clock.
  if (state.currentScene === "regenRoom") ensureBuildAccessStarted("regen-room-slide-opened");
  const app = document.getElementById("app");
  if (shell || !document.getElementById("regenStage")) app.innerHTML = stageShell();
  const viewport = document.getElementById("sceneViewport");
  const renderer = RENDERERS[state.currentScene] || renderIntro;
  viewport.innerHTML = renderer();
  const stage = document.getElementById("regenStage");
  const openingStep = Math.max(0, Math.min(10, Number(state.opening?.step) || 0));
  if (stage) {
    stage.dataset.scene = state.currentScene;
    stage.dataset.openingState = String(openingStep);
    stage.dataset.discoveryGroup = state.currentScene === "discovery" ? (DISCOVERY_GROUPS[state.discoveryStep]?.id || "presence") : "";
  }
  viewport.dataset.scene = state.currentScene;
  document.body.dataset.scene = state.currentScene;
  document.body.dataset.openingState = String(openingStep);
  document.body.dataset.discoveryGroup = state.currentScene === "discovery" ? (DISCOVERY_GROUPS[state.discoveryStep]?.id || "presence") : "";
  document.documentElement.dataset.motion = prefersReducedMotion() ? "reduced" : "full";
  if (state.currentScene === "infrastructure") prepareInfrastructureMap();
  else { infrastructureResizeObserver?.disconnect(); infrastructureResizeObserver = null; }
  document.body.classList.toggle("prospectMode", state.mode === "prospect");
  if (renderedScene !== state.currentScene) {
    track("scene_viewed", { scene: state.currentScene });
    renderedScene = state.currentScene;
    if (state.currentScene === "price" && !state.analytics.priceFirstShownAt) { state.analytics.priceFirstShownAt = now(); state.pricing.shownAt = now(); }
    if (state.currentScene === "proof") preloadNextDemo();
  }
  renderOverlay();
  applyPresentationLanguage();
  enforceReadableLightSurfaces(app);
  fitSceneTitleToOneLine();
  requestAnimationFrame(fitSceneTitleToOneLine);
  document.fonts?.ready?.then(fitSceneTitleToOneLine);
  scaleStage();
  if (state.currentScene === "regenRoom" && state.regenRoom?.expiresAt) startBuildExpiryTicker();
  else if (buildExpiryTimer) { clearInterval(buildExpiryTimer); buildExpiryTimer = null; }
  save({ sync: false });
}

function startBuildExpiryTicker() {
  if (buildExpiryTimer) clearInterval(buildExpiryTimer);
  buildExpiryTimer = setInterval(() => {
    if (state.currentScene !== "regenRoom") { clearInterval(buildExpiryTimer); buildExpiryTimer = null; return; }
    const timer = document.querySelector("[data-testid='build-countdown']");
    if (!timer || buildAccessExpired()) return render({ shell: true });
    const expiry = new Date(timer.dataset.expiry).getTime();
    const remaining = Math.max(0, expiry - Date.now());
    const values = [Math.floor(remaining / 3600000), Math.floor((remaining % 3600000) / 60000), Math.floor((remaining % 60000) / 1000)];
    timer.querySelectorAll("b span").forEach((node, index) => { node.textContent = String(values[index]).padStart(2, "0"); });
  }, 1000);
}

function renderOverlay() {
  const root = document.getElementById("overlayRoot");
  if (!root) return;
  if (modal) root.innerHTML = modalMarkup(modal);
  else if (drawer) root.innerHTML = drawerMarkup(drawer);
  else root.innerHTML = "";
  enforceReadableLightSurfaces(root);
}

function safeFlushPersistence() {
  try {
    return flushPersistence();
  } catch (error) {
    // Utility panels must still open in embedded/private browsing contexts
    // where storage can become unavailable during an otherwise valid session.
    console.warn("Most Wanted could not persist the latest utility state", error);
    return false;
  }
}

function openPresenterUtility(kind, { persist = true, rebuildPlan = false } = {}) {
  if (persist) safeFlushPersistence();
  if (rebuildPlan) buildLaunchPlan();
  drawer = null;
  modal = kind;
  renderOverlay();
}

/*
 * Final contrast guard
 * --------------------
 * The deck is intentionally dark, while editors, tables and document tools
 * use light work surfaces. This guard prevents both light-on-light and
 * dark-on-dark regressions. It only touches visible elements that render
 * actual text (or a form value), and only when their computed contrast is
 * below WCAG AA on a clearly light or clearly dark surface.
 */
function cssColor(value) {
  const match = String(value || "").match(/rgba?\(([^)]+)\)/i);
  if (!match) return null;
  const parts = match[1].split(/[ ,/]+/).filter(Boolean).map(Number);
  if (parts.length < 3 || parts.slice(0, 3).some(value => !Number.isFinite(value))) return null;
  return { r: parts[0], g: parts[1], b: parts[2], a: Number.isFinite(parts[3]) ? parts[3] : 1 };
}

function compositeColor(foreground, background) {
  const alpha = Math.max(0, Math.min(1, foreground?.a ?? 0));
  return {
    r: foreground.r * alpha + background.r * (1 - alpha),
    g: foreground.g * alpha + background.g * (1 - alpha),
    b: foreground.b * alpha + background.b * (1 - alpha),
    a: 1
  };
}

function effectiveBackground(element) {
  const layers = [];
  for (let node = element; node instanceof Element; node = node.parentElement) {
    const style = getComputedStyle(node);
    const gradientColors = [...String(style.backgroundImage || "").matchAll(/rgba?\([^)]+\)/gi)]
      .map(match => cssColor(match[0]))
      .filter(Boolean);
    if (gradientColors.length) {
      layers.push(gradientColors.reduce((average, color) => ({
        r: average.r + color.r / gradientColors.length,
        g: average.g + color.g / gradientColors.length,
        b: average.b + color.b / gradientColors.length,
        a: average.a + color.a / gradientColors.length
      }), { r: 0, g: 0, b: 0, a: 0 }));
      continue;
    }
    const color = cssColor(style.backgroundColor);
    if (color && color.a > 0) layers.push(color);
  }
  let result = { r: 3, g: 27, b: 23, a: 1 };
  layers.reverse().forEach(layer => { result = compositeColor(layer, result); });
  return result;
}

function relativeLuminance(color) {
  const channel = value => {
    const normalized = Math.max(0, Math.min(255, value)) / 255;
    return normalized <= .04045 ? normalized / 12.92 : ((normalized + .055) / 1.055) ** 2.4;
  };
  return .2126 * channel(color.r) + .7152 * channel(color.g) + .0722 * channel(color.b);
}

function contrastRatio(first, second) {
  const a = relativeLuminance(first), b = relativeLuminance(second);
  return (Math.max(a, b) + .05) / (Math.min(a, b) + .05);
}

function enforceReadableLightSurfaces(root) {
  if (!(root instanceof Element)) return;
  root.querySelectorAll("*").forEach(element => {
    element.classList.remove("autoContrastOnLight");
    element.classList.remove("autoContrastOnDark");
    // The proposal pledge is an intentionally dark document component with
    // its own white/turquoise palette. Its translucent gradient can look
    // light to the generic sampler, so leave its explicit palette untouched.
    if (element.closest(".proposalPledge,.revenueGapHeadline,.revenueGapConclusion")) return;
    if (element.matches("script,style,svg,path,img,picture,video,iframe,canvas")) return;
    const rect = element.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const tag = element.tagName;
    const hasFormValue = ["INPUT", "TEXTAREA", "SELECT", "OPTION"].includes(tag);
    const directText = [...element.childNodes].some(node => node.nodeType === Node.TEXT_NODE && /[\p{L}\p{N}]/u.test(node.textContent));
    if (!hasFormValue && !directText) return;
    const style = getComputedStyle(element);
    const foreground = cssColor(style.color);
    if (!foreground) return;
    const background = effectiveBackground(element);
    if (contrastRatio(foreground, background) < 4.5) {
      const darkInk = { r: 8, g: 35, b: 31, a: 1 };
      const lightInk = { r: 248, g: 255, b: 253, a: 1 };
      if (contrastRatio(darkInk, background) >= contrastRatio(lightInk, background)) {
        element.classList.add("autoContrastOnLight");
      } else {
        element.classList.add("autoContrastOnDark");
      }
    }
  });
}

function proposalDate(value = new Date()) {
  return new Intl.DateTimeFormat("en-US", { day: "numeric", month: "long", year: "numeric" }).format(value);
}

function proposalReference() {
  const saved = String(state.proposal?.reference || "").trim();
  if (saved) return saved;
  const created = new Date(state.createdAt || now());
  const year = created.getFullYear();
  const month = String(created.getMonth() + 1).padStart(2, "0");
  return `RD-${year}-${month}-${String(state.id || "0000").slice(-4).toUpperCase()}`;
}

function proposalValidThrough() {
  const days = Math.max(1, Math.min(365, Number(state.proposal?.validDays) || 14));
  const date = new Date();
  date.setDate(date.getDate() + days);
  return proposalDate(date);
}

function proposalLogoSrc() {
  return new URL(PROPOSAL_LOGO_SRC, location.href).href;
}

function applyProposalContentDefaults() {
  state.proposal ||= {};
  const oldSummary = "Thank you for meeting with us. This proposal explains what we will build, what it costs and what happens next.";
  const oldNeeds = "Your business details, chosen domain, any account access we need and prompt approval when we ask for it.";
  Object.assign(state.proposal, {
    title: REGEN_PROPOSAL_TITLE,
    preparedByEmail: REGEN_CONTACT_EMAIL,
    preparedByPhone: REGEN_CONTACT_PHONE
  });
  if (!String(state.proposal.introduction || "").trim() || state.proposal.introduction === oldSummary) state.proposal.introduction = REGEN_PROPOSAL_SUMMARY;
  if (!String(state.proposal.customerNeeds || "").trim() || state.proposal.customerNeeds === oldNeeds) state.proposal.customerNeeds = REGEN_PROPOSAL_CUSTOMER_NEEDS;
  state.proposal.itemNotes = state.proposal.itemNotes && typeof state.proposal.itemNotes === "object" ? state.proposal.itemNotes : {};
  Object.entries(REGEN_PROPOSAL_SERVICE_COPY).forEach(([id, copy]) => {
    if (!String(state.proposal.itemNotes[id] || "").trim()) state.proposal.itemNotes[id] = copy;
  });
}

function proposalScopeItems() {
  applyProposalContentDefaults();
  const proposal = state.proposal || {};
  const itemNotes = proposal.itemNotes || {};
  const linked = selectedServices().map(service => ({
    kind: "linked", id: service.id, icon: service.icon, name: service.name,
    quantity: service.quantity, setup: Math.max(0, Number(service.setup) || 0) * service.quantity,
    monthly: Math.max(0, Number(service.monthly) || 0) * service.quantity,
    window: serviceTimeToLive(service), deliverable: service.deliverable || service.name + " setup",
    description: itemNotes[service.id] || service.deliverable || service.name + " setup",
    customer: service.customer || ""
  }));
  const manual = (Array.isArray(proposal.manualItems) ? proposal.manualItems : []).map((item, index) => ({
    kind: "manual", id: String(item.id || ("manual-" + index)), icon: String(item.icon || "🧩"),
    name: String(item.name || "Custom scope item"), quantity: Math.max(1, Math.floor(Number(item.quantity) || 1)),
    setup: Math.max(0, Number(item.setup) || 0) * Math.max(1, Math.floor(Number(item.quantity) || 1)),
    monthly: Math.max(0, Number(item.monthly) || 0) * Math.max(1, Math.floor(Number(item.quantity) || 1)),
    window: String(item.window || "To be agreed"), deliverable: String(item.deliverable || item.description || "Custom scope to be agreed"),
    description: String(item.description || item.deliverable || "Custom scope to be agreed"), customer: ""
  }));
  return [...linked, ...manual];
}

function proposalCommercials(scope = proposalScopeItems()) {
  const linkedSetup = scope.filter(item => item.kind === "linked").reduce((sum, item) => sum + item.setup, 0);
  const linkedMonthly = scope.filter(item => item.kind === "linked").reduce((sum, item) => sum + item.monthly, 0);
  const manualSetup = scope.filter(item => item.kind === "manual").reduce((sum, item) => sum + item.setup, 0);
  const manualMonthly = scope.filter(item => item.kind === "manual").reduce((sum, item) => sum + item.monthly, 0);
  const live = priceSummary();
  const linkedBaseSetup = state.pricing.manualSetup ? live.standardSetup : linkedSetup;
  const linkedBaseMonthly = state.pricing.manualMonthly ? live.monthly : linkedMonthly;
  const standardSetup = linkedBaseSetup + manualSetup;
  const effectiveSetup = standardSetup;
  const monthly = linkedBaseMonthly + manualMonthly;
  return { standardSetup, effectiveSetup, monthly, firstYear: effectiveSetup + (monthly * 12) };
}

function proposalData() {
  buildLaunchPlan();
  const selected = selectedServices();
  const scope = proposalScopeItems();
  const price = proposalCommercials(scope);
  const business = state.prospect.business || "Your Business";
  const contact = state.prospect.name || "Business Owner";
  const proposal = state.proposal || {};
  return {
    proposal,
    business,
    contact,
    reference: proposalReference(),
    date: proposalDate(),
    validThrough: proposalValidThrough(),
    selected,
    scope,
    price,
    overallLaunchWindow: selected.length ? overallLaunchTiming() : (scope.length ? "The ready time for each service is shown below." : "Ready times are agreed after the services are confirmed."),
    customerRequirements: [...new Set(selected.map(service => service.customer).filter(Boolean))],
    pledge: guaranteeFullyConfigured() ? state.guarantee : null
  };
}

function proposalDocumentMarkup(data = proposalData()) {
  const { proposal, business, contact, reference, date, validThrough, scope, price, overallLaunchWindow, customerRequirements, pledge } = data;
  const priceRows = [
    ...(price.monthly ? [["Monthly support", `${money(price.monthly)} / month`]] : []),
    ["Price For Life", money(price.standardSetup)]
  ];
  const scopeMarkup = scope.length ? scope.map(service => {
    return `<article class="proposalService">
    <div class="proposalServiceIcon">${esc(` ${service.icon} `)}</div>
    <div><h3>${esc(service.name)}${service.quantity > 1 ? ` <small>Qty ${service.quantity}</small>` : ""}${service.kind === "manual" ? " <small>Custom</small>" : ""}</h3><p>${esc(service.description)}</p></div>
    <div class="proposalServiceTiming"><b>Ready time</b><span>${esc(serviceTimeToLive(service))}</span></div>
    <div class="proposalServicePricing"><b>Price</b><span>${money(service.setup)}${service.monthly ? ` + ${money(service.monthly)}/mo` : ""}</span></div>
  </article>`;
  }).join("") : `<p class="proposalEmpty">Add a custom scope item in the proposal builder. This proposal can be sent without a pitch-deck plan.</p>`;
  const pledgeMarkup = pledge ? `<section class="proposalPledge"><div><span>On-time launch pledge</span><h2>${esc(pledge.title)}</h2><p>${esc(pledge.trigger)}</p></div><div class="proposalPledgeRemedies"><b>${money(pledge.buyerCredit)} ${esc(pledge.buyerCreditLabel)}</b>${pledge.charityEnabled ? `<b>${number(pledge.mealQuantity)} meals funded</b>` : ""}</div></section>` : "";
  return `<article class="proposalDocument" data-testid="proposal-preview">
    <header class="proposalDocHeader">
      <img class="proposalLogo" src="${esc(proposalLogoSrc())}" alt="Most Wanted">
      <div class="proposalDocRef">PROPOSAL <strong>${esc(reference)}</strong></div>
    </header>
    <section class="proposalCover">
      <p class="proposalEyebrow">MOST WANTED PROPOSES</p>
      <h1>Proposal for ${esc(business)}</h1>
      <h2>${esc(REGEN_PROPOSAL_TITLE)}</h2>
      <dl class="proposalMeta">
        <div><dt>Prepared for</dt><dd>${esc(contact)}${state.prospect.business ? ` · ${esc(business)}` : ""}</dd></div>
        <div><dt>Prepared by</dt><dd>${esc(proposal.preparedBy || "Kailan")} - ${esc(proposal.preparedByTitle || "Owner")}</dd></div>
        <div><dt>Date</dt><dd>${esc(date)}</dd></div>
        <div><dt>Valid through</dt><dd>${esc(validThrough)}</dd></div>
      </dl>
    </section>
    <section class="proposalSection proposalIntro proposalAtomic"><h2><span>1.</span> Summary</h2><p>${esc(proposal.introduction)}</p><p>${esc(proposal.scopeNote)}</p></section>
    <section class="proposalSection"><div class="proposalSectionIntro"><h2><span>2.</span> What is included</h2><p class="proposalSectionLead">Each service in your plan is listed below.</p></div><div class="proposalServices">${scopeMarkup}</div></section>
    <section class="proposalSection proposalAtomic"><h2><span>3.</span> ${esc(proposal.outlineHeading || "What we will do")}</h2><p>${esc(proposal.outline)}</p></section>
    <section class="proposalSection proposalTwoColumn"><div class="proposalKeepBlock"><h2><span>4.</span> ${esc(proposal.timelineHeading || "Ready times and support")}</h2><p class="proposalLaunchWindow">${esc(overallLaunchWindow)}</p><p>${esc(proposal.supportNote || state.support.onboarding)}</p></div><div class="proposalTimeList proposalKeepBlock"><h3>Ready times</h3>${scope.map(service => `<div><span>${esc(` ${service.icon} `)} ${esc(service.name)}</span><b>${esc(service.window)}</b></div>`).join("") || "<p>Add a ready time for each service.</p>"}</div></section>
    ${pledgeMarkup}
    <section class="proposalSection proposalCommercial proposalAtomic"><h2><span>5.</span> ${esc(proposal.commercialHeading || "Price and payment")}</h2><p>${esc(proposal.paymentNote)}</p><div class="proposalInvestment"><div class="proposalInvestmentHead"><span>Price summary</span><b>Agreed investment</b></div>${priceRows.map(([label, value], index) => `<div class="proposalPriceRow ${index === priceRows.length - 1 ? "proposalPriceTotal" : ""}"><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`).join("")}</div></section>
    <section class="proposalSection proposalTwoColumn"><div class="proposalKeepBlock"><h2><span>6.</span> ${esc(proposal.termsHeading || "Important details")}</h2><p>${esc(proposal.terms)}</p><p class="proposalExclusions">${esc(proposal.exclusions)}</p></div><div class="proposalKeepBlock"><h2><span>7.</span> ${esc(proposal.responsibilitiesHeading || "What we need from you")}</h2><p>${esc(REGEN_PROPOSAL_CUSTOMER_NEEDS)}</p></div></section>
    <section class="proposalSection proposalNext proposalAtomic"><h2><span>8.</span> ${esc(proposal.nextStepsHeading || "Next steps")}</h2><p>${esc(proposal.nextSteps)}</p></section>
    <footer class="proposalDocFooter"><span><b>Kailan - Owner · Most Wanted</b></span><span>DBA of Kailan Industries FZCO (UAE) · Sales contractually underwritten by Regen Digital (Delaware)</span></footer>
  </article><style class="proposalPrintOverrides">@media screen{.proposalSectionIntro>h2,.proposalKeepBlock>h2{margin:0 0 9px;padding-bottom:6px;border-bottom:1px solid #c7c9cd;color:#111214;font-family:var(--editorial);font-size:21px;line-height:1.1}.proposalSectionIntro>h2 span,.proposalKeepBlock>h2 span{color:#3f4349}}@media print{.proposalDocument{overflow:visible!important}.proposalCover,.proposalDocHeader,.proposalDocFooter,.proposalAtomic,.proposalSectionIntro,.proposalService,.proposalPledge,.proposalInvestment,.proposalKeepBlock,.proposalSignature{break-inside:avoid-page;page-break-inside:avoid}.proposalSectionIntro,.proposalSection>h2{break-after:avoid-page;page-break-after:avoid}.proposalService p,.proposalSection p,.proposalSection li{overflow-wrap:break-word;word-break:normal;orphans:3;widows:3}}</style>`;
}

function proposalPrintDocument() {
  const data = proposalData();
  const title = `Most Wanted Proposal - ${data.business}`;
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>
    @page{size:Letter portrait;margin:.68in .72in .7in}
    html,body{width:auto;height:auto;margin:0;padding:0;overflow:visible!important;background:#fff}
    *{box-sizing:border-box}
    .proposalDocument{width:100%;max-width:none;margin:0;overflow:visible;font-family:Arial,Helvetica,sans-serif;color:#142421;background:#fff;font-size:10.2pt;line-height:1.48}
    .proposalDocHeader{display:flex;justify-content:space-between;align-items:center;gap:20pt;padding:0 0 12pt;border-bottom:1.5pt solid #123b36;break-inside:avoid-page;page-break-inside:avoid}
    .proposalLogo{display:block;width:170pt;height:auto;max-width:48%;max-height:40pt;object-fit:contain;object-position:left center}
    .proposalDocRef{font-size:8pt;letter-spacing:1pt;color:#56635f;font-weight:700;text-align:right;white-space:nowrap}
    .proposalDocRef strong{display:block;margin-top:2pt;color:#143d38;letter-spacing:.5pt}
    .proposalCover{padding:20pt 0 12pt;break-inside:avoid-page;page-break-inside:avoid}
    .proposalEyebrow{margin:0 0 5pt;color:#087d73;font-size:8pt;font-weight:700;letter-spacing:1.3pt}
    .proposalCover h1{margin:0;color:#172522;font-size:28pt;line-height:1.08;letter-spacing:-.8pt;overflow-wrap:break-word}
    .proposalCover h2{margin:6pt 0 15pt;color:#087d73;font-size:19pt;line-height:1.15;overflow-wrap:break-word}
    .proposalMeta{display:grid;grid-template-columns:1fr 1fr;margin:0;border:1pt solid #d9d3c7;border-radius:7pt;overflow:hidden}
    .proposalMeta div{display:grid;grid-template-columns:78pt minmax(0,1fr);min-height:33pt;border-bottom:.6pt solid #ded9d0;break-inside:avoid-page;page-break-inside:avoid}
    .proposalMeta div:nth-last-child(-n+2){border-bottom:0}
    .proposalMeta dt{display:flex;align-items:center;padding:7pt 9pt;background:#f6f4ee;color:#087269;font-size:7.3pt;font-weight:700;letter-spacing:.6pt;text-transform:uppercase}
    .proposalMeta dd{display:flex;align-items:center;min-width:0;margin:0;padding:7pt 9pt;font-weight:700;overflow-wrap:break-word}
    .proposalSection{padding:15pt 0 0;overflow:visible;break-inside:auto;page-break-inside:auto}
    .proposalSection>h2,.proposalSectionIntro>h2,.proposalKeepBlock>h2{margin:0 0 7pt;padding-bottom:5pt;border-bottom:1pt solid #c4f0eb;font-size:16pt;line-height:1.14;break-after:avoid-page;page-break-after:avoid}
    .proposalSection h2 span{color:#1fc9bb}
    .proposalSection p{margin:0 0 8pt;overflow-wrap:break-word;word-break:normal;orphans:3;widows:3}
    .proposalSectionIntro{break-inside:avoid-page;page-break-inside:avoid;break-after:avoid-page;page-break-after:avoid}
    .proposalSectionLead{color:#5d6d68;font-size:9.5pt}
    .proposalAtomic,.proposalPledge,.proposalInvestment,.proposalKeepBlock,.proposalSignature{break-inside:avoid-page;page-break-inside:avoid}
    .proposalServices{overflow:visible;border:0;border-radius:0}
    .proposalService{display:grid;grid-template-columns:29pt minmax(0,1fr) 76pt 132pt;gap:7pt;align-items:center;margin:0 0 7pt;padding:8pt 9pt;border:1pt solid #dbded9;border-radius:8pt;break-inside:avoid-page;page-break-inside:avoid}
    .proposalService:first-child{break-before:avoid-page;page-break-before:avoid}
    .proposalServiceIcon{display:grid;place-items:center;width:26pt;height:26pt;border-radius:7pt;background:#e1faf7;font-size:14pt}
    .proposalService h3{margin:0;font-size:11pt;line-height:1.25;overflow-wrap:break-word}
    .proposalService h3 small{display:inline-block;padding:2pt 4pt;border-radius:4pt;background:#edf4f2;color:#47655f;font-size:7pt}
    .proposalService p{margin:2pt 0 0;color:#60716b;font-size:8.5pt;line-height:1.32;overflow-wrap:break-word;word-break:normal;orphans:3;widows:3}
    .proposalServiceTiming,.proposalServicePricing{min-width:0;text-align:right;overflow-wrap:break-word}
    .proposalServiceTiming b,.proposalServicePricing b{display:block;color:#71817c;font-size:6.8pt;letter-spacing:.6pt;text-transform:uppercase}
    .proposalServiceTiming span{color:#087269;font-size:8.5pt;font-weight:700}
    .proposalServicePricing span{display:block;color:#143d38;font-size:7.8pt;font-weight:700;line-height:1.25;white-space:nowrap;overflow-wrap:normal;word-break:normal;font-variant-numeric:tabular-nums}
    .proposalTwoColumn{display:block}
    .proposalKeepBlock+.proposalKeepBlock{margin-top:12pt}
    .proposalLaunchWindow{padding:8pt 9pt;border-left:3pt solid #1fc9bb;background:#edf9f7;color:#123f39;font-weight:700}
    .proposalTimeList{padding:11pt;border:1pt solid #d8e8e5;border-radius:8pt;background:#f7fbfa}
    .proposalTimeList h3{margin:0 0 5pt;font-size:9.5pt}
    .proposalTimeList>div{display:flex;justify-content:space-between;gap:12pt;padding:4pt 0;border-bottom:.6pt solid #e0ece9;font-size:8pt;break-inside:avoid-page;page-break-inside:avoid}
    .proposalTimeList>div:last-child{border-bottom:0}
    .proposalTimeList span{min-width:0;overflow-wrap:break-word}
    .proposalTimeList b{color:#087269;text-align:right}
    .proposalPledge{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:15pt;margin-top:15pt;padding:13pt 15pt;border-radius:9pt;background:#0c302b;color:#f8fffd;-webkit-text-fill-color:#f8fffd}
    .proposalPledge span{color:#67e1d6;-webkit-text-fill-color:#67e1d6;font-size:7.5pt;font-weight:700;letter-spacing:1pt;text-transform:uppercase}
    .proposalPledge h2{margin:4pt 0 3pt;color:#fff;-webkit-text-fill-color:#fff;font-size:16pt;line-height:1.12}
    .proposalPledge p{margin:0;color:#d7e8e5;-webkit-text-fill-color:#d7e8e5;font-size:8.7pt}
    .proposalPledgeRemedies{display:flex;flex-direction:column;justify-content:center;gap:5pt;text-align:right;color:#67e1d6;-webkit-text-fill-color:#67e1d6;font-size:10pt;white-space:nowrap}
    .proposalPledgeRemedies b{color:#67e1d6;-webkit-text-fill-color:#67e1d6}
    .proposalInvestment{border:1pt solid #d7dedb;border-radius:8pt;overflow:hidden}
    .proposalInvestmentHead,.proposalPriceRow{display:flex;justify-content:space-between;align-items:center;gap:12pt;padding:8pt 10pt;border-bottom:.6pt solid #dfe5e2}
    .proposalInvestmentHead{background:#effaf8;color:#087269;font-size:8pt;font-weight:700;letter-spacing:.6pt;text-transform:uppercase}
    .proposalPriceRow{font-size:10pt;break-inside:avoid-page;page-break-inside:avoid}
    .proposalPriceRow strong{font-size:11pt;white-space:nowrap}
    .proposalPriceTotal{border-bottom:0;background:#0c302b;color:#fff;font-weight:700}
    .proposalPriceTotal strong{color:#64e1d6;font-size:15pt}
    .proposalRequirements{margin:7pt 0 0;padding-left:15pt}
    .proposalRequirements li{margin:3pt 0;overflow-wrap:break-word;orphans:3;widows:3}
    .proposalNext{padding-bottom:14pt}
    .proposalSignature{display:flex;flex-direction:column;gap:2pt;margin-top:14pt;padding-top:10pt;border-top:.7pt solid #d8d4ca}
    .proposalSignature b{font-size:11pt}
    .proposalSignature span{color:#586864;font-size:8.5pt}
    .proposalDocFooter{display:flex;justify-content:space-between;gap:12pt;padding-top:8pt;border-top:.7pt solid #d8d4ca;color:#7a8985;font-size:7.5pt;break-inside:avoid-page;page-break-inside:avoid}
    .proposalDocument{color:#111214}
    .proposalDocHeader{border-bottom-color:#111214}
    .proposalDocRef,.proposalDocRef strong,.proposalEyebrow,.proposalCover h2,.proposalMeta dt,.proposalSection h2 span,.proposalServiceTiming span,.proposalServicePricing span,.proposalTimeList b{color:#303238}
    .proposalMeta,.proposalMeta div,.proposalSection>h2,.proposalSectionIntro>h2,.proposalKeepBlock>h2,.proposalService,.proposalInvestment,.proposalInvestmentHead,.proposalPriceRow,.proposalTimeList,.proposalTimeList>div{border-color:#c5c8cd}
    .proposalMeta dt,.proposalServiceIcon,.proposalService h3 small,.proposalTimeList,.proposalInvestmentHead{background:#eceef0;color:#303238}
    .proposalLaunchWindow{border-left-color:#111214;background:#f0f0ef;color:#111214}
    .proposalPledge,.proposalPriceTotal{background:#111214;color:#fff;-webkit-text-fill-color:#fff}
    .proposalPledge span,.proposalPledge h2,.proposalPledge p,.proposalPledgeRemedies,.proposalPledgeRemedies b,.proposalPriceTotal strong{color:#fff;-webkit-text-fill-color:#fff}
    @media print{html,body{overflow:visible!important}.proposalDocument{width:100%;max-width:none;margin:0}.proposalServices{overflow:visible}}
  </style></head><body>${proposalDocumentMarkup(data)}</body></html>`;
}

function legacyProposalModal() {
  const editor = `<aside class="proposalEditor"><div class="proposalEditorIntro"><span>Formal proposal</span><h3>Fill what is specific. The live scope, timing and commercial figures are pulled in automatically.</h3></div><div class="proposalEditorScroll"><section><h4>Proposal details</h4><div class="formGrid">${field("proposal.title", "Proposal title", "text", { full: true, readonly: true })}${field("proposal.reference", "Reference", "text", { placeholder: proposalReference() })}${field("proposal.validDays", "Valid for days", "number", { min: 1, max: 365 })}</div></section><section><h4>Prepared by</h4><div class="formGrid three">${field("proposal.preparedBy", "Name")}${field("proposal.preparedByTitle", "Role")}${field("proposal.preparedByEmail", "Email", "text", { readonly: true })}${field("proposal.preparedByPhone", "Phone", "text", { readonly: true })}</div></section><section><h4>Proposal copy</h4><div class="formGrid">${field("proposal.introduction", "Introduction", "textarea", { full: true })}${field("proposal.scopeNote", "Scope note", "textarea", { full: true })}${field("proposal.supportNote", "Support and launch", "textarea", { full: true })}${field("proposal.paymentNote", "Fees and payment", "textarea", { full: true })}${field("proposal.terms", "Terms", "textarea", { full: true })}${field("proposal.customerNeeds", "What we need from them", "textarea", { full: true })}${field("proposal.nextSteps", "Next steps", "textarea", { full: true })}</div></section></div></aside>`;
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal proposalModal" data-testid="proposal-modal"><header class="modalHead"><div><small>Linked to the live plan</small><h2>Formal Proposal</h2></div><button class="iconBtn" data-action="close-overlay" aria-label="Close proposal">×</button></header><div class="proposalModalBody">${editor}<section class="proposalPreviewPane"><div class="proposalPreviewToolbar"><span>Live print preview</span><span>${esc(proposalReference())}</span></div><div class="proposalPreview">${proposalDocumentMarkup()}</div></section></div><footer class="modalFoot"><button class="ghostBtn" data-action="proposal-refresh">Refresh preview</button><button class="primaryBtn" data-action="proposal-pdf" data-testid="proposal-export-pdf">Export PDF</button></footer></section></div>`;
}

function proposalManualLineEditor(item, index) {
  const base = "proposal.manualItems." + index;
  return `<article class="proposalManualItem" data-testid="proposal-manual-item-${index}">
    <header><span>${esc(item.icon || "🧩")}</span><b>Custom scope item ${index + 1}</b><button class="iconBtn" data-action="proposal-remove-item" data-index="${index}" aria-label="Remove custom scope item">×</button></header>
    <div class="formGrid proposalItemGrid">
      ${field(base + ".icon", "Icon", "text")}
      ${field(base + ".name", "Product or service", "text", { full: true })}
      ${field(base + ".quantity", "Quantity", "number", { min: 1, max: 99 })}
      ${field(base + ".setup", "One-time price, each", "number", { min: 0, currency: true })}
      ${field(base + ".monthly", "Monthly price, each", "number", { min: 0, currency: true })}
      ${field(base + ".window", "Ready time", "text", { full: true })}
      ${field(base + ".description", "What is included and why it matters", "textarea", { full: true })}
    </div>
  </article>`;
}

function proposalModal() {
  applyProposalContentDefaults();
  const proposal = state.proposal || {};
  const selected = selectedServices();
  const manualItems = Array.isArray(proposal.manualItems) ? proposal.manualItems : [];
  const linkedNotes = selected.length
    ? `<section class="proposalEditorSection"><div class="proposalSectionTitle"><div><span>Linked presentation scope</span><h4>Explain each selected system</h4></div><span class="proposalPill">${selected.length} linked</span></div><p class="proposalEditorHelp">These lines stay linked to the live plan, quantities, timing and item-by-item pricing. You can still tailor their explanation for this tender.</p><div class="proposalLinkedNotes">${selected.map(service => field("proposal.itemNotes." + service.id, " " + service.icon + " " + service.name + " explanation", "textarea", { full: true, help: "Leave blank to use the configured service explanation." })).join("")}</div></section>`
    : `<section class="proposalEmptyLinked"><b>No presentation products are selected.</b><p>Build this proposal manually below. It will export normally without a pitch-deck scope.</p></section>`;
  const manual = `<section class="proposalEditorSection"><div class="proposalSectionTitle"><div><span>Manual tender scope</span><h4>Add products, prices and explanations</h4></div><button class="ghostBtn" data-action="proposal-add-item" data-testid="proposal-add-item">+ Add item</button></div><p class="proposalEditorHelp">Use this for any product, option or package that is not selected in the presentation. Quantity and price feed directly into the proposal total.</p><div class="proposalManualItems">${manualItems.map(proposalManualLineEditor).join("") || `<div class="proposalManualEmpty">No manual items yet. Add a custom line to build a proposal from scratch.</div>`}</div></section>`;
  const editor = `<aside class="proposalEditor"><div class="proposalEditorIntro"><span>Formal tender builder</span><h3>Build the commercial proposal here. Use the live plan, manual scope, or both.</h3></div><div class="proposalEditorScroll">
    <section class="proposalEditorSection"><div class="proposalSectionTitle"><div><span>Proposal details</span><h4>Who this is for</h4></div></div><div class="formGrid">${field("proposal.title", "Proposal title", "text", { full: true, readonly: true })}${field("proposal.reference", "Reference", "text", { placeholder: proposalReference() })}${field("proposal.validDays", "Valid for days", "number", { min: 1, max: 365 })}</div></section>
    <section class="proposalEditorSection"><div class="proposalSectionTitle"><div><span>Prepared by</span><h4>Your proposal details</h4></div></div><div class="formGrid three">${field("proposal.preparedBy", "Name")}${field("proposal.preparedByTitle", "Role")}${field("proposal.preparedByEmail", "Email", "text", { readonly: true })}${field("proposal.preparedByPhone", "Phone", "text", { readonly: true })}</div></section>
    ${linkedNotes}
    ${manual}
    <section class="proposalEditorSection"><div class="proposalSectionTitle"><div><span>Tender narrative</span><h4>Make the case in your own words</h4></div></div><div class="formGrid">
      ${field("proposal.introduction", "Executive summary", "textarea", { full: true })}
      ${field("proposal.scopeNote", "Scope context", "textarea", { full: true })}
      ${field("proposal.outlineHeading", "Delivery outline heading", "text")}
      ${field("proposal.outline", "Delivery outline", "textarea", { full: true })}
      ${field("proposal.timelineHeading", "Delivery and support heading", "text")}
      ${field("proposal.supportNote", "Delivery and support explanation", "textarea", { full: true })}
      ${field("proposal.commercialHeading", "Commercial section heading", "text")}
      ${field("proposal.paymentNote", "Commercial explanation", "textarea", { full: true })}
      ${field("proposal.termsHeading", "Terms heading", "text")}
      ${field("proposal.terms", "Terms and assumptions", "textarea", { full: true })}
      ${field("proposal.exclusions", "Exclusions or boundaries", "textarea", { full: true })}
      ${field("proposal.responsibilitiesHeading", "Client responsibilities heading", "text")}
      ${field("proposal.customerNeeds", "Client responsibilities", "textarea", { full: true })}
      ${field("proposal.nextStepsHeading", "Next steps heading", "text")}
      ${field("proposal.nextSteps", "Next steps", "textarea", { full: true })}
    </div></section>
  </div></aside>`;
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal proposalModal" data-testid="proposal-modal"><header class="modalHead"><div><small>Linked formal tender</small><h2>Formal Proposal</h2></div><button class="iconBtn" data-action="close-overlay" aria-label="Close proposal">×</button></header><div class="proposalModalBody">${editor}<section class="proposalPreviewPane"><div class="proposalPreviewToolbar"><span>Live print preview</span><span>${esc(proposalReference())}</span></div><div class="proposalPreview">${proposalDocumentMarkup()}</div></section></div><footer class="modalFoot"><span class="proposalPdfHint">Uses the real Most Wanted logo and opens the system print dialog. Choose Save as PDF.</span><button class="ghostBtn" data-action="proposal-refresh">Refresh preview</button><button class="primaryBtn" data-action="proposal-pdf" data-testid="proposal-export-pdf">Export PDF</button></footer></section></div>`;
}

function updateProposalPreview() {
  const preview = document.querySelector(".proposalPreview");
  if (preview) preview.innerHTML = proposalDocumentMarkup();
}

function exportProposalPdf() {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return toast("Allow pop-ups to export the proposal as a PDF.");
  buildLaunchPlan();
  safeFlushPersistence();
  printWindow.opener = null;
  let printed = false;
  const printWhenReady = () => {
    if (printed || printWindow.closed) return;
    printed = true;
    const images = [...(printWindow.document.images || [])];
    Promise.all(images.map(image => image.decode ? image.decode().catch(() => undefined) : Promise.resolve()))
      .finally(() => setTimeout(() => {
        if (!printWindow.closed) { printWindow.focus?.(); printWindow.print?.(); }
      }, 120));
  };
  printWindow.addEventListener("load", printWhenReady, { once: true });
  printWindow.document.open();
  printWindow.document.write(proposalPrintDocument());
  printWindow.document.close();
  setTimeout(printWhenReady, 900);
  track("proposal_exported", { reference: proposalReference(), systems: selectedServices().map(service => service.id), effectiveFirstYear: priceSummary().effectiveFirstYear });
  toast("Your print-ready proposal is open. Choose Save as PDF to export it.");
}

function takeawayPrintDocument() {
  buildLaunchPlan();
  const business = state.prospect.business || "Your Business";
  const contact = state.prospect.name || "Business Owner";
  const services = selectedServices();
  const price = priceSummary();
  const expiry = state.regenRoom?.expiresAt
    ? new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", timeZone: "America/New_York", timeZoneName: "short" }).format(new Date(state.regenRoom.expiresAt))
    : `${regenRoomDurationLabel()} after the Most Wanted Room window begins · EDT`;
  const serviceRows = services.length ? services.map(service => `<article><span>${esc(service.icon)}</span><div><b>${esc(service.name)}${service.quantity > 1 ? ` · Qty ${service.quantity}` : ""}</b><small>Ready within ${esc(serviceTimeToLive(service))}</small></div></article>`).join("") : `<p class="empty">No services have been added to the offer yet.</p>`;
  const agreement = String(state.checkoutLinks.agreement || "").trim();
  const payment = String(state.checkoutLinks.payment || "").trim();
  const phone = REGEN_CONTACT_PHONE;
  const email = REGEN_CONTACT_EMAIL;
  const supportContacts = [email, phone].filter(Boolean);
  const supportSentence = supportContacts.length
    ? `For same-day payment help, contact ${supportContacts.map(esc).join(" or ")}.`
    : "For same-day payment help, contact Most Wanted.";
  const legalNotice = "Most Wanted · DBA of Kailan Industries FZCO (UAE) · Sales contractually underwritten by Regen Digital (Delaware)";
  return `<!doctype html><html><head><meta charset="utf-8"><title>Most Wanted Take Away · ${esc(business)}</title><style>
    @page{size:Letter portrait;margin:.58in .62in}
    .takeawayPrint,*{box-sizing:border-box}
    html,body{background:#fff;color:#111214;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    body{margin:0;font-family:Arial,Helvetica,sans-serif;font-size:10.5pt;line-height:1.42}
    .takeawayPrint{width:100%}
    .docHead{display:flex;align-items:center;justify-content:space-between;gap:24px;padding-bottom:14px;border-bottom:2px solid #111214}
    .docHead img{display:block;width:175px;height:34px;object-fit:contain;object-position:left center}
    .docHead span{color:#111214;font-weight:900;letter-spacing:1.4px;text-transform:uppercase}
    .hero{padding:24px 0 18px}.hero small{color:#111214;font-weight:900;letter-spacing:1.2px}.hero h1{margin:5px 0 7px;color:#111214;font-size:34px;line-height:1.04}.hero p{margin:0;color:#303238;font-size:12px;font-weight:600}
    .offerGrid{display:grid;grid-template-columns:1.15fr .85fr;gap:13px;margin:0 0 16px}
    .offerMain,.offerExpiry{padding:17px;border:2px solid #111214;border-radius:13px;background:#fff;color:#111214}
    .offerMain small,.offerExpiry small{color:#303238;font-weight:900;letter-spacing:.8px}
    .offerMain strong{display:block;margin:5px 0;color:#111214;font-size:39px;font-weight:900;line-height:1}
    .offerMain p,.offerExpiry p{margin:5px 0 0;color:#34373c;font-weight:600}
    .offerExpiry strong{display:block;margin:8px 0 4px;color:#111214;font-size:19px;font-weight:900}
    .numbers{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:17px}.numbers div{padding:11px;border:1px solid #8f949b;border-radius:10px;background:#fff}.numbers span{display:block;color:#303238;font-size:8px;font-weight:900;letter-spacing:.5px;text-transform:uppercase}.numbers b{display:block;margin-top:4px;color:#111214;font-size:18px}.numbers em{display:block;margin-top:2px;color:#3f4349;font-size:8px;font-style:normal;font-weight:700}
    .section{margin-top:16px}.section h2{margin:0 0 9px;padding-bottom:6px;border-bottom:1px solid #8f949b;color:#111214;font-size:17px}.scope{display:grid;grid-template-columns:1fr 1fr;gap:7px}.scope article{display:grid;grid-template-columns:30px minmax(0,1fr);align-items:center;gap:8px;padding:9px;border:1px solid #a8acb2;border-radius:9px;break-inside:avoid}.scope article>span{display:grid;width:28px;height:28px;place-items:center;border-radius:7px;background:#e3e4e6}.scope b{display:block;color:#111214}.scope small{display:block;margin-top:2px;color:#3f4349}.empty{padding:12px;border:1px dashed #8f949b;border-radius:9px;color:#303238;font-weight:600}
    .next{display:grid;grid-template-columns:1fr 1fr;gap:10px}.next a,.next div{display:block;padding:12px;border:1px solid #111214;border-radius:9px;background:#111214;color:#fff;font-weight:800;text-decoration:none}.next div{background:#fff;color:#111214}.fine{margin-top:14px;padding:11px;border-left:3px solid #111214;background:#f0f0ef;color:#303238;font-weight:600}.docFoot{display:flex;justify-content:space-between;gap:15px;margin-top:18px;padding-top:9px;border-top:1px solid #8f949b;color:#303238;font-size:8.5px;font-weight:600}
    @media print{a{color:inherit;text-decoration:none}.offerGrid,.numbers,.scope article,.next,.fine{break-inside:avoid;page-break-inside:avoid}}
  </style></head><body><main class="takeawayPrint"><header class="docHead"><img src="${esc(proposalLogoSrc())}" alt="Most Wanted"><span>Take Away</span></header><section class="hero"><small>MOST WANTED OFFER SUMMARY</small><h1>Prepared for ${esc(business)}</h1><p>${esc(contact)} · ${esc(proposalDate())} · ${esc(proposalReference())}</p></section><section class="offerGrid"><div class="offerMain"><small>AGREED INVESTMENT</small><strong>${money(price.standardSetup)}</strong><p>The agreed one-time setup price for the digital infrastructure listed below.</p></div><div class="offerExpiry"><small>OFFER WINDOW · EASTERN TIME</small><strong>${esc(expiry)}</strong><p>The agreed proposal and completion links remain available until the window closes.</p></div></section><section class="numbers"><div><span>One-time setup</span><b>${money(price.standardSetup)}</b></div><div><span>Monthly</span><b>${money(price.monthly)}</b></div></section><section class="section"><h2>What is included</h2><div class="scope">${serviceRows}</div></section><section class="section"><h2>Complete the offer</h2><div class="next">${agreement ? `<a href="${esc(agreement)}">Open signing link</a>` : `<div>Signing link will be provided</div>`}${payment ? `<a href="${esc(payment)}">Open payment link</a>` : `<div>Payment link will be provided</div>`}</div></section><p class="fine">Ready within the timeframes given once Most Wanted receives the required details and access. ${supportSentence}</p><footer class="docFoot"><span>${esc(legalNotice)}</span><span>${esc(business)}</span></footer></main></body></html>`;
}

function exportTakeawayPdf() {
  const printWindow = window.open("", "_blank");
  if (!printWindow) return toast("Allow pop-ups to export the Takeout PDF.");
  safeFlushPersistence();
  printWindow.opener = null;
  let printed = false;
  const printWhenReady = () => {
    if (printed || printWindow.closed) return;
    printed = true;
    const images = [...(printWindow.document.images || [])];
    Promise.all(images.map(image => image.decode ? image.decode().catch(() => undefined) : Promise.resolve()))
      .finally(() => setTimeout(() => {
        if (!printWindow.closed) { printWindow.focus?.(); printWindow.print?.(); }
      }, 120));
  };
  printWindow.addEventListener("load", printWhenReady, { once: true });
  printWindow.document.open();
  printWindow.document.write(takeawayPrintDocument());
  printWindow.document.close();
  setTimeout(printWhenReady, 900);
  track("takeaway_pdf_exported", { systems: selectedServices().map(service => service.id), standardSetup: priceSummary().standardSetup });
  toast("Your print-ready Takeout PDF is open. Choose Save as PDF to export it.");
}

function takeawayMenuModal() {
  const windowLabel = regenRoomWindowLabel();
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal takeawayMenuModal" data-testid="takeaway-menu"><header class="modalHead"><div><small>CLIENT DOCUMENTS + FOLLOW-UP</small><h2>Offer Tools</h2><p>Prepare the client document, email or text from the same saved figures.</p></div><button class="iconBtn" data-action="close-overlay" aria-label="Close Offer Tools">×</button></header><div class="modalBody takeawayMenuChoices"><button type="button" class="takeawayMenuChoice" data-action="open-formal-proposal"><i>📑</i><span><small>EDITABLE FORMAL DOCUMENT</small><b>Proposal</b><p>Build and tailor the complete formal proposal, then export it as a PDF.</p></span><em>Open →</em></button><button type="button" class="takeawayMenuChoice featured" data-action="export-takeaway-pdf" data-testid="takeout-pdf"><i>📄</i><span><small>QUICK CLIENT SUMMARY</small><b>Takeout PDF</b><p>Export the regular offer summary with scope, agreed price and Most Wanted Room window.</p></span><em>Export →</em></button><button type="button" class="takeawayMenuChoice communication" data-action="open-follow-up-email" data-testid="follow-up-email-open"><i>✉️</i><span><small>PRE-WRITTEN ${esc(windowLabel.toUpperCase())} MESSAGE</small><b>Email</b><p>Includes the Most Wanted Room, decision window and current commercial figures.</p></span><em>Prepare →</em></button><button type="button" class="takeawayMenuChoice communication" data-action="open-follow-up-text" data-testid="follow-up-text-open"><i>💬</i><span><small>SHORT MOST WANTED ROOM REMINDER</small><b>Text</b><p>Prepare the linked ${esc(windowLabel)} SMS with the same commercial figures.</p></span><em>Prepare →</em></button></div><footer class="modalFoot"><button class="ghostBtn" data-action="close-overlay">Close</button></footer></section></div>`;
}

function questionCategories() {
  const categories = Array.isArray(state.questions?.categories) ? state.questions.categories : [];
  return categories.filter(category => category && category.id);
}

function questionsModal() {
  const categories = questionCategories();
  const active = categories.find(category => category.id === state.questions.activeCategory) || categories[0];
  if (active && state.questions.activeCategory !== active.id) state.questions.activeCategory = active.id;
  const items = (active?.items || []).filter(item => String(item?.question || "").trim() || String(item?.answer || "").trim());
  return `<div class="modalBackdrop questionsModalBackdrop" data-overlay-dismiss><section class="modal questionsModal" data-testid="questions-modal" aria-labelledby="questions-title">
    <header class="questionsModalHead">
      <div><span class="questionsEyebrow">Most Wanted answers</span><h2 id="questions-title">Questions, answered clearly.</h2><p>Choose a topic, then open any question. Nothing vague and nothing hidden.</p></div>
      <button class="iconBtn" data-action="close-overlay" aria-label="Close questions">×</button>
    </header>
    <div class="questionsExperience">
      <nav class="questionsTabs" aria-label="Question topics">${categories.map(category => `<button type="button" class="${category.id === active?.id ? "on" : ""}" data-action="questions-tab" data-id="${esc(category.id)}" aria-pressed="${category.id === active?.id}"><span>${esc(category.emoji || "💬")}</span><b>${esc(category.name || "Questions")}</b></button>`).join("")}</nav>
      <section class="questionsPanel" data-testid="questions-panel">
        ${active ? `<header class="questionsPanelHead"><span class="questionsPanelIcon">${esc(active.emoji || "💬")}</span><div><small>${esc(active.name || "Questions")}</small><h3>${esc(active.description || "Clear answers to the questions that matter.")}</h3></div><span class="questionsCount">${items.length} ${items.length === 1 ? "answer" : "answers"}</span></header>` : ""}
        <div class="questionsList">${items.length ? items.map((item, index) => `<details class="questionItem" data-testid="question-item-${index}"><summary><span class="questionEmoji">${esc(item.emoji || "💬")}</span><span class="questionText">${esc(item.question || "Question")}</span><span class="questionToggle" aria-hidden="true">+</span></summary><div class="questionAnswer"><span aria-hidden="true"></span><p>${esc(item.answer || "Answer coming soon.")}</p></div></details>`).join("") : `<div class="questionsEmpty"><span>💬</span><b>No questions have been added to this topic yet.</b><p>Add as many as you need in Admin, then they will appear here automatically.</p></div>`}</div>
      </section>
    </div>
    <footer class="questionsModalFoot"><span>Need something else? Ask Kailan - Owner directly during the session.</span><button class="primaryBtn" data-action="close-overlay">Back to the experience</button></footer>
  </section></div>`;
}

function adminQuestionsMarkup() {
  const categories = questionCategories();
  return `<section class="faqAdmin" data-testid="faq-admin">
    <header class="faqAdminIntro"><div><h3>Questions and answers</h3><p>Create unlimited topic tabs and unlimited expandable questions. Changes appear instantly in the full-screen Questions experience.</p></div><button class="primaryBtn" data-action="faq-add-category">Add topic tab</button></header>
    <div class="faqAdminCategories">${categories.map((category, categoryIndex) => `<details class="faqAdminCategory" open data-faq-category="${categoryIndex}">
      <summary><span>${esc(category.emoji || "💬")}</span><b>${esc(category.name || `Topic ${categoryIndex + 1}`)}</b><small>${(category.items || []).length} ${(category.items || []).length === 1 ? "question" : "questions"}</small></summary>
      <div class="faqAdminCategoryBody">
        <div class="faqAdminCategoryFields">${field(`questions.categories.${categoryIndex}.emoji`, "Tab emoji", "text", { placeholder: "💬" })}${field(`questions.categories.${categoryIndex}.name`, "Tab name", "text", { placeholder: "Services" })}${field(`questions.categories.${categoryIndex}.description`, "Tab introduction", "textarea", { full: true, placeholder: "What this section helps the customer understand" })}</div>
        <div class="faqAdminQuestionList">${(category.items || []).map((item, itemIndex) => `<article class="faqAdminQuestion" data-testid="faq-admin-question-${categoryIndex}-${itemIndex}">
          <span class="faqAdminNumber">${String(itemIndex + 1).padStart(2, "0")}</span>
          <div class="faqAdminQuestionFields">${field(`questions.categories.${categoryIndex}.items.${itemIndex}.emoji`, "Emoji", "text", { placeholder: "💬" })}${field(`questions.categories.${categoryIndex}.items.${itemIndex}.question`, "Question", "text", { placeholder: "What will the customer ask?" })}${field(`questions.categories.${categoryIndex}.items.${itemIndex}.answer`, "Answer", "textarea", { full: true, placeholder: "Give a clear, useful answer" })}</div>
          <button class="dangerBtn" data-action="faq-remove-question" data-category-index="${categoryIndex}" data-item-index="${itemIndex}" aria-label="Remove question ${itemIndex + 1}">Remove</button>
        </article>`).join("") || `<div class="faqAdminEmpty">No questions in this tab yet.</div>`}</div>
        <div class="faqAdminCategoryActions"><button class="ghostBtn" data-action="faq-add-question" data-category-index="${categoryIndex}">Add question</button><button class="dangerBtn" data-action="faq-remove-category" data-category-index="${categoryIndex}" ${categories.length === 1 ? "disabled" : ""}>Remove topic tab</button></div>
      </div>
    </details>`).join("")}</div>
  </section>`;
}

function serviceComparisonModal() {
  const available = Object.keys(SERVICE_COMPARISONS);
  const activeId = available.includes(state.activeTabs.serviceCompare) ? state.activeTabs.serviceCompare : "seo";
  const comparison = SERVICE_COMPARISONS[activeId];
  const service = state.serviceConfig[activeId] || SERVICES[activeId];
  const tabs = available.map(id => {
    const item = state.serviceConfig[id] || SERVICES[id];
    const tabLabel = SERVICE_COMPARISONS[id]?.title || item.name;
    return `<button class="serviceCompareTab ${id === activeId ? "on" : ""}" data-action="service-compare-select" data-id="${id}" aria-pressed="${id === activeId}"><i>${item.icon}</i><span>${esc(tabLabel)}</span></button>`;
  }).join("");
  const cards = comparison.levels.map(level => `<article class="serviceCompareCard ${level.className}">
    <header><span>${level.number}</span><i>${level.icon}</i><div><small>${esc(level.label)}</small><h3>${esc(level.provider)}</h3></div></header>
    <div class="serviceCompareFactor"><strong>${esc(level.factor)}</strong><span>${esc(level.factorLabel)}</span></div>
    <p>${esc(level.headline)}</p>
    <ul>${level.bullets.map(point => `<li>${esc(point)}</li>`).join("")}</ul>
    <b>${esc(level.outcome)}</b>
  </article>`).join("");
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal serviceCompareModal" data-testid="service-comparison-modal" data-service="${activeId}">
    <header class="modalHead"><div><small>Compare MW Vs. Others</small><h2>${service.icon} ${esc(comparison.title)}</h2><p>${esc(comparison.lead)}</p></div><button class="iconBtn" data-action="close-overlay" aria-label="Close comparison">×</button></header>
    <div class="modalBody"><nav class="serviceCompareTabs" aria-label="Choose a service to compare">${tabs}</nav><section class="serviceCompareGrid" aria-live="polite">${cards}</section><p class="serviceCompareDisclaimer">A realistic operating-model comparison, not a promise about every provider. Exact scope varies. No traffic, lead or revenue result is guaranteed.</p></div>
    <footer class="modalFoot"><span>Choose any of the seven services above.</span><button class="ghostBtn" data-action="close-overlay">Done</button></footer>
  </section></div>`;
}

function updateServiceComparisonModal() {
  const root = document.getElementById("overlayRoot");
  const current = root.querySelector(".serviceCompareModal");
  if (!current) return renderOverlay();

  const template = document.createElement("template");
  template.innerHTML = serviceComparisonModal().trim();
  const next = template.content.querySelector(".serviceCompareModal");
  if (!next) return renderOverlay();

  current.dataset.service = next.dataset.service;
  const nextHead = next.querySelector(".modalHead>div");
  const currentHead = current.querySelector(".modalHead>div");
  const nextGrid = next.querySelector(".serviceCompareGrid");
  const currentGrid = current.querySelector(".serviceCompareGrid");

  if (currentHead && nextHead) currentHead.replaceChildren(...Array.from(nextHead.childNodes, node => node.cloneNode(true)));

  current.querySelectorAll(".serviceCompareTab").forEach(tab => {
    const selected = tab.dataset.id === next.dataset.service;
    tab.classList.toggle("on", selected);
    tab.setAttribute("aria-pressed", String(selected));
  });

  if (currentGrid && nextGrid) {
    currentGrid.replaceChildren(...Array.from(nextGrid.childNodes, node => node.cloneNode(true)));
  }

  enforceReadableLightSurfaces(current);
}

function embeddableDemoUrl(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    const parsed = new URL(raw, location.href);
    return ["http:", "https:"].includes(parsed.protocol) ? parsed.href : "";
  } catch {
    return "";
  }
}

function websiteDemoModal() {
  const url = embeddableDemoUrl(activeDemoOverlay?.url);
  const title = String(activeDemoOverlay?.title || state.prospect.business || "Website demo").trim();
  if (!url) return simpleModal("Website Demo", `<div class="emptyState"><i>🖥️</i><b>Website preview unavailable</b><p>Add a valid website URL in Client Details.</p></div>`);
  return `<div class="modalBackdrop websiteDemoBackdrop"><section class="modal websiteDemoModal websiteDemoImmersive" data-testid="website-demo-modal" aria-label="Full-screen website demo">
    <div class="websiteDemoModalBody"><iframe src="${esc(url)}" title="${esc(title)}" loading="eager" allow="autoplay; clipboard-read; clipboard-write; fullscreen"></iframe></div>
    <button class="websiteDemoClose" data-action="close-overlay" aria-label="Close full-screen website demo">← Close Full Screen</button>
  </section></div>`;
}

function modalMarkup(kind) {
  if (kind === "setup") return setupModal();
  if (kind === "admin") return adminModal();
  if (kind === "questions") return questionsModal();
  if (kind === "service-compare") return serviceComparisonModal();
  if (kind === "website-demo") return websiteDemoModal();
  if (kind === "opening-pain-points") {
    const points = ["Poor communication", "Slow delivery", "Fragmented providers", "Limited ownership", "Technical complexity", "Weak support", "Hidden or repeated costs", "Generic execution", "Being left to figure systems out alone"];
    return simpleModal("The Agency Problems We Built Most Wanted To Remove", `<section class="openingPainPointsModal" data-testid="opening-pain-points"><p>These are the common frustrations Most Wanted was designed to solve, not a list of excuses you have to accept.</p><div>${points.map((point, index) => `<article><span>${String(index + 1).padStart(2, "0")}</span><b>${esc(point)}</b></article>`).join("")}</div></section>`);
  }
  if (kind === "payment") {
    const price = priceSummary();
    return simpleModal("Payment Options", `<div class="paymentSummary"><span>${price.timing === "after" ? "Standard setup price" : "Paid-today setup price"}</span><b>${money(price.effectiveSetup)}</b><small>${price.timing === "after" ? "No paid-today saving is applied after this call." : `${money(price.saving)} saved today at ${price.discount}%.`}</small></div><div class="threeGrid">${state.paymentOptions.map(option => `<button class="choice ${state.pricing.paymentOption === option.toLowerCase() ? "on" : ""}" data-action="payment-option" data-value="${option.toLowerCase()}"><i>$</i><span>${option}</span></button>`).join("")}</div>${field("pricing.deposit", "Amount paid today", "number", { min: 0, currency: true })}`);
  }
  if (kind === "outcome") return simpleModal("Record Call Outcome", `<div class="formGrid">${field("outcome.type", "Final outcome", "select", { items: ["", "Same-call payment", "Same-call deposit", `${regenRoomWindowLabel()} Most Wanted Room window`, "Closed later", "Lost"] })}${field("outcome.cashCollected", "Amount paid today", "number", { min: 0, currency: true })}${field("outcome.contractValue", "Contract value", "number", { min: 0, currency: true })}${field("outcome.followupDate", "Follow-up date", "datetime-local")}${field("outcome.lossReason", "Loss reason", "textarea", { full: true })}</div>`, `<button class="primaryBtn" data-action="save-outcome">Save Outcome</button>`);
  if (kind === "takeout") return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal takeoutModal" data-testid="call-notes-takeout"><header class="modalHead"><div><h2>Call Notes</h2><p>Keep the private conversation notes separate from the client-facing Take-Away PDF.</p></div><button class="iconBtn" data-action="close-overlay">×</button></header><div class="modalBody shareTakeoutBody"><section class="takeoutNotesPanel"><header><b>Private call notes</b><span>Capture the prospect, offer and outcome notes here.</span></header><div class="formGrid three">${field("takeoutNotes.prospect", "Prospect notes", "textarea", { rows: 4 })}${field("takeoutNotes.offer", "Offer notes", "textarea", { rows: 4 })}${field("takeoutNotes.outcome", "Outcome notes", "textarea", { rows: 4 })}</div></section><section class="takeoutSummaryPanel"><header><b>Copy-ready call notes</b><span>This is private text for your own records. The formal offer is exported separately as a PDF.</span></header><textarea readonly data-testid="takeout-summary">${esc(callNotesSummary())}</textarea></section></div><footer class="modalFoot"><button class="ghostBtn" data-action="close-overlay">Close</button><button class="ghostBtn" data-action="copy-takeout">Copy Call Notes</button><button class="primaryBtn" data-action="download-takeout" data-testid="download-takeout">Download Call Notes (.txt)</button></footer></section></div>`;
  if (kind === "launch-cart") return launchCartModal();
  if (kind === "line-item-pricing") return lineItemPricingModal();
  if (kind === "package-builder") return packageBuilderModal();
  if (kind === "discovery-details") return discoveryDetailsModal();
  if (kind === "leak-details") return leakDetailsModal();
  if (kind === "service-timing") return serviceTimingModal();
  if (kind === "launch-tasks") return launchTasksModal();
  if (kind === "checkout-saved-plan") return checkoutSavedPlanModal();
  if (kind === "website-changes") return websiteChangesModal();
  if (kind === "takeaway-menu") return takeawayMenuModal();
  if (kind === "follow-up-email") return followUpMessageModal("email");
  if (kind === "follow-up-text") return followUpMessageModal("text");
  if (kind === "proposal") return proposalModal();
  if (kind === "all-systems") return simpleModal("Explore All Most Wanted Systems", `<div class="pillarGrid">${Object.entries(PILLARS).map(([pillarId, pillar]) => `<section class="pillar"><header class="pillarHead"><i>${pillar.icon}</i><div><b>${pillar.name}</b></div></header><div class="moduleList">${Object.values(state.serviceConfig).filter(service => service.pillar === pillarId).map(service => moduleCard(service)).join("")}</div></section>`).join("")}</div>`);
  return "";
}

function simpleModal(title, body, foot = "") {
  return `<div class="modalBackdrop" data-overlay-dismiss><section class="modal"><header class="modalHead"><h2>${title}</h2><button class="iconBtn" data-action="close-overlay">×</button></header><div class="modalBody">${body}</div><footer class="modalFoot"><button class="ghostBtn" data-action="close-overlay">Close</button>${foot}</footer></section></div>`;
}

function setupModal() {
  const tabs = [["prospect", "Prospect"], ["prices", "Service Prices"], ["economics", "Economics"], ["infrastructure", "Infrastructure"], ["decision", "Decision + Path"], ["launch", "Launch Start"], ["records", "Saved Prospects"]];
  let body = "";
  if (state.setupTab === "prospect") body = `<div class="formGrid three">${field("prospect.business", "Business name")}${field("prospect.name", "Prospect name")}${field("prospect.demoUrl", "Custom website URL", "url")}</div>`;
  if (state.setupTab === "prices") {
    const services = Object.values(state.serviceConfig);
    const configured = services.filter(service => Number(service.setup) > 0 || Number(service.monthly) > 0).length;
    body = `<section class="clientServicePricing" data-testid="client-service-pricing"><header class="clientServicePricingHead"><div><small>STANDARD SERVICE PRICES</small><h3>Price every service once</h3><p>These prices carry into every new prospect. They change only when you edit them here or press Clear Prices.</p></div><div><span><b>${configured}</b> of ${services.length} priced</span><button class="dangerBtn" data-action="clear-service-prices" data-testid="clear-service-prices">Clear Prices</button></div></header><div class="clientServicePricingGrid">${services.map(service => `<article class="clientServicePriceCard" data-testid="client-service-price-${service.id}"><header><i>${service.icon}</i><div><b>${esc(service.name)}</b><small>${esc(PILLARS[service.pillar]?.name || "Most Wanted service")}</small></div></header><div class="clientServicePriceFields"><label><span>One-time setup</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" inputmode="decimal" value="${esc(service.setup)}" data-bind="serviceConfig.${service.id}.setup" data-client-service-price="setup" data-service-id="${service.id}" aria-label="One-time setup price for ${esc(service.name)}"></span></label><label><span>Monthly</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" inputmode="decimal" value="${esc(service.monthly)}" data-bind="serviceConfig.${service.id}.monthly" data-client-service-price="monthly" data-service-id="${service.id}" aria-label="Monthly price for ${esc(service.name)}"></span></label></div></article>`).join("")}</div></section>`;
  }
  if (state.setupTab === "economics") body = `<div class="formGrid three">${field("prospect.averageJobRevenue", "Average completed-job revenue", "number", { min: 0, currency: true })}${field("prospect.desiredJobsMonthly", "Additional jobs wanted each month", "number", { min: 0 })}${field("prospect.grossProfitPerJob", "Gross profit / contribution per job", "number", { min: 0, currency: true })}${field("prospect.monthlyRevenue", "Approximate monthly revenue", "number", { min: 0, currency: true })}${field("prospect.monthlyOpportunities", "Monthly calls / forms / enquiries", "number", { min: 0 })}${field("prospect.missedPercent", "Missed / unanswered %", "number", { min: 0 })}${field("prospect.averageResponseTime", "Average response time (minutes)", "number", { min: 0 })}${field("prospect.monthlyEstimates", "Monthly estimates / appointments", "number", { min: 0 })}${field("prospect.closeRate", "Current close rate %", "number", { min: 0 })}${field("prospect.capacityJobs", "Capacity for additional jobs", "number", { min: 0 })}</div>`;
  if (state.setupTab === "infrastructure") body = `<div class="formGrid three">${field("prospect.reviewCount", "Review count", "number", { min: 0 })}${field("prospect.reviewRating", "Review rating", "number", { min: 0, step: .1 })}${field("prospect.provider", "Current provider")}${field("prospect.localVisibility", "Local visibility", "select", { items: ["", "Invisible", "Poor", "Adequate", "Strong", "Unknown"] })}${field("prospect.websitePerformance", "Website performance", "select", { items: ["", "No website", "Poor", "Adequate", "Strong", "Unknown"] })}${field("prospect.followupProcess", "Follow-up process", "select", { items: ["", "None", "Manual and inconsistent", "Manual and consistent", "Automated", "Unknown"] })}</div>`;
  if (state.setupTab === "decision") body = `<div class="formGrid setupDecisionGrid">${field("prospect.growthGoal", "Growth goal", "textarea", { rows: 2 })}${field("prospect.primaryProblem", "Primary problem", "textarea", { rows: 2 })}${field("prospect.whyGoalMatters", "Why it matters", "textarea", { rows: 2 })}${field("prospect.whyNow", "Why now", "textarea", { rows: 2 })}${field("prospect.decisionMaker", "Decision-maker status", "select", { items: ["", "Sole decision-maker", "Joint decision-maker", "Recommender only", "Unknown"] })}${field("prospect.approvers", "Other required approvers")}${field("prospect.budgetTiming", "Budget / timing notes", "textarea", { rows: 2 })}${field("path", "Presenter path", "select", { items: [{ value: "standard", label: "Standard" }, { value: "ready", label: "Ready to buy" }, { value: "clarity", label: "Needs clarity" }, { value: "proof", label: "Needs proof" }, { value: "low", label: "Low urgency" }, { value: "price", label: "Price concern" }, { value: "provider", label: "Existing-provider objection" }] })}</div>`;
  if (state.setupTab === "launch") body = `<section class="launchStartSetup" data-testid="launch-start-setup"><div class="sceneLead">Set these before the call when they are already known, or complete them with the customer at launch. They stay attached to the saved Launch Plan.</div><div class="launchStartQuestion" data-testid="launch-timing-setup-question"><span class="launchQuestionNumber">01</span><div><h3>Preferred launch timing</h3>${launchTimingChoicesMarkup("setup")}</div></div><div class="launchStartQuestion" data-testid="launch-domain-setup-question"><span class="launchQuestionNumber">02</span><div>${field("launchStart.domain", "Domain to use", "text", { full: true, testid: "launch-domain-setup", placeholder: "example.com or I need help choosing" })}</div></div><div class="launchStartQuestion launchStartContact" data-testid="launch-contact-setup-question"><span class="launchQuestionNumber">03</span><div class="formGrid">${field("launchStart.contactPhone", "Best phone number", "tel", { testid: "launch-phone-setup", placeholder: "+1 555 000 0000" })}${field("launchStart.contactEmails", "Contact email address(es)", "textarea", { testid: "launch-emails-setup", placeholder: "owner@example.com" })}</div></div></section>`;
  if (state.setupTab === "records") {
    const records = JSON.parse(localStorage.getItem(INDEX_KEY) || "[]");
    body = records.length ? records.map(item => `<article class="claimRow"><b>${esc(item.business || item.name || "Unnamed prospect")}</b><span>${new Date(item.updatedAt).toLocaleDateString()}</span><button class="ghostBtn" data-action="load-prospect" data-id="${item.id}">Open</button></article>`).join("") : empty("◇", "No saved prospects", "Start entering prospect information and it will be saved automatically.");
  }
  return `<div class="modalBackdrop"><section class="modal setupModal" data-setup-tab="${esc(state.setupTab)}"><header class="modalHead"><h2>Presenter Prospect Setup</h2><button class="iconBtn" data-action="close-overlay">×</button></header><div class="modalBody"><div class="setupTabs">${tabs.map(([id, label]) => `<button class="${state.setupTab === id ? "on" : ""}" data-action="setup-tab" data-id="${id}">${label}</button>`).join("")}</div>${body}</div><footer class="modalFoot"><button class="dangerBtn" data-action="new-prospect">New prospect</button><button class="ghostBtn" data-action="close-overlay">Close</button><button class="primaryBtn" data-action="apply-setup">Save + Build Recommendation</button></footer></section></div>`;
}

function adminModal() {
  const tabs = [["services", "System + Pricing"], ["packages", "Packages"], ["testimonials", "Client Stories"], ["demos", "Website + Demos"], ["payments", "Investment + Links"], ["guarantee", "Delivery Guarantee"], ["language", "Language"]];
  if (!tabs.some(([id]) => id === state.adminTab)) state.adminTab = "services";
  let body = "";
  if (state.adminTab === "services") body = `<div class="adminContextBar"><small>ONE CONNECTED SYSTEM + INVESTMENT</small><b>These services, prices and ready times feed the system builder, investment screen and proposal.</b></div><div class="adminService adminServiceTimingHead"><b>Service</b><b>Group</b><b>Setup</b><b>Monthly</b><b>Ready time</b><b>Work stage</b></div>${Object.values(state.serviceConfig).map(service => `<div class="adminService adminServiceTiming" data-testid="admin-service-${service.id}"><b>${service.icon} ${esc(service.name)}</b><select data-bind="serviceConfig.${service.id}.pillar">${Object.entries(PILLARS).map(([id, pillar]) => `<option value="${id}" ${service.pillar === id ? "selected" : ""}>${pillar.name}</option>`).join("")}</select><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" data-bind="serviceConfig.${service.id}.setup" value="${esc(service.setup)}"></span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="number" min="0" data-bind="serviceConfig.${service.id}.monthly" value="${esc(service.monthly)}"></span><input data-bind="serviceConfig.${service.id}.window" data-testid="admin-service-ttl-${service.id}" value="${esc(serviceTimeToLive(service))}" aria-label="Ready time for ${esc(service.name)}"><span class="adminServicePhase" data-testid="admin-service-phase-${service.id}" data-derived-from="serviceConfig.${service.id}.window">${esc(LAUNCH_PHASES[serviceLaunchGroup(service)]?.label || LAUNCH_PHASES.ongoing.label)}</span><div style="grid-column:1/-1;display:grid;grid-template-columns:repeat(3,1fr);gap:8px"><input data-bind="serviceConfig.${service.id}.problem" value="${esc(service.problem)}" placeholder="Problem this solves"><input data-bind="serviceConfig.${service.id}.deliverable" value="${esc(service.deliverable)}" placeholder="What the customer gets"><input data-bind="serviceConfig.${service.id}.customer" value="${esc(service.customer)}" placeholder="What we need from the customer"></div></div>`).join("")}`;
  if (state.adminTab === "packages") body = `<section class="packageAdmin" data-testid="package-admin"><header><div><small>PACKAGE TEMPLATES</small><h3>Edit the packages available in Build Package</h3><p>Only packages saved here appear in the package builder. Service details stay off the sales screen so you can explain the package verbally.</p></div><button class="primaryBtn" data-action="add-package-template">Add Package</button></header><div class="packageAdminList">${(state.packageConfig || []).map((item, index) => `<article class="packageAdminRow" data-package-id="${esc(item.id)}"><i>${item.id === "complete-digital-infrastructure" ? "🏗️" : item.id === "digital-market-mastery" ? "🚀" : "📦"}</i><label><span>Package name</span><input type="text" data-bind="packageConfig.${index}.name" value="${esc(item.name)}"></label><label><span>Default setup</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="text" inputmode="decimal" autocomplete="off" data-bind="packageConfig.${index}.setup" data-package-template-price value="${esc(item.setup)}" aria-label="Default setup price for ${esc(item.name)}"></span></label><label><span>Default monthly</span><span class="currencyControl"><span class="currencyPrefix" aria-hidden="true">$</span><input type="text" inputmode="decimal" autocomplete="off" data-bind="packageConfig.${index}.monthly" data-package-template-price value="${esc(item.monthly)}" aria-label="Default monthly price for ${esc(item.name)}"></span></label><label><span>Package scope</span><select data-bind="packageConfig.${index}.allServices"><option value="false" ${item.allServices ? "" : "selected"}>Use services chosen today</option><option value="true" ${item.allServices ? "selected" : ""}>All 7 Most Wanted services</option></select></label><button class="dangerBtn" data-action="remove-package-template" data-index="${index}" aria-label="Remove ${esc(item.name)}">Remove</button></article>`).join("") || empty("＋", "No packages configured", "Add a package to make it available in Build Package.")}</div></section>`;
  if (state.adminTab === "testimonials") body = `<section class="testimonialAdmin" data-testid="testimonial-admin"><header class="lightSurface"><div><small>CLIENT VIDEO TESTIMONIALS</small><h3>Choose the client stories shown in the deck</h3><p>Add approved YouTube, Google Drive, Vimeo or direct video links. The first three enabled videos appear as 9:16 proof cards.</p></div><button class="primaryBtn" data-action="add-testimonial">Add Testimonial</button></header><div class="testimonialAdminList">${(state.testimonialsConfig || []).map((item, index) => `<article class="testimonialAdminRow lightSurface"><i>🎥</i><div class="testimonialAdminFields"><label><span>Client name</span><input data-bind="testimonialsConfig.${index}.clientName" value="${esc(item.clientName)}"></label><label><span>Business name</span><input data-bind="testimonialsConfig.${index}.businessName" value="${esc(item.businessName)}"></label><label><span>Role, optional</span><input data-bind="testimonialsConfig.${index}.role" value="${esc(item.role)}"></label><label><span>Star rating</span><input type="number" min="1" max="5" step="0.1" data-bind="testimonialsConfig.${index}.rating" value="${esc(item.rating || 5)}"></label><label class="full"><span>Video URL</span><input type="url" data-bind="testimonialsConfig.${index}.videoUrl" value="${esc(item.videoUrl)}" placeholder="YouTube, Google Drive, Vimeo or direct video URL"></label><label class="full"><span>Return / result shown beside the bar</span><input data-bind="testimonialsConfig.${index}.resultLabel" value="${esc(item.resultLabel)}" placeholder="Example: 50% growth within 3 months"></label><label class="full"><span>Short quote, optional</span><input data-bind="testimonialsConfig.${index}.quote" value="${esc(item.quote)}" placeholder="One concise sentence from the client"></label></div><label class="testimonialEnabled"><input type="checkbox" data-bind="testimonialsConfig.${index}.enabled" ${item.enabled ? "checked" : ""}><span>Show in deck</span></label><button class="dangerBtn" data-action="remove-testimonial" data-index="${index}" aria-label="Remove testimonial">Remove</button></article>`).join("") || empty("🎥", "No testimonials added", "Add an approved client video to populate the testimonial slide.")}</div></section>`;
  if (state.adminTab === "demos") body = `<div class="adminContextBar"><small>SEE IT BEFORE YOU DECIDE</small><b>Only links entered here or in Client Details appear on the live demo slide.</b></div><div class="formGrid">${Object.values(state.demosConfig).map(demo => field(`demos.${demo.id}.url`, demo.name, "text", { full: true, placeholder: "Website, video, app or live demo URL" })).join("")}</div>`;
  if (state.adminTab === "payments") {
    body = `<div class="adminContextBar"><small>INVESTMENT + OFFER TOOLS</small><b>The deck applies a fixed 20% on-call saving. These options, links and Most Wanted Room details feed the live presentation.</b></div><div class="formGrid">${field("paymentOptions.0", "Payment option one")}${field("paymentOptions.1", "Payment option two")}${field("paymentOptions.2", "Payment option three")}${field("checkoutLinks.agreement", "Agreement URL", "text", { full: true })}${field("checkoutLinks.payment", "Secure payment URL", "text", { full: true })}${field("checkoutLinks.onboarding", "Onboarding portal URL", "text", { full: true })}</div><section class="regenRoomAdmin"><header><div><small>${esc(regenRoomWindowLabel().toUpperCase())} MOST WANTED ROOM</small><h3>Consultation-room access</h3><p>The deletion window and private link remain available for every new prospect until you change them.</p></div></header><div class="regenRoomAdminGrid">${field("regenRoom.windowHours", "Site deletion window (hours)", "number", { min: 1, max: 720, step: 1, placeholder: "72" })}${field("regenRoom.url", "Most Wanted Room / Zoom URL", "url", { full: true, placeholder: "https://zoom.us/j/..." })}</div></section>`;
  }
  if (state.adminTab === "guarantee") body = `<section data-testid="pledge-admin"><div class="adminContextBar"><small>DELIVERY GUARANTEE</small><b>Every field below appears directly on the Delivery Guarantee slide.</b></div><div class="formGrid">${field("guarantee.trigger", "When the guarantee applies", "textarea", { full: true })}${field("guarantee.buyerCredit", "Most Wanted performance credit", "number", { min: 0, currency: true })}${field("guarantee.mealQuantity", "Meals funded", "number", { min: 0 })}${field("guarantee.charityName", "Charity partner")}</div></section>`;
  if (state.adminTab === "language") body = `<section class="languageSettings" data-testid="language-settings"><div class="adminContextBar"><small>PRESENTATION LANGUAGE</small><b>Switch the complete client-facing deck without changing saved prospect information.</b></div><div class="languageSwatches" role="radiogroup" aria-label="Presentation language"><button type="button" class="languageSwatch ${state.language?.locale !== "es" ? "on" : ""}" data-action="language-select" data-value="en" role="radio" aria-checked="${state.language?.locale !== "es"}"><i>🇺🇸</i><span><b>English</b><small>Original presentation</small></span><em>${state.language?.locale !== "es" ? "✓" : ""}</em></button><button type="button" class="languageSwatch ${state.language?.locale === "es" ? "on" : ""}" data-action="language-select" data-value="es" role="radio" aria-checked="${state.language?.locale === "es"}"><i>🌎</i><span><b>Español</b><small>Latinoamérica · SEO Regular</small></span><em>${state.language?.locale === "es" ? "✓" : ""}</em></button></div><p class="languageSettingsNote">Spanish uses concise Latin American wording and automatically fits the fixed 16:9 presentation stage.</p></section>`;
  return `<div class="modalBackdrop"><section class="modal adminModal" data-admin-tab="${esc(state.adminTab)}"><header class="modalHead specialistSettingsHead"><div><small>PRESENTATION CONFIGURATION</small><h2>Specialist Settings Manager</h2><p>Only controls used by the current pitch deck are shown here.</p></div><button class="iconBtn" data-action="close-overlay">×</button></header><div class="adminTabs adminTabsBar">${tabs.map(([id, label]) => `<button class="${state.adminTab === id ? "on" : ""}" data-action="admin-tab" data-id="${id}">${label}</button>`).join("")}</div><div class="modalBody">${body}</div><footer class="modalFoot"><button class="ghostBtn" data-action="close-overlay">Close</button><button class="primaryBtn" data-action="save-admin">Save Presentation Settings</button></footer></section></div>`;
}

function drawerMarkup() {
  const options = [
    ["Product Certainty", "Custom website, AI live tests, CRM flow, review flow and technical explanation.", "proof"],
    ["Company Certainty", "Company facts, support, ownership, launch plan, guarantee and process.", "company"],
    ["Timing + Urgency", "Why-now answer, known cost of delay, capacity and launch timeline.", "lowUrgency"],
    ["Money", "Break-even calculator, scope adjustment, payment options and first-year cost.", "calculator"]
  ];
  return `<div class="drawerBackdrop" data-overlay-dismiss><aside class="drawer"><header class="modalHead"><h2>Certainty Navigation</h2><button class="iconBtn" data-action="close-overlay">×</button></header><div class="modalBody"><div class="objectionGrid">${options.map(([name, copy, scene]) => `<article class="objectionCard"><h3>${name}</h3><p>${copy}</p><button class="ghostBtn" data-action="drawer-go" data-scene="${scene}">Open relevant module</button></article>`).join("")}</div></div></aside></div>`;
}

function go(scene) {
  if (!RENDERERS[scene]) return false;
  if (scene === "leaks" && !state.heard.confirmed) { toast("Confirm What I Heard before opening the diagnosis."); state.currentScene = "heard"; render({ shell: true }); return false; }
  state.currentScene = scene;
  if (scene === "lowUrgency") state.lowUrgencyEnabled = true;
  track("navigation", { to: scene });
  render({ shell: true });
  return true;
}

function applyCheckpointSelection(key, value, source = "checkpoint") {
  const allowed = CHECKPOINT_OPTIONS[key];
  if (!allowed?.includes(value)) return false;

  state.checkpoints[key] = value;
  if (key === "understanding") {
    state.heard.confirmed = value === "Yes";
    if (state.heard.confirmed) evaluateRecommendations();
  }
  if (key === "product" && value === "Add detail") state.showAllDemos = true;
  track("checkpoint", { key, answer: value, source });
  save();

  let route = "";
  if (key === "recommendation" && value === "Needs an edit") route = "recommendation";
  if ((key === "product" || key === "decision") && value === "Needs an edit") route = "recommendation";
  if (route === "support" && !hasSupportCommitments()) route = "company";

  if (route) go(route);
  else render();

  flushPersistence();
  if (API_ENABLED && state.mode === "presenter") {
    void syncServerSession().finally(() => scheduleApiSync());
  }

  if (!route && value !== "Yes" && value !== "Nothing") focusCheckpointEditor(key);
  if (!route && key === "certainty" && value === "Nothing") toast("Great, everything is clear. Continue when you’re ready.");
  return true;
}

function focusCheckpointEditor(key) {
  const selector = ({
    understanding: "[data-bind='heard.situation']",
    problem: state.leaks.primary ? `[data-leak-card="${state.leaks.primary}"]` : "[data-testid='urgency-score-grid']",
    recommendation: "[data-reason]",
    product: "[data-action='select-demo']",
    decision: "[data-testid='decision-summary']"
  })[key];
  if (!selector) return;
  requestAnimationFrame(() => {
    const element = document.querySelector(selector);
    revealElement(element);
    element?.focus();
  });
}

function next() {
  if (state.currentScene === "opening") return advanceOpening();
  const sequence = scenes();
  const index = sequence.indexOf(state.currentScene);
  if (state.currentScene === "heard" && !state.heard.confirmed) return toast("Confirm the summary before continuing.");
  if (state.currentScene === "price") {
    const price = priceSummary();
    if (price.standardSetup <= 0 && price.monthly <= 0) {
      revealElement(document.querySelector("[data-testid='price-editor']"));
      document.querySelector("[data-testid='price-setup-input']")?.focus();
      return toast("Enter the agreed setup or monthly price before continuing.");
    }
  }
  if (index < sequence.length - 1) go(sequence[index + 1]);
}

function prev() {
  if (state.currentScene === "opening") return reverseOpening();
  const sequence = scenes();
  const index = sequence.indexOf(state.currentScene);
  if (index > 0) go(sequence[index - 1]);
}

function beginCheckout() {
  const price = priceSummary();
  if (price.standardSetup <= 0 && price.monthly <= 0) {
    revealElement(document.querySelector("[data-testid='price-editor']"));
    document.querySelector("[data-testid='price-setup-input']")?.focus();
    toast("Enter the agreed setup or monthly price before opening checkout.");
    return false;
  }
  const selected = selectedServices();
  track("primary_cta", { selected: selected.map(service => service.id), timing: price.timing, discount: price.discount });
  state.outcome.type ||= state.pricing.dollarCommitmentSelected ? "Same-call deposit" : "Launch selected";
  state.outcome.servicesSold = selected.map(service => service.id);
  state.outcome.serviceQuantities = Object.fromEntries(selected.map(service => [service.id, service.quantity]));
  state.outcome.contractValue = price.effectiveFirstYear;
  state.outcome.guaranteeVersion = guaranteeFullyConfigured() ? state.guarantee.versionDate : "";
  buildLaunchPlan();
  state.outcome.serviceTimings = selectedServiceTimings();
  state.outcome.launchWindow = overallLaunchTiming();
  state.launchPlan.guaranteeVersion = state.outcome.guaranteeVersion;
  save();
  go("checkout");
  return true;
}

function beginBuildAccess(source = "close-decision") {
  state.outcome.type = `No launch, grant ${regenRoomWindowLabel()} Most Wanted Room access`;
  ensureBuildAccessStarted(source);
  save();
  go("regenRoom");
}

function advanceOpening() {
  const step = Math.max(0, Math.min(10, Number(state.opening?.step) || 0));
  if (step < 10) {
    state.opening.step = step + 1;
    track("opening_step_viewed", { step: state.opening.step });
    save();
    return render();
  }
  openingToShell = true;
  state.currentScene = "intro";
  track("opening_completed", { business: state.prospect.business || "" });
  save();
  render({ shell: true });
  requestAnimationFrame(() => document.getElementById("regenStage")?.classList.add("shellRevealActive"));
  setTimeout(() => { openingToShell = false; }, 760);
}

function reverseOpening() {
  const step = Math.max(0, Math.min(10, Number(state.opening?.step) || 0));
  if (step <= 0) return;
  state.opening.step = step - 1;
  track("opening_step_reversed", { step: state.opening.step });
  save();
  render();
}

function prefersReducedMotion() {
  return Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches);
}

function revealElement(element) {
  if (!element) return;
  element.scrollIntoView({ behavior: prefersReducedMotion() ? "auto" : "smooth", block: "center" });
}

function toast(message) {
  const element = document.getElementById("toast");
  const text = typeof message === "string" ? message.trim() : String(message || "").trim();
  // Never expose raw upstream/API payloads to a presenter or prospect.
  if (!text || (/^\{[\s\S]*"detail"\s*:\s*"Bad Request"[\s\S]*\}$/i.test(text))) return;
  element.textContent = text;
  element.classList.add("show");
  setTimeout(() => element.classList.remove("show"), 2200);
}

function scaleStage() {
  const stage = document.getElementById("regenStage");
  if (!stage) return;
  const scale = Math.min(innerWidth / 1600, innerHeight / 900);
  stage.style.transform = `scale(${scale})`;
  stage.style.transformOrigin = "top left";
  stage.style.position = "absolute";
  stage.style.left = `${Math.max(0, (innerWidth - 1600 * scale) / 2)}px`;
  stage.style.top = `${Math.max(0, (innerHeight - 900 * scale) / 2)}px`;
  if (state.currentScene === "infrastructure") requestInfrastructureConnections();
}

function presentationFullscreenContext() {
  let ownerDocument = document;
  try {
    if (window.top && window.top !== window && window.top.document?.documentElement) ownerDocument = window.top.document;
  } catch { /* Cross-origin embeds safely use the current document. */ }
  return { ownerDocument, target: ownerDocument.documentElement };
}

function presentationFullscreenElement(ownerDocument) {
  return ownerDocument.fullscreenElement || ownerDocument.webkitFullscreenElement || null;
}

function preloadNextDemo() {
  const relevant = Object.values(state.demosConfig).filter(demo => !demo.service || state.services[demo.service]?.selected);
  const next = relevant.find(demo => !state.demos[demo.id]?.viewed);
  const url = next ? resolvedDemoUrl(next) : "";
  if (url && !document.querySelector(`link[rel=preload][href="${CSS.escape(url)}"]`)) {
    const link = document.createElement("link"); link.rel = "preload"; link.as = "document"; link.href = url; document.head.append(link);
  }
}

function bindEvents() {
  document.addEventListener("wheel", event => {
    const scroller = event.target.closest?.(".proposalEditorScroll,.proposalPreview");
    if (!scroller) return;
    const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? scroller.clientHeight : 1;
    const delta = (event.deltaY || event.deltaX) * unit;
    if (!delta) return;
    event.preventDefault();
    event.stopPropagation();
    scroller.scrollTop += delta;
  }, { capture: true, passive: false });

  document.addEventListener("click", async event => {
    if (event.target.matches("[data-overlay-dismiss]")) {
      const closingModal = modal;
      modal = null;
      drawer = null;
      if (closingModal === "website-demo") activeDemoOverlay = null;
      if (closingModal === "package-builder") packageDraft = null;
      if (["follow-up-email", "follow-up-text"].includes(closingModal)) followUpTemplateEditing = "";
      if (["launch-cart", "line-item-pricing", "website-changes", "discovery-details", "admin"].includes(closingModal)) render();
      else renderOverlay();
      return;
    }
    const target = event.target.closest("[data-action]");
    if (!target) return;
    const action = target.dataset.action;
    if (action === "opening-pain-points") { modal = "opening-pain-points"; return renderOverlay(); }
    if (action === "opening-next") return advanceOpening();
    if (action === "next") return next();
    if (action === "prev") return prev();
    if (action === "closer-check") {
      const id = target.dataset.id;
      if (!Object.prototype.hasOwnProperty.call(state.closerChecklist || {}, id)) return;
      state.closerChecklist[id] = !state.closerChecklist[id];
      save();
      return render();
    }
    if (action === "setup" || action === "client-details") {
      // Client Details is an editor, never a new-session action. Flush first so
      // a fast click after entering data cannot reopen an older browser snapshot.
      return openPresenterUtility("setup");
    }
    if (action === "admin") { modal = "admin"; return renderOverlay(); }
    if (action === "open-testimonial-settings") {
      state.adminTab = "testimonials";
      modal = "admin";
      return renderOverlay();
    }
    if (action === "clear-current-pricing") {
      // Keep the reusable standard catalog intact, but explicitly override all
      // service prices to zero for this prospect. Without these overrides the
      // next recalculation restores the old catalog total after the reset.
      state.pricing.serviceOverrides = Object.fromEntries(
        Object.keys(state.serviceConfig || {}).map(id => [id, { setup: 0, monthly: 0 }])
      );
      Object.assign(state.pricing, {
        setup: 0,
        monthly: 0,
        catalogSetup: 0,
        catalogMonthly: 0,
        manualSetup: false,
        manualMonthly: false,
        deposit: 1
      });
      state.activePackage = { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
      state.combinedOffer = { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false };
      packageDraft = null;
      combinedOfferDraft = null;
      recalculatePrice();
      buildLaunchPlan();
      flushPersistence();
      scheduleApiSync();
      render();
      requestAnimationFrame(() => {
        const clearPricingButton = document.querySelector('[data-action="clear-current-pricing"]');
        if (!clearPricingButton) return;
        clearPricingButton.classList.remove("pricingClearedPulse");
        void clearPricingButton.offsetWidth;
        clearPricingButton.classList.add("pricingClearedPulse");
        clearPricingButton.addEventListener("animationend", () => {
          clearPricingButton.classList.remove("pricingClearedPulse");
        }, { once: true });
        setTimeout(() => clearPricingButton.classList.remove("pricingClearedPulse"), 1100);
      });
      return;
    }
    if (action === "takeaway-menu") return openPresenterUtility("takeaway-menu", { persist: false });
    if (action === "open-formal-proposal") return openPresenterUtility("proposal", { persist: false, rebuildPlan: true });
    if (action === "export-takeaway-pdf") return exportTakeawayPdf();
    if (action === "open-follow-up-email") return openPresenterUtility("follow-up-email");
    if (action === "open-follow-up-text") return openPresenterUtility("follow-up-text");
    if (action === "proposal") return openPresenterUtility("proposal", { persist: false, rebuildPlan: true });
    if (action === "service-compare-open") {
      state.activeTabs.serviceCompare = SERVICE_COMPARISONS[target.dataset.id] ? target.dataset.id : "seo";
      modal = "service-compare";
      save();
      return renderOverlay();
    }
    if (action === "service-compare-select") {
      if (!SERVICE_COMPARISONS[target.dataset.id]) return;
      state.activeTabs.serviceCompare = target.dataset.id;
      save();
      return updateServiceComparisonModal();
    }
    if (action === "objections") { modal = "questions"; drawer = null; return renderOverlay(); }
    if (action === "about") { modal = "about"; return renderOverlay(); }
    if (action === "close-overlay") {
      const closingModal = modal;
      modal = null;
      drawer = null;
      if (closingModal === "website-demo") activeDemoOverlay = null;
      if (closingModal === "package-builder") packageDraft = null;
      return ["launch-cart", "line-item-pricing", "website-changes", "discovery-details", "admin"].includes(closingModal) ? render() : renderOverlay();
    }
    if (action === "proposal-add-item") {
      state.proposal.manualItems ||= [];
      state.proposal.manualItems.push({ id: uid(), icon: "🧩", name: "Custom scope item", description: "", deliverable: "", window: "To be agreed", quantity: 1, setup: 0, monthly: 0 });
      save();
      return renderOverlay();
    }
    if (action === "proposal-remove-item") {
      const index = Number(target.dataset.index);
      state.proposal.manualItems = (state.proposal.manualItems || []).filter((_, itemIndex) => itemIndex !== index);
      save();
      return renderOverlay();
    }
    if (action === "proposal-refresh") { buildLaunchPlan(); save(); return renderOverlay(); }
    if (action === "proposal-pdf") return exportProposalPdf();
    if (action === "fullscreen") {
      try {
        const { ownerDocument, target: fullscreenTarget } = presentationFullscreenContext();
        if (presentationFullscreenElement(ownerDocument)) {
          const exitFullscreen = ownerDocument.exitFullscreen || ownerDocument.webkitExitFullscreen;
          if (typeof exitFullscreen !== "function") return toast("Full screen is not available in this browser.");
          await exitFullscreen.call(ownerDocument);
        } else {
          const requestFullscreen = fullscreenTarget.requestFullscreen || fullscreenTarget.webkitRequestFullscreen;
          if (typeof requestFullscreen !== "function") return toast("Full screen is not available in this browser.");
          await requestFullscreen.call(fullscreenTarget);
          if (!presentationFullscreenElement(ownerDocument)) toast("Full screen is not available in this browser.");
        }
      } catch { toast("Full screen is not available in this browser."); }
      return;
    }
    if (action === "choice") {
      const path = target.dataset.path, value = target.dataset.value, multi = target.dataset.multi === "true";
      if (multi) { const list = get(state, path, []); set(state, path, list.includes(value) ? list.filter(item => item !== value) : [...list, value]); }
      else set(state, path, value);
      save(); return render();
    }
    if (action === "flow-tab") {
      const group = target.dataset.group;
      const id = target.dataset.id;
      const allowed = {
        discovery: ["business", "problems", "outcome"],
        cost: ["impact", "symptoms", "cost"],
        agency: AGENCY_FAILURES.map(item => item.id),
        regen: REGEN_DIFFERENCES.map(item => item.id)
      };
      if (!allowed[group]?.includes(id)) return;
      state.activeTabs[group] = id;
      if (group === "discovery") state.discoveryStep = allowed.discovery.indexOf(id);
      save();
      return render();
    }
    if (action === "system-select-all") {
      const ids = Object.keys(state.services);
      const allSelected = ids.every(id => state.services[id].selected);
      if (allSelected) {
        const restore = new Set(systemSelectionBeforeComplete || []);
        ids.forEach(id => {
          state.services[id].selected = restore.has(id);
          state.services[id].quantity = restore.has(id) ? Math.max(1, serviceQuantity(id)) : 0;
          state.services[id].status = restore.has(id) ? "recommended" : "later";
          state.services[id].manual = true;
        });
        systemSelectionBeforeComplete = null;
      } else {
        systemSelectionBeforeComplete = ids.filter(id => state.services[id].selected);
        ids.forEach(id => {
          state.services[id].selected = true;
          state.services[id].quantity = Math.max(1, serviceQuantity(id));
          state.services[id].status = "recommended";
          state.services[id].manual = true;
        });
      }
      buildLaunchPlan(); recalculatePrice(); save();
      return render();
    }
    if (action === "decision-launch") return beginCheckout();
    if (action === "decision-48") return beginBuildAccess("decision-slide");
    if (action === "offer-takeaway" || action === "go-takeaway") return go("regenRoom");
    if (action === "regen-room-link-received") {
      state.regenRoom.linkReceived = !state.regenRoom.linkReceived;
      save();
      return render();
    }
    if (action === "regen-room-confirm") {
      state.regenRoom.attendanceConfirmed = !state.regenRoom.attendanceConfirmed;
      save();
      if (state.regenRoom.attendanceConfirmed) toast("Most Wanted Room attendance recorded.");
      return render();
    }
    if (action === "regen-room-gift") {
      state.regenRoom.giftCardChoice = target.dataset.value || "Amazon";
      save();
      return render();
    }
    if (action === "discovery-step") { state.discoveryStep = Number(target.dataset.index); return render(); }
    if (action === "discovery-details") {
      discoveryDetailsGroup = ["presence", "channels", "success"].includes(target.dataset.group) ? target.dataset.group : "presence";
      modal = "discovery-details";
      return renderOverlay();
    }
    if (action === "leak-details") { modal = "leak-details"; return renderOverlay(); }
    if (action === "service-timing") { modal = "service-timing"; return renderOverlay(); }
    if (action === "launch-tasks") {
      launchTasksGroup = target.dataset.group || "today";
      modal = "launch-tasks";
      return renderOverlay();
    }
    if (action === "checkout-saved-plan") { modal = "checkout-saved-plan"; return renderOverlay(); }
    if (action === "discovery-next") { state.discoveryStep = Math.min(DISCOVERY_GROUPS.length - 1, state.discoveryStep + 1); return render(); }
    if (action === "discovery-back") { state.discoveryStep = Math.max(0, state.discoveryStep - 1); return render(); }
    if (action === "finish-discovery") {
      state.analytics.discoveryCompletedAt ||= now(); inferHeard({ force: true }); evaluateRecommendations(); go("heard"); return;
    }
    if (action === "confirm-heard") return applyCheckpointSelection("understanding", "Yes", "what-i-heard-confirm");
    if (action === "heard-edit") return applyCheckpointSelection("understanding", "Add detail", "what-i-heard-edit");
    if (action === "checkpoint") return applyCheckpointSelection(target.dataset.key, target.dataset.value, "checkpoint-control");
    if (action === "primary-leak") {
      const id = target.dataset.id;
      const status = normalizeOpportunityState(state.leaks[id]?.state);
      if (status !== "yes" && status !== "maybe") return toast("Choose Yes or Maybe before marking this as the biggest problem.");
      state.leaks.primary = id;
      track("primary_leak_selected", { leak: id });
      save();
      return render();
    }
    if (action === "service-status") {
      const item = state.services[target.dataset.id]; item.status = target.dataset.status; item.selected = target.dataset.status === "recommended"; item.quantity = item.selected ? Math.max(1, serviceQuantity(target.dataset.id)) : 0; item.manual = true;
      track("service_changed", { id: target.dataset.id, status: item.status }); buildLaunchPlan(); recalculatePrice(); save(); return renderOverlayOrScene();
    }
    if (action === "plan-toggle-service") {
      const id = target.dataset.id;
      const item = state.services[id];
      if (!item) return;
      item.selected = !item.selected;
      item.quantity = item.selected ? Math.max(1, serviceQuantity(id)) : 0;
      if (item.selected) item.status = "recommended";
      item.manual = true;
      track("final_plan_service_toggled", { id, selected: item.selected });
      buildLaunchPlan(); recalculatePrice(); save(); return render();
    }
    if (action === "map-service-toggle") {
      const id = target.dataset.id;
      const item = state.services[id];
      if (!item) return;
      item.selected = !item.selected;
      item.quantity = item.selected ? Math.max(1, serviceQuantity(id)) : 0;
      item.status = item.selected ? "recommended" : "optional";
      item.manual = true;
      item.reason ||= item.selected ? "Included after reviewing the connected system together." : "Available as a useful add-on when the timing is right.";
      track("service_changed_from_map", { id, status: item.status });
      buildLaunchPlan(); recalculatePrice(); save(); return render();
    }
    if (action === "explore-all") { modal = "all-systems"; return renderOverlay(); }
    if (action === "launch-cart") { modal = "launch-cart"; return renderOverlay(); }
    if (action === "line-item-pricing") {
      recalculatePrice();
      combinedOfferDraft = state.combinedOffer?.applied
        ? deepClone(state.combinedOffer)
        : { name: "Combined Growth Offer", serviceIds: selectedServices().map(service => service.id), setup: state.pricing.catalogSetup, monthly: state.pricing.catalogMonthly, applied: false };
      modal = "line-item-pricing";
      return renderOverlay();
    }
    if (action === "build-package") {
      packageDraft = state.activePackage?.applied ? deepClone(state.activePackage) : { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
      modal = "package-builder";
      return renderOverlay();
    }
    if (action === "package-select") {
      const template = (state.packageConfig || []).find(item => item.id === target.dataset.id);
      if (!template) return;
      const configured = packageTemplatePrice(template);
      packageDraft = {
        id: template.id,
        name: template.name,
        quantity: 1,
        setup: configured.setup,
        monthly: configured.monthly,
        applied: false
      };
      return renderOverlay();
    }
    if (action === "package-apply") {
      if (!packageDraft?.id || !String(packageDraft.name || "").trim()) return toast("Choose and name a package first.");
      const template = (state.packageConfig || []).find(item => item.id === packageDraft.id);
      const quantity = Math.max(1, Math.min(99, Math.floor(Number(packageDraft.quantity) || 1)));
      if (template?.allServices) {
        Object.keys(state.services).forEach(id => {
          state.services[id].selected = true;
          state.services[id].quantity = quantity;
          state.services[id].status = "recommended";
          state.services[id].manual = true;
        });
      }
      state.activePackage = {
        id: packageDraft.id,
        name: String(packageDraft.name).trim(),
        quantity,
        setup: Math.max(0, Number(packageDraft.setup) || 0),
        monthly: Math.max(0, Number(packageDraft.monthly) || 0),
        applied: true
      };
      state.combinedOffer = { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false };
      state.pricing.setup = state.activePackage.setup * quantity;
      state.pricing.monthly = state.activePackage.monthly * quantity;
      state.pricing.manualSetup = true;
      state.pricing.manualMonthly = true;
      buildLaunchPlan();
      packageDraft = null;
      modal = null;
      save();
      render();
      return toast(`${state.activePackage.name} added to today’s plan.`);
    }
    if (action === "combined-offer-toggle-service") {
      if (!combinedOfferDraft) return;
      const id = target.dataset.id;
      const ids = new Set(combinedOfferDraft.serviceIds || []);
      ids.has(id) ? ids.delete(id) : ids.add(id);
      combinedOfferDraft.serviceIds = [...ids];
      return renderOverlay();
    }
    if (action === "combined-offer-apply") {
      const ids = (combinedOfferDraft?.serviceIds || []).filter(id => state.services[id]?.selected);
      if (ids.length < 2) return toast("Choose at least two services for a combined offer.");
      const name = String(combinedOfferDraft?.name || "").trim();
      if (!name) return toast("Add a name for the combined offer.");
      state.combinedOffer = {
        name,
        serviceIds: ids,
        setup: Math.max(0, Number(combinedOfferDraft.setup) || 0),
        monthly: Math.max(0, Number(combinedOfferDraft.monthly) || 0),
        applied: true
      };
      state.activePackage = { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
      state.pricing.manualSetup = true;
      state.pricing.manualMonthly = true;
      recalculatePrice();
      buildLaunchPlan();
      save();
      renderOverlay();
      return toast(`${name} applied as one combined price.`);
    }
    if (action === "combined-offer-remove") {
      state.combinedOffer = { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false };
      state.pricing.manualSetup = false;
      state.pricing.manualMonthly = false;
      recalculatePrice();
      combinedOfferDraft = { name: "Combined Growth Offer", serviceIds: selectedServices().map(service => service.id), setup: state.pricing.catalogSetup, monthly: state.pricing.catalogMonthly, applied: false };
      save();
      renderOverlay();
      return toast("Combined offer removed. Line-item pricing restored.");
    }
    if (action === "use-line-item-prices" || action === "use-catalog-price") {
      state.activePackage = { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
      state.combinedOffer = { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false };
      state.pricing.manualSetup = false;
      state.pricing.manualMonthly = false;
      recalculatePrice();
      track("line_item_pricing_applied", { setup: state.pricing.catalogSetup, monthly: state.pricing.catalogMonthly });
      save();
      return modal === "line-item-pricing" ? renderOverlay() : render();
    }
    if (action === "cart-quantity-minus" || action === "cart-quantity-plus") {
      const id = target.dataset.id;
      const current = serviceQuantity(id);
      const nextQuantity = action === "cart-quantity-plus" ? current + 1 : Math.max(0, current - 1);
      if (setServiceQuantity(id, nextQuantity, action)) updateLaunchCartPreview();
      return;
    }
    if (action === "go-ecosystem") { modal = null; drawer = null; return go("recommendation"); }
    if (action === "go-infrastructure") { modal = null; drawer = null; return go("infrastructure"); }
    if (action === "select-demo") { state.selectedDemo = target.dataset.id; state.demos[target.dataset.id].viewed = true; track("demo_viewed", { id: target.dataset.id }); save(); return render(); }
    if (action === "toggle-all-demos") { state.showAllDemos = !state.showAllDemos; return render(); }
    if (action === "open-demo") {
      const demo = state.demosConfig[state.selectedDemo];
      const url = target.dataset.url || resolvedDemoUrl(demo || state.selectedDemo);
      if (!embeddableDemoUrl(url)) return toast("Add a valid verified demo URL in Admin first.");
      activeDemoOverlay = { url, title: target.dataset.title || demo?.name || state.prospect.business || "Website demo" };
      modal = "website-demo";
      track("demo_opened_in_presentation", { id: state.selectedDemo || "website" });
      return renderOverlay();
    }
    if (action === "website-launch-open") {
      const url = target.dataset.url || String(state.prospect.demoUrl || state.prospect.websiteUrl || state.prospect.previewImageUrl || "").trim();
      if (!embeddableDemoUrl(url)) return toast("Add a valid custom website or preview URL in Client Details first.");
      activeDemoOverlay = { url, title: target.dataset.title || state.prospect.business || "Website launch version" };
      modal = "website-demo";
      track("website_launch_opened_in_presentation");
      return renderOverlay();
    }
    if (action === "website-change-add") {
      const change = String(state.websiteLaunch.draftChange || "").trim();
      if (!change) return toast("Enter one requested website change first.");
      state.websiteLaunch.requestedChanges = [...(state.websiteLaunch.requestedChanges || []), change];
      state.websiteLaunch.draftChange = "";
      track("website_launch_change_added", { change, total: state.websiteLaunch.requestedChanges.length });
      save();
      return render();
    }
    if (action === "website-changes") { modal = "website-changes"; return renderOverlay(); }
    if (action === "website-change-remove") {
      const index = Number(target.dataset.index);
      if (!Number.isInteger(index) || index < 0) return;
      const removed = state.websiteLaunch.requestedChanges?.[index] || "";
      state.websiteLaunch.requestedChanges = (state.websiteLaunch.requestedChanges || []).filter((_, itemIndex) => itemIndex !== index);
      track("website_launch_change_removed", { change: removed, total: state.websiteLaunch.requestedChanges.length });
      save();
      return modal === "website-changes" ? renderOverlay() : render();
    }
    if (action === "scenario") { state.calculatorScenario = target.dataset.id; track("calculator_scenario", { scenario: target.dataset.id }); save(); return render(); }
    if (action === "launch" || action === "close-yes") return beginCheckout();
    if (action === "close-no") return beginBuildAccess("close-decision");
    if (action === "payment-options") { modal = "payment"; return renderOverlay(); }
    if (action === "payment-option") { state.pricing.paymentOption = target.dataset.value; save(); return renderOverlay(); }
    if (action === "launch-start-timing") {
      const timing = target.dataset.value;
      if (!LAUNCH_TIMING_OPTIONS.includes(timing)) return;
      state.launchStart.timing = timing;
      buildLaunchPlan();
      track("launch_timing_selected", { timing });
      save();
      return modal ? renderOverlay() : render();
    }
    if (action === "price-timing") {
      state.pricing.timing = target.dataset.value === "after" ? "after" : "today";
      if (state.pricing.timing === "after") {
        state.pricing.dollarCommitmentSelected = false;
        if (state.pricing.paymentOption === "$1 eligible launch commitment") state.pricing.paymentOption = "pay in full";
        if (Number(state.pricing.deposit) === 1) state.pricing.deposit = 0;
      }
      track("price_timing_selected", { timing: state.pricing.timing, discount: priceSummary().discount });
      save(); return render();
    }
    if (action === "toggle-dollar-eligibility") {
      state.pricing.dollarCommitmentEligible = !state.pricing.dollarCommitmentEligible;
      if (!state.pricing.dollarCommitmentEligible) state.pricing.dollarCommitmentSelected = false;
      track("dollar_commitment_eligibility", { eligible: state.pricing.dollarCommitmentEligible });
      save(); return render();
    }
    if (action === "select-dollar-commitment") {
      if (!state.pricing.dollarCommitmentEligible) return;
      state.pricing.dollarCommitmentSelected = !state.pricing.dollarCommitmentSelected;
      if (state.pricing.dollarCommitmentSelected) {
        state.pricing.deposit = 1;
        state.pricing.paymentOption = "$1 eligible launch commitment";
        state.outcome.cashCollected = 1;
      } else {
        state.pricing.deposit = 0;
        state.pricing.paymentOption = "pay in full";
        if (Number(state.outcome.cashCollected) === 1) state.outcome.cashCollected = 0;
      }
      track("dollar_commitment_selected", { selected: state.pricing.dollarCommitmentSelected });
      save(); return render();
    }
    if (action === "toggle-academy") {
      state.pricing.academyRevealed = !state.pricing.academyRevealed;
      track("growth_academy_revealed", { revealed: state.pricing.academyRevealed });
      save(); return render();
    }
    if (action === "takeout") {
      return openPresenterUtility("takeout");
    }
    if (action === "copy-takeout") {
      const field = document.querySelector("[data-testid='takeout-summary']");
      const copied = copyVisibleText(field) || await copyText(callNotesSummary());
      return toast(copied ? "Call notes copied." : "The call notes are selected. Press Copy to keep them.");
    }
    if (action === "download-takeout") {
      safeFlushPersistence();
      downloadText(callNotesFilename(), callNotesSummary());
      return toast("Call notes downloaded.");
    }
    if (action === "copy-follow-up-email" || action === "copy-follow-up-text") {
      const emailMode = action === "copy-follow-up-email";
      const field = document.querySelector(`[data-testid='follow-up-${emailMode ? "email" : "text"}-body']`);
      const copied = copyVisibleText(field) || await copyText(emailMode ? followUpEmailText() : followUpTextMessage());
      return toast(copied ? `${emailMode ? "Email" : "Text"} copied.` : `The ${emailMode ? "email" : "text"} is selected. Press Copy to keep it.`);
    }
    if (action === "edit-follow-up-template") {
      const type = target.dataset.type === "text" ? "text" : "email";
      state.followUpTemplates ||= { emailSubject: "", emailBody: "", textBody: "" };
      if (type === "email") {
        state.followUpTemplates.emailSubject ||= followUpEmailSubject();
        state.followUpTemplates.emailBody ||= followUpEmailText();
      } else {
        state.followUpTemplates.textBody ||= followUpTextMessage();
      }
      followUpTemplateEditing = type;
      save();
      return renderOverlay();
    }
    if (action === "save-follow-up-template") {
      followUpTemplateEditing = "";
      save();
      renderOverlay();
      return toast("Follow-up template saved for this prospect.");
    }
    if (action === "questions-tab") {
      if (questionCategories().some(category => category.id === target.dataset.id)) {
        state.questions.activeCategory = target.dataset.id;
        save();
      }
      return renderOverlay();
    }
    if (action === "setup-tab") { state.setupTab = target.dataset.id; return renderOverlay(); }
    if (action === "admin-tab") { state.adminTab = target.dataset.id; return renderOverlay(); }
    if (action === "language-select") {
      state.language ||= {};
      state.language.locale = target.dataset.value === "es" ? "es" : "en";
      save();
      return render();
    }
    if (action === "add-package-template") {
      state.packageConfig ||= [];
      const packageId = `package-${uid()}`;
      state.packageConfig.push({ id: packageId, name: `Package ${state.packageConfig.length + 1}`, setup: 0, monthly: 0, allServices: false });
      save();
      renderOverlay();
      requestAnimationFrame(() => {
        const row = [...document.querySelectorAll(".packageAdminRow")].find(item => item.dataset.packageId === packageId);
        if (!row) return;
        row.classList.add("isNew");
        row.scrollIntoView({ block: "nearest", behavior: "smooth" });
        const name = row.querySelector('input[data-bind$=".name"]');
        name?.focus({ preventScroll: true });
        name?.select();
      });
      return;
    }
    if (action === "remove-package-template") {
      const index = Number(target.dataset.index);
      const removed = state.packageConfig?.[index];
      state.packageConfig = (state.packageConfig || []).filter((_, itemIndex) => itemIndex !== index);
      if (removed?.id && state.activePackage?.id === removed.id) state.activePackage = { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
      save();
      return renderOverlay();
    }
    if (action === "add-testimonial") {
      state.testimonialsConfig ||= [];
      state.testimonialsConfig.push({ id: `testimonial-${uid()}`, clientName: "", businessName: "", role: "", quote: "", resultLabel: "", rating: 5, videoUrl: "", enabled: false });
      save();
      return renderOverlay();
    }
    if (action === "remove-testimonial") {
      const index = Number(target.dataset.index);
      state.testimonialsConfig = (state.testimonialsConfig || []).filter((_, itemIndex) => itemIndex !== index);
      save();
      return renderOverlay();
    }
    if (action === "faq-add-category") {
      const id = `faq-${uid()}`;
      state.questions.categories.push({ id, name: "New topic", emoji: "💬", description: "Add a short introduction for this topic.", items: [] });
      state.questions.activeCategory = id;
      save();
      return renderOverlay();
    }
    if (action === "faq-remove-category") {
      const index = Number(target.dataset.categoryIndex);
      if (state.questions.categories.length <= 1 || !state.questions.categories[index]) return;
      const removed = state.questions.categories[index].id;
      state.questions.categories.splice(index, 1);
      if (state.questions.activeCategory === removed) state.questions.activeCategory = state.questions.categories[0].id;
      save();
      return renderOverlay();
    }
    if (action === "faq-add-question") {
      const index = Number(target.dataset.categoryIndex);
      const category = state.questions.categories[index];
      if (!category) return;
      category.items ||= [];
      category.items.push({ id: `question-${uid()}`, emoji: "💬", question: "New question", answer: "Add the clear answer here." });
      save();
      return renderOverlay();
    }
    if (action === "faq-remove-question") {
      const categoryIndex = Number(target.dataset.categoryIndex);
      const itemIndex = Number(target.dataset.itemIndex);
      const category = state.questions.categories[categoryIndex];
      if (!category?.items?.[itemIndex]) return;
      category.items.splice(itemIndex, 1);
      save();
      return renderOverlay();
    }
    if (action === "opening-logo-reset") {
      state.opening.logo = "";
      save();
      return renderOverlay();
    }
    if (action === "regen-room-qr-reset") {
      state.regenRoom.qrImage = "";
      save();
      return renderOverlay();
    }
    if (action === "clear-service-prices") {
      Object.values(state.serviceConfig).forEach(service => {
        service.setup = 0;
        service.monthly = 0;
      });
      state.activePackage = { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
      state.combinedOffer = { name: "", serviceIds: [], setup: 0, monthly: 0, applied: false };
      Object.assign(state.pricing, {
        setup: 0,
        monthly: 0,
        catalogSetup: 0,
        catalogMonthly: 0,
        manualSetup: false,
        manualMonthly: false,
        serviceOverrides: {}
      });
      save();
      renderOverlay();
      return toast("All standard service prices cleared.");
    }
    if (action === "apply-setup") { if (state.path === "low") state.lowUrgencyEnabled = true; inferHeard({ force: true }); evaluateRecommendations(); buildLaunchPlan(); modal = null; save(); render({ shell: true }); return toast("Prospect saved and recommendation rebuilt."); }
    if (action === "save-admin") { recalculatePrice(); buildLaunchPlan(); modal = null; save(); render({ shell: true }); return toast("Admin configuration saved."); }
    if (action === "new-prospect") return startNewProspect();
    if (action === "load-prospect") { const saved = JSON.parse(localStorage.getItem(`${STORAGE_PREFIX}prospect:${target.dataset.id}`) || "null"); if (saved) { state = mergeState(defaultState(), migrateLegacySnapshot(saved)); modal = null; track("prospect_reopened"); flushPersistence(); render({ shell: true }); } return; }
    if (action === "add-claim") { state.claims.push({ text: "", verified: false, source: "", metricDefinition: "", lastVerified: "", sourceVisibility: "public", publicLink: "", privateLink: "", displayEnabled: false }); save(); return renderOverlay(); }
    if (action === "add-case-study") { state.caseStudies.push({ customerName: "", permissionStatus: "", industry: "", startingSituation: "", systemsInstalled: "", baselineEvidence: "", resultEvidence: "", metricDefinition: "", dateRange: "", sourceLinks: "", verifiedBy: "", displayEnabled: false }); save(); return renderOverlay(); }
    if (action === "drawer-go") { drawer = null; return go(target.dataset.scene); }
    if (action === "record-outcome") { modal = "outcome"; return renderOverlay(); }
    if (action === "save-outcome") {
      track("call_outcome", { ...state.outcome });
      modal = null;
      const noLaunch = /no launch|lost/i.test(state.outcome.type || "");
      if (noLaunch) return beginBuildAccess("record-call-outcome");
      save();
      return render({ shell: true });
    }
    if (action === "expiry-launch") {
      if (buildAccessExpired()) return render({ shell: true });
      const price = priceSummary();
      return go(price.standardSetup > 0 || price.monthly > 0 ? "checkout" : "price");
    }
    if (action.startsWith("checkout-")) {
      const type = action.replace("checkout-", "");
      track(action, { plan: selectedServices().map(service => service.id) });
      const url = state.checkoutLinks[type];
      if (url) window.open(url, "_blank", "noopener");
      else toast(`${type} action recorded. Add the secure URL in Admin.`);
      return;
    }
  });

  document.addEventListener("input", event => {
    const target = event.target;
    if (target.matches("[data-combined-offer-draft]")) {
      if (!combinedOfferDraft) return;
      const key = target.dataset.combinedOfferDraft;
      combinedOfferDraft[key] = target.type === "number" ? (target.value === "" ? 0 : Number(target.value)) : target.value;
      return;
    }
    if (target.matches("[data-package-draft]")) {
      if (!packageDraft) return;
      const key = target.dataset.packageDraft;
      packageDraft[key] = target.type === "number" ? (target.value === "" ? 0 : Number(target.value)) : target.value;
      updatePackageBuilderPreview();
      return;
    }
    if (target.matches("[data-package-template-price]")) {
      set(state, target.dataset.bind, currencyNumber(target.value));
      save();
      return;
    }
    if (target.matches("[data-bind]")) {
      const numeric = target.type === "number" || target.type === "range";
      const value = target.type === "checkbox" ? target.checked : numeric ? (target.value === "" ? "" : Number(target.value)) : coerce(target.value);
      set(state, target.dataset.bind, value);
      if (target.dataset.bind === "regenRoom.windowHours") {
        state.regenRoom.windowHours = normalizeRegenRoomWindowHours(value);
        syncRegenRoomExpiryToWindow();
        const proposalCopy = String(state.proposal?.introduction || "");
        if (proposalCopy === REGEN_PROPOSAL_SUMMARY || /The prepared work and offer remain reserved for \d+ hours while the Most Wanted Room is available/.test(proposalCopy)) {
          state.proposal.introduction = proposalCopy.replace(/reserved for \d+ hours while/, `reserved for ${regenRoomDurationLabel()} while`);
        }
      }
      if (["prospect.monthlyOpportunities", "prospect.averageJobRevenue"].includes(target.dataset.bind)) {
        const key = target.dataset.bind.split(".").at(-1);
        state.prospect.commercialSources ||= { monthlyOpportunities: "", averageJobRevenue: "" };
        if (state.currentScene === "discovery") state.prospect.commercialSources[key] = value === "" ? "" : "discovery";
        else if (state.currentScene === "cost" && state.prospect.commercialSources[key] !== "discovery") state.prospect.commercialSources[key] = value === "" ? "" : "cost";
      }
      if (target.dataset.bind.startsWith("heard.")) {
        state.heard.confirmed = false;
        state.checkpoints.understanding = "Add detail";
      }
      if (target.dataset.bind === "pricing.setup") state.pricing.manualSetup = true;
      if (target.dataset.bind === "pricing.monthly") state.pricing.manualMonthly = true;
      if (target.matches("[data-line-item-price]")) {
        state.activePackage = { id: "", name: "", quantity: 1, setup: 0, monthly: 0, applied: false };
        state.pricing.manualSetup = Boolean(state.combinedOffer?.applied);
        state.pricing.manualMonthly = Boolean(state.combinedOffer?.applied);
        recalculatePrice();
        updateLineItemPricingPreview();
      }
      if (target.matches("[data-client-service-price]")) {
        const serviceId = target.dataset.serviceId;
        const priceKey = target.dataset.clientServicePrice;
        if (serviceId && priceKey && state.pricing.serviceOverrides?.[serviceId]) {
          delete state.pricing.serviceOverrides[serviceId][priceKey];
          if (!Object.keys(state.pricing.serviceOverrides[serviceId]).length) delete state.pricing.serviceOverrides[serviceId];
        }
        state.pricing.manualSetup = false;
        state.pricing.manualMonthly = false;
        recalculatePrice();
      }
      if (target.matches("[data-plan-price]")) {
        state.pricing.manualSetup = false;
        state.pricing.manualMonthly = false;
        recalculatePrice();
        const total = priceSummary();
        document.querySelectorAll('[data-plan-total="setup"]').forEach(node => { node.textContent = money(total.standardSetup); });
        document.querySelectorAll('[data-plan-total="monthly"]').forEach(node => { node.textContent = money(total.monthly); });
      }
      if (target.dataset.bind.startsWith("launchStart.")) state.launchPlan.launchStart = deepClone(state.launchStart);
      if (/^serviceConfig\.[^.]+\.window$/.test(target.dataset.bind)) buildLaunchPlan();
      if (target.dataset.bind.startsWith("pricing.")) {
        updatePricingPreview();
      }
      if (["prospect.desiredJobsMonthly", "prospect.monthlyOpportunities", "prospect.missedPercent", "prospect.closeRate", "prospect.averageJobRevenue"].includes(target.dataset.bind)) updateCostPreview();
      if (["prospect.desiredJobsMonthly", "prospect.averageJobRevenue"].includes(target.dataset.bind)) {
        updateEconomicsGoalPreview();
        updateDiscoveryGoalPreview();
      }
      if (target.dataset.bind.startsWith("proposal.")) {
        updateProposalPreview();
      }
      if (target.dataset.bind.startsWith("takeoutNotes.")) {
        const takeout = document.querySelector("[data-testid='takeout-summary']");
        if (takeout) takeout.value = callNotesSummary();
      }
      if (state.language?.locale === "es") requestAnimationFrame(applyPresentationLanguage);
      save();
    }
    if (target.matches("[data-reason]")) { state.services[target.dataset.reason].reason = target.textContent.trim(); state.services[target.dataset.reason].manual = true; save(); }
  });

  document.addEventListener("change", event => {
    const target = event.target;
    if (target.matches("[data-opening-logo-upload]")) {
      const file = target.files?.[0];
      if (!file) return;
      if (!["image/svg+xml", "image/png", "image/webp"].includes(file.type)) return toast("Use an SVG, PNG or WebP logo.");
      if (file.size > 3 * 1024 * 1024) return toast("Keep the opening logo below 3 MB.");
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        state.opening.logo = String(reader.result || "");
        save();
        renderOverlay();
      }, { once: true });
      reader.readAsDataURL(file);
      return;
    }
    if (target.matches("[data-regen-room-qr-upload]")) {
      const file = target.files?.[0];
      if (!file) return;
      if (!["image/svg+xml", "image/png", "image/jpeg", "image/webp"].includes(file.type)) return toast("Use an SVG, PNG, JPG or WebP QR image.");
      if (file.size > 3 * 1024 * 1024) return toast("Keep the Most Wanted Room QR below 3 MB.");
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        state.regenRoom.qrImage = String(reader.result || "");
        save();
        renderOverlay();
      }, { once: true });
      reader.readAsDataURL(file);
      return;
    }
    if (target.matches("[data-cart-quantity]")) {
      const id = target.dataset.cartQuantity;
      if (setServiceQuantity(id, target.value, "launch-cart-input")) updateLaunchCartPreview();
      return;
    }
    if (target.matches("[data-leak-state]")) {
      const id = target.dataset.leakState;
      const status = normalizeOpportunityState(target.value);
      state.leaks[id].state = status;
      state.leaks[id].manual = true;
      if ((status === "no" || status === "unknown") && state.leaks.primary === id) state.leaks.primary = "";
      save();
      render();
    }
    if (target.matches("[data-bind]")) {
      if (target.dataset.bind === "path" && target.value === "low") state.lowUrgencyEnabled = true;
      if (target.dataset.bind.startsWith("launchStart.")) buildLaunchPlan();
      // Do not render here. A change event commonly fires while focus is moving
      // from a form control to Save/Continue. Replacing the DOM between
      // pointerdown and click prevents the intended button click from firing.
      // The input handler above has already updated state and the control
      // already displays its new value; explicit actions render the next view.
      save();
      if (state.currentScene === "calculator" && ["prospect.averageJobRevenue", "prospect.grossProfitPerJob", "prospect.customerLifetimeValue", "customScenarioJobs"].includes(target.dataset.bind)) return render();
    }
  });

  window.addEventListener("keydown", event => {
    const editing = event.target.matches("input,textarea,select,[contenteditable=true]");
    if (event.key === "Escape" && (modal || drawer)) {
      if (modal === "website-demo") activeDemoOverlay = null;
      modal = null;
      drawer = null;
      renderOverlay();
      return;
    }
    if (modal || drawer || event.repeat) return;
    if (event.key === "ArrowRight") { event.preventDefault(); next(); return; }
    if (event.key === "ArrowLeft") { event.preventDefault(); prev(); return; }
    if (editing) return;
    if (state.currentScene === "opening" && ["Enter", " "].includes(event.key)) {
      event.preventDefault();
      advanceOpening();
      return;
    }
  });
  window.addEventListener("message", event => {
    if (event.source !== window.parent || event.data?.type !== "regen-stage-key") return;
    if (modal || drawer) return;
    if (event.data.key === "ArrowRight") next();
    if (event.data.key === "ArrowLeft") prev();
  });
  window.addEventListener("resize", scaleStage);
  const fullscreenDocuments = new Set([document, presentationFullscreenContext().ownerDocument]);
  fullscreenDocuments.forEach(ownerDocument => {
    const refreshFullscreenLayout = () => { scaleStage(); requestInfrastructureConnections(); };
    ownerDocument.addEventListener("fullscreenchange", refreshFullscreenLayout);
    ownerDocument.addEventListener("webkitfullscreenchange", refreshFullscreenLayout);
  });
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") save(); });
}

async function copyText(value) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return true;
    }
  } catch { /* Use the compatible selection fallback below. */ }
  try {
    const textarea = document.createElement("textarea");
    textarea.value = value;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.append(textarea);
    textarea.select();
    const copied = document.execCommand("copy");
    textarea.remove();
    return copied;
  } catch { return false; }
}

function copyVisibleText(field) {
  if (!(field instanceof HTMLTextAreaElement || field instanceof HTMLInputElement)) return false;
  try {
    field.focus({ preventScroll: true });
    field.select();
    field.setSelectionRange(0, field.value.length);
    return document.execCommand("copy");
  } catch { return false; }
}

function renderOverlayOrScene() { if (modal || drawer) renderOverlay(); else render(); }
function callNotesFilename() {
  const business = String(state.prospect?.business || "prospect").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "prospect";
  return `regen-call-notes-${business}.txt`;
}
function downloadText(filename, value) {
  const blob = new Blob([value], { type: "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}
function downloadJson(filename, value) { const blob = new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }); const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1000); }

async function init() {
  await loadInitialState();
  sanitizeStoredServerSession();
  await loadPublicClaims();
  inferHeard();
  if (!Object.values(state.services).some(item => item.manual || item.selected)) evaluateRecommendations({ preserveManual: false });
  buildLaunchPlan();
  bindEvents();
  render({ shell: true });
  track("presentation_started", { variant: state.variant, mode: state.mode });
  save();
}

window.__REGEN_TEST__ = {
  version: APP_VERSION,
  getState: () => deepClone(state),
  setState: patch => { modal = null; drawer = null; state = mergeState(state, patch); render({ shell: true }); return deepClone(state); },
  reset: () => { modal = null; drawer = null; state = defaultState(); render({ shell: true }); return deepClone(state); },
  advanceOpening: () => { advanceOpening(); return deepClone(state); },
  reverseOpening: () => { reverseOpening(); return deepClone(state); },
  go,
  scenes,
  evaluateRecommendations,
  calculateLeaks,
  calculateBreakEven,
  priceSummary: () => deepClone(priceSummary()),
  migrateLegacySnapshot: snapshot => deepClone(migrateLegacySnapshot(snapshot)),
  buildLaunchPlan: () => { buildLaunchPlan(); return deepClone(state.launchPlan); },
  getSharePayload: () => deepClone(sharePayload()),
  qualifiedClaim,
  render: () => render({ shell: true }),
  exportSummary: () => {
    buildLaunchPlan();
    return {
      prospect: deepClone(state.prospect), heard: deepClone(state.heard), leaks: deepClone(state.leaks),
      recommended: selectedServices().map(service => ({ id: service.id, name: service.name, quantity: service.quantity, reason: state.services[service.id].reason, timeToLive: serviceTimeToLive(service), launchGroup: serviceLaunchGroup(service) })),
      serviceTimings: deepClone(selectedServiceTimings()), launchWindow: overallLaunchTiming(),
      launchPlan: deepClone(state.launchPlan), launchStart: deepClone(state.launchStart), breakEven: calculateBreakEven(), pricing: deepClone(state.pricing), package: deepClone(state.activePackage), combinedOffer: deepClone(state.combinedOffer), proposal: deepClone(state.proposal), outcome: deepClone(state.outcome)
    };
  }
};

function adaptiveDerived() {
  buildLaunchPlan();
  const recommended = selectedServices().map(service => ({
    id: service.id, name: service.name, status: state.services[service.id].status,
    reason: state.services[service.id].reason, customerRequirement: service.customer,
    quantity: service.quantity, setup: Number(service.setup || 0), monthly: Number(service.monthly || 0),
    setupTotal: Number(service.setup || 0) * service.quantity, monthlyTotal: Number(service.monthly || 0) * service.quantity,
    timeToLive: serviceTimeToLive(service), launchGroup: serviceLaunchGroup(service), launchPhase: LAUNCH_PHASES[serviceLaunchGroup(service)]?.label || LAUNCH_PHASES.ongoing.label
  }));
  const price = priceSummary();
  return {
    recommendations: deepClone(state.services),
    selectedServices: recommended,
    leakMap: calculateLeaks(),
    supportRequirements: recommended.map(service => ({ service: service.id, requirement: service.customerRequirement })),
    guaranteeScope: {
      enabled: guaranteeFullyConfigured(),
      includedServices: guaranteeFullyConfigured() ? recommended.map(service => service.id) : [],
      definition: state.guarantee.coreDefinition,
      remedy: `${money(state.guarantee.buyerCredit)} ${state.guarantee.buyerCreditLabel} plus ${number(state.guarantee.mealQuantity)} meals donated`,
      deadlineRule: state.guarantee.deadlineRule,
      trigger: state.guarantee.trigger
    },
    launchPlan: deepClone(state.launchPlan),
    launchStart: deepClone(state.launchStart),
    pricing: deepClone(state.pricing),
    package: deepClone(state.activePackage),
    combinedOffer: deepClone(state.combinedOffer),
    priceSummary: deepClone(price),
    breakEven: calculateBreakEven(),
    proposal: {
      template: deepClone(state.proposal),
      reference: proposalReference(),
      validThrough: proposalValidThrough(),
      business: state.prospect.business,
      systems: recommended.map(service => service.quantity > 1 ? `${service.name} (Qty ${service.quantity})` : service.name),
      serviceTimings: recommended.map(service => ({ id: service.id, name: service.name, quantity: service.quantity, timeToLive: service.timeToLive, launchGroup: service.launchGroup, launchPhase: service.launchPhase })),
      setupInvestment: Number(state.pricing.setup), monthlySupport: Number(state.pricing.monthly),
      standardFirstYearTotal: price.standardFirstYear,
      paidTodayDiscount: price.discount,
      paidTodaySaving: price.saving,
      firstYearTotal: price.effectiveFirstYear,
      launchWindow: earliestLaunch()
    }
  };
}

function flushPersistence() {
  state.updatedAt = now();
  localStorage.setItem(`${STORAGE_PREFIX}prospect:${state.id}`, JSON.stringify(state));
  localStorage.setItem(ACTIVE_KEY, state.id);
  const list = JSON.parse(localStorage.getItem(INDEX_KEY) || "[]");
  localStorage.setItem(INDEX_KEY, JSON.stringify([{ id: state.id, name: state.prospect.name, business: state.prospect.business, updatedAt: state.updatedAt }, ...list.filter(item => item.id !== state.id)].slice(0, 100)));
  return true;
}

window.__REGEN_ADAPTIVE_TEST__ = {
  getRegenRoomTimeZones(date) {
    return deepClone(regenRoomTimeZones(date ? new Date(date) : new Date()));
  },
  reset() {
    modal = null;
    drawer = null;
    state = defaultState();
    evaluateRecommendations({ preserveManual: false });
    render({ shell: true });
    flushPersistence();
    return deepClone(state);
  },
  seedSession(fixture = {}) {
    modal = null;
    drawer = null;
    state = mergeState(defaultState(), fixture);
    inferHeard();
    evaluateRecommendations({ preserveManual: true });
    buildLaunchPlan();
    recalculatePrice();
    render({ shell: true });
    flushPersistence();
    return deepClone(state);
  },
  getSession: () => deepClone(state),
  getDerived: () => deepClone(adaptiveDerived()),
  getSharePayload: () => deepClone(sharePayload()),
  setPresenterPath(path) {
    const aliases = { "ready-to-buy": "ready", "needs-clarity": "clarity", "needs-proof": "proof", "low-urgency": "low", "price-concern": "price", "existing-provider": "provider" };
    state.path = aliases[path] || path || "standard";
    state.lowUrgencyEnabled = state.path === "low";
    render({ shell: true });
    flushPersistence();
    return scenes();
  },
  setMode(mode) {
    state.mode = mode === "prospect" ? "prospect" : "presenter";
    render({ shell: true });
    flushPersistence();
    return state.mode;
  },
  navigate(sceneId) { return go(SCENE_ALIASES[sceneId] || sceneId); },
  recompute() {
    evaluateRecommendations({ preserveManual: true });
    buildLaunchPlan();
    recalculatePrice();
    render({ shell: true });
    return deepClone(adaptiveDerived());
  },
  flushPersistence,
  sceneAliases: deepClone(SCENE_ALIASES)
};

init().catch(error => {
  console.error("Most Wanted V2 failed to initialize", error);
  document.getElementById("app").innerHTML = `<div class="emptyState"><div><i>!</i><b>Most Wanted V2 could not start</b><p>Please reload the presentation. If it continues, reopen the current live link.</p></div></div>`;
});
